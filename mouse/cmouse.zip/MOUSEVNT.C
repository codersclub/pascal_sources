/* MOUSEVNT.C: Illustration of mouse function 12 */

/* INCLUDES */
#include <stdio.h>
#include <dos.h>
#include <mouse.i>

/* DEFINES */
#define ROMBIOS  int86 (0x10, &inreg, &outreg)

/* TYPE DEFINITION */
typedef struct {            /* structure for recording mouse event */
  unsigned  event,                          /* event that occurred */
            btnStatus,                    /* current button status */
            horiz, vert;          /* position where event occurred */
} mEvent;

/* LOCAL PROTOTYPES */
void clrScr (void);
void gotoxy (int, int);
/* --------------------------------------------------------------- */
void far handler (void)   /* event handler called by device driver */
{
mEvent  far *save;         /* pointer to save area in diff segment */
unsigned a, b, c, d;                  /* temp storage of registers */

  a = _AX, b = _BX, c = _CX, d = _DX;            /* save registers */
  save = MK_FP (_CS - 0x10, 0x00C0);     /* point to PSP user area */
  save->event = a;                      /* stuff registers into it */
  save->btnStatus = b;
  save->horiz = c;
  save->vert = d;
} /* ------------------------ */
main ()
{
mEvent  far *mous;
resetRec    *m;

/* Set up screen */
  clrScr ();                                       /* clear screen */
  gotoxy (17, 24);
  printf ("Press left button for position, right to quit");
  gotoxy (27, 0);
  puts ("MOUSE EVENT-HANDLING DEMO");

/* Set up mouse */
  m = mReset ();                               /* initialize mouse */
  if (m->exists) {                        /* if mouse exists . . . */
    mInstTask (0x14, FP_SEG (handler), FP_OFF (handler));
    mous = MK_FP (_psp, 0x00C0);          /* point to event buffer */
    mous->event = 0;                         /* reset event signal */
    mShow ();                                       /* show cursor */

/* Loop to perform demo */
    do {
      if (mous->event == 4) {     /* if left button operated . . . */
        mHide ();                 /* hide cursor in case of scroll */
        printf ("\nX = %3d, Y = %3d", mous->horiz, mous->vert);
        mShow ();                             /* show cursor again */
        mous->event = 0;                     /* reset event signal */
      }
    } while (mous->event != 0x10);        /* loop til right button */

/* Clean up and quit */
    mHide ();                                        /* cursor off */
    mReset ();                               /* reinitialize mouse */
  }
  clrScr ();                                       /* clear screen */
} /* ------------------------ */
void clrScr (void)                                 /* clear screen */
{           /* Uses ROM BIOS int 10h to reset video mode to itself */
struct REGS  inreg, outreg;

  inreg.h.ah = 0x0F;                           /* get current mode */
  ROMBIOS;
  inreg.h.al = outreg.h.al;                           /* copy mode */
  inreg.h.ah = 0;                            /* reset to same mode */
  ROMBIOS;
} /* ------------------------ */
void gotoxy (int col, int row)             /* position text cursor */
{                                         /* uses ROM BIOS int 10h */
struct REGS  inreg, outreg;

  inreg.h.ah = 2;                    /* fcn 2 sets cursor position */
  inreg.h.bh = 0;                        /* video page 0 is active */
  inreg.h.dh = row;
  inreg.h.dl = col;
  ROMBIOS;
} /* ------------------------ */