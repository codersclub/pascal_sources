/* MOUSDEMO.C:  Demo of basic mouse operations */

/* INCLUDES */
#include <stdio.h>
#include <dos.h>
#include <mouse.i>

/* CONSTANTS */
#define HARDWARE  1                                /* cursor types */
#define SOFTWARE  0
#define LEFT      0                               /* mouse buttons */
#define RITE      1
#define ROMBIOS   int86 (0x10, &inreg, &outreg)      /* BIOS calls */

/* LOCAL FUNCTIONS */
void  clrScr (void);
void  gotoxy (int col, int row);

/* --------------------------------------------------------------- */
main ()
{
resetRec   *theMouse;                       /* from reset function */
locRec     *its;                           /* from mouse inquiries */
int        col, row;
char       input [80];

  clrScr ();                                       /* clear screen */
  theMouse = mReset ();                             /* reset mouse */
  if (theMouse->exists) {             /* do following if it exists */

/* Software mouse cursor */
    puts ("Software cursor:");
    printf ("Demo of a mouse with %d buttons\n", theMouse->nButtons);
    puts ("Move the mouse around and click the left button");
    puts ("Click the right button for hardware demo\n");
    mTextCursor (SOFTWARE, 0x0000, 0x0718);      /* set s/w cursor */
    mShow ();                                        /* turn it on */
    do {
      its = mReleased (LEFT);                 /* check left button */
      if (its->opCount > 0) {
        mHide ();                  /* cursor off in case of scroll */
        printf ("\nMouse is at col %d, row %d", its->column,
                its->row);                      /* position report */
        mShow ();                                /* cursor back on */
      }
      its = mReleased (RITE);                /* check right button */
    } while (its->opCount == 0);          /* repeat until operated */

/* Now do hardware mouse cursor demo */
    clrScr ();                                     /* clear screen */
    puts ("Hardware cursor:");
    puts ("Move the mouse, click left button");
    puts ("Type something and press Enter");
    puts ("Click right button to end demo");
    theMouse = mReset ();                           /* reset mouse */
    mTextCursor (HARDWARE, 2, 5);                /* set h/w cursor */
    mShow ();                                         /* cursor on */
    do {
      its = mReleased (LEFT);                 /* check left button */
      if (its->opCount > 0) {                 /* if operated . . . */
        col = its->column / 8;            /* compute text position */
        row = its->row / 8;
        gotoxy (col, row);                             /* go there */
        putchar ('?');                                   /* prompt */
        gets (input);
        mMoveto (its->column, its->row);       /* restore position */
      }
      its = mReleased (RITE);                /* check right button */
    } while (its->opCount == 0);          /* repeat until operated */

/* Clean up and end of job */
    mTextCursor (HARDWARE, 6, 7);      /* use 11, 12 if mono board */
    mReset ();                                     /* reset cursor */
    clrScr ();                                     /* clear screen */
  } else
    puts ("Mouse not present in system. Demo can't run.");
} /* ------------------------ */
void  clrScr (void)                           /* clears the screen */
            /* Uses ROM BIOS int 10h to reset video mode to itself */
{
struct REGS  inreg, outreg;

  inreg.h.ah = 0x0F;                     /* first get current mode */
  ROMBIOS;
  inreg.h.al = outreg.h.al;                           /* copy mode */
  inreg.h.ah = 0;                        /* now reset to same mode */
  ROMBIOS;
} /* ------------------------ */
void  gotoxy (int col, int row)            /* position text cursor */
                                          /* Uses ROM BIOS int 10h */
{
struct REGS  inreg, outreg;

  inreg.h.ah = 2;                    /* function 2 sets cursor pos */
  inreg.h.bh = 0;                        /* video page 0 is active */
  inreg.h.dh = row;
  inreg.h.dl = col;
  ROMBIOS;
} /* ------------------------ */