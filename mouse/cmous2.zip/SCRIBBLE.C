/* SCRIBBLE.C:  Simple utility for drawing with mouse in graphics */

/* INCLUDES */
#include <stdio.h>
#include <dos.h>
#include <graphics.h>
#include <mouse.i>
#include <gmouscur.i>

/* DEFINE TRUE/FALSE */
#ifndef TRUE
#define TRUE  -1
#define FALSE  0
#endif

/* DEFINE CONSTANTS */
#define eventMask 0x55      /* any button released, or mouse moved */
#define menu        20                      /* bottom of menu area */
#define helpTop    185                         /* top of help area */
#define box1       160               /* right end of each menu box */
#define box2       320
#define box3       480
#define helpMsg1   "Click any button on Scribble to begin drawing"
#define helpMsg2   "Hold down left button to draw"

/* GLOBALS */
resetRec  *theMouse;
locRec    *mouses;

/* LOCAL FUNCTIONS */
void menuBox (int, int, char*);
void help (char*);
int  setUpScreen (void);
void updateMeter (int, int);
void work (void);

/* --------------------------------------------------------------- */

void main ()
{
  theEvents = MK_FP (_psp, 0x00C0);       /* point to event buffer */
  initGCurs ();                        /* initialize cursor images */
    theMouse = mReset ();                      /* initialize mouse */
  if (theMouse->exists) {
    theEvents->flag = 0;
      if (setUpScreen()) {               /* if in graphics mode... */
        mInstTask (eventMask, FP_SEG(handler),  /* install handler */
                  FP_OFF(handler));
        mGraphCursor (hand.hotX, hand.hotY, _DS,  /* graphics curs */
                     (unsigned) hand.image);
        mShow ();                                     /* cursor on */
        mouses = mPos ();                          /* get position */
        updateMeter (mouses->column, mouses->row);
        work ();                      /* do mouse stuff until thru */
        theMouse = mReset ();                       /* reset mouse */
        closegraph ();                        /* back to text mode */
      } else
        puts ("\nGraphics mode not available. Program ended.");
  } else
    puts ("Mouse not active. Program ended.");
} /* ------------------------ */

void menuBox (int x1, int x2, char *item)

    /* create a menu box between x1 and x2 at top of screen */

{
    setviewport (x1+1, 1, x2-1, menu-1, FALSE);
    clearviewport ();
    outtextxy (50, 7, item);                       /* display text */
    setviewport (0, 0, getmaxx(), helpTop, FALSE); /* drawing area */
} /* ------------------------ */

void help (char *message)

    /* Display help message at bottom of screen */

{
    int x;

    x = (getmaxx() - textwidth(message)) / 2;     /* For centering */
    setviewport (1, helpTop+1, 638, getmaxy() - 1, FALSE);
    clearviewport ();
    outtextxy (x, 3, message);               /* write help message */
    setviewport (0, menu, 639, helpTop, FALSE);    /* drawing area */
} /* ------------------------ */

int setUpScreen (void)

    /* Prepare screen, return TRUE if done, FALSE if can't */

{
int   driver   = CGA, mode = CGAHI;         /* use CGA hi-res mode */
char  path [6] = "C:\TC";                       /* path to drivers */

  initgraph (&driver, &mode, path);              /* set graph mode */
    if (graphresult () == grOk) {              /* if successful... */
      setcolor (1);                                  /* initialize */
      settextstyle (DEFAULT_FONT, HORIZ_DIR, 1);
      menuBox (0, box1, "Scribble");            /* make menu boxes */
      rectangle (0, 0, box1, menu);
      menuBox (box1, box2, " Clear");
      rectangle (box1, 0, box2, menu);
      menuBox (box2, box3, "  Quit");
      rectangle (box2, 0, box3, menu);
      rectangle (box3, 0, 639, menu);             /* box for meter */
      rectangle (0, helpTop, 639, getmaxy());      /* box for help */
      help (helpMsg1);                     /* initial help message */
      return (TRUE);                            /* successful exit */
    } else
      return (FALSE);                              /* unsuccessful */
} /* ------------------------ */

void updateMeter (int x, int y)

    /* Update mouse position meter, upper right corner */

{
char   position [9];

  sprintf (position, "%3d, %3d", x, y);   /* convert pos to string */
  menuBox (box3, 639, position);                     /* display it */
} /* ------------------------ */

void work (void)

     /* Draw with mouse until user clicks on Quit selection */

{
int    thru = FALSE;

  do {
    theEvents->flag = 0;                 /* clear mouse event flag */
    while (theEvents->flag == 0);          /* wait for mouse event */
    switch (theEvents->flag) {
      case 0x0001:                              /* mouse has moved */
        if ((theEvents->row > menu) &&
            (theEvents->row < helpTop))            /* in work area */
          if (theEvents->button == 1) {           /* and left down */
            mHide ();
            putpixel (theEvents->col, theEvents->row, 1);  /* draw */
            mShow ();
          }
        updateMeter (theEvents->col, theEvents->row);    /* update */
      break;
      case 0x0004:
      case 0x0010:
      case 0x0040:                          /* any button released */
        if (theEvents->row < menu)              /* if in menu area */
          if (theEvents->col < box1) {                /* Scribble? */
              mGraphCursor (cross.hotX, cross.hotY, _DS,
                           (unsigned) cross.image);
              help (helpMsg2);
           }
         else
           if (theEvents->col < box2) {                  /* Clear? */
             mHide ();
             setviewport (0, menu+1, getmaxx(), helpTop-1, TRUE);
             clearviewport ();
             mShow ();
             mGraphCursor (hand.hotX, hand.hotY, _DS,
                          (unsigned) hand.image);
             help (helpMsg1);
           } else
             if (theEvents->col < box3)                   /* Quit? */
               thru = TRUE;
          break;
    }
  } while (!thru);
} /* ------------------------ */