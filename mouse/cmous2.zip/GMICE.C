/* GMICE.C: Illustrates the default graphics mouse cursor, plus    */
/*    the four from GMOUSCUR.I                                     */

/* INCLUDES AND DEFINES */
#include <stdio.h>
#include <dos.h>
#include <graphics.h>
#include <c:\articles\porter\mouse2\mouse.inc>
#include <c:\articles\porter\mouse2\gmouscur.i>
#ifndef  TRUE
#define  TRUE  -1
#define  FALSE  0
#endif
#define  EVENTMASK  0x54   /* event when any mouse button released */

/* LOCAL PROTOTYPES */
void demo (GCURSREC, char*);
void graphicScreen (char*);
void identify (char*);

/* GLOBALS */
union REGS  reg;
int   driver = CGA, mode = CGAHI;
char  path [] = "C:\TC";

void main ()
{
resetRec    *theMouse;

/* Set up for run */
  initGCurs();                     /* initialize the cursor images */
  theMouse = mReset();                          /* reset the mouse */
  if (theMouse->exists) {
    mInstTask (EVENTMASK, FP_SEG (handler),      /* install handler*/
               FP_OFF (handler));
    theEvents = MK_FP (_psp, 0x00C0);     /* point to event record */

/* Show default cursor */
    graphicScreen ("Default cursor");
    mShow();                                     /* turn on cursor */
    theEvents->flag = 0;
    while (theEvents->flag == 0)                 /* wait for click */
      ;

/* Show the custom cursors */
    demo (check, "Check");
    demo (arrow, "Left arrow");
    demo (cross, "Cross");
    demo (hand,  "Pointing hand");
    demo (iBeam, "I-Beam");
    theMouse = mReset();                            /* reset mouse */
    closegraph();
  }
} /* ------------------------ */

void demo (GCURSREC cursor, char title[])  /* show graphics cursor */
{
  identify (title);
  mGraphCursor (cursor.hotX, cursor.hotY, (unsigned) (_DS),
                (unsigned) (cursor.image));
  theEvents->flag = 0;
  while (theEvents->flag == 0)                   /* wait for click */
      ;
} /* ------------------------ */

void graphicScreen (char  title[])       /* set up graphics screen */
{
int  x, y;
char prompt [30];

  initgraph (&driver, &mode, path);
  if (graphresult() == grOk) {
    identify (title);
		strcpy (prompt, "Click any button to continue");
    x = (getmaxx() - textwidth (prompt)) / 2;
		outtextxy (x, getmaxx() - 20, prompt);

  /* draw rectangle as backdrop for cursor */
		setfillstyle (SOLID_FILL, 1);
		setcolor (1);
    x = (getmaxx()/2) - 50;
		y = (getmaxy()/2) - 50;
		rectangle (x, y, x+100, y+100);
		floodfill (getmaxx()/2, getmaxy()/2, 1);
	}
} /* ------------------------ */

void identify (char *title)
{
int    x;

  setviewport (0, 0, getmaxx(), 30, TRUE);
	clearviewport();
	settextstyle (DEFAULT_FONT, HORIZ_DIR, 1);
  x = (getmaxx() - textwidth (title)) / 2;
	outtextxy (x, 20, title);
	setviewport (0, 0, getmaxx(), getmaxy(), TRUE);
} /* ------------------------ */

