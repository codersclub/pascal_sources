#include <conio.h>
#include "sbsample.c"

void clipsample(signed int *sample)
  {
    if (*sample > 127)  *sample = 127;
    if (*sample < -128) *sample = -128;
  }

void processsample(signed char *sample)
  {
    signed int temp;

    temp = *sample - 128;

    /* Process sample here */
    temp = temp; /* Very complex processing algorithm ;) */

    clipsample(&temp);
    *sample = temp + 128;
  }

int main(void)
  {
    unsigned char sample;

    resetdsp();
    while (!kbhit())
      {
        sample = getsample();
        processsample(&sample);
        outputsample(sample);
      }
    getch();

    return(0);
  }