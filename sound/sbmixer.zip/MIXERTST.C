#include "sbmixer.c"
#define baseio 0x220

int main(void)
  {
    init(baseio);
    resetmixer();
    setmicvolume(7);
    setvoicevolume(15, 15);
    setfmvolume(15, 15);
    setcdvolume(15, 15);
    setlinevolume(15, 15);
    return 0;
  }