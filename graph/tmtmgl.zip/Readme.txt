***************************************************************************
*   SciTech MGL                                                           *
*   Release 4.04                                                          *
*   Copyright (c) 1991-1997 SciTech Software, Inc. All Rights Reserved.   *
***************************************************************************

Supported environments:
    Microsoft Windows 32-bit

Description:
    This is a partial port of MGL to the TMT Pascal Multi-target compiler,
    which can be obtained from http://www.tmt.com. The following Pascal wrappers
    available in this release:
        MGLFX.PAS
        MGLGM.PAS
        MGLSPR.PAS
        MGLTYPES.PAS
        ZTEST.PAS
        ZTIMER.PAS

Release notice:
    3D graphics and OpenGL features of the MGL library are still to be
    ported.