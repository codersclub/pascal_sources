#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
        init(1);
        moveab(100,100);
        rlenfl(LIGHT_BLUE,115,RIGHT);
        printf("Press return to continue...\n");
        getchar();
        finit();
        exit(0);
    }



