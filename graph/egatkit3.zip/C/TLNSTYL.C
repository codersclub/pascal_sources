#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short mask;

        init(1);
        dcolor(LIGHT_GREEN);
        mask=0xF0F0;           /*  4 pixels on, 4 off, ...*/
        lnstyl(mask);
  /*  Give the background some color  */
        patbcl(LIGHT_RED);
        moveab(10,10);
        drawab(300,100);
  /*  Make solid again  */
        mask=0xFFFF;
        lnstyl(mask);
        moveab(20,10);
        drawab(310,100);
        printf("Press return to exit...\n");
        getchar();
        finit();
        exit(0);
    }



