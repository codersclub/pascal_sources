#include "hlev.h"

/****************************************************************
*	This routine is used to read and write PC paint brush files
*
*/
	void pbfile( fname, setup, error )
	char *fname;
	short setup[],*error;
	{
		*error=TKFILE( fname, setup );
		return;
	}
