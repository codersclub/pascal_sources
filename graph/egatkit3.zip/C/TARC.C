#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>
#include<math.h>

    struct{ short x,y; } Arc[36];


    main()
    {
    short i,nv,xrad,yrad,cx,cy;
    float theta,step;

        init(1);
	nv=19;          /*  Number of vertices  */
	cx=300;
	cy=175;
	xrad=118;
	yrad=100;
	theta=1.396;      /*  80 degress in radians  */
	step= 0.1745;    /*   uses 10 degree increments  */

        for( i=0; i<nv; ++i, theta+=step )  {
		Arc[i].x=(xrad*cos(theta))+cx;
		Arc[i].y=(yrad*sin(theta))+cy;
	}

/*   Move to the first point to leave the region open  */

        moveab( Arc[0].x, Arc[0].y );
	dcolor(LIGHT_BLUE);
        polyab( nv, Arc, OUTLINED);
        printf("Press Return to Exit...\n");
        getchar();
        finit();
        exit(0);
    }



