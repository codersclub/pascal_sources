#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

     main()
     {
     short ored,ogreen,oblue;

          init(1);
          dcolor(1);
          rectab(100,100,200,200,FILLED);

 /*   Read and save the contents of a colormap register   */

          inqmap(1,&ored,&ogreen,&oblue);

 /*  Change the colormap register   */
          printf("Press Return to Change Color Map Register...\n");
          getchar();
          colmap(1,0,3,0);

/*  Restore the register   */

          printf("Press return to restore register...\n");
          getchar();
          colmap(1,ored,ogreen,oblue);
          printf("Press return to exit...\n");
          getchar();
          finit();
          exit(0);
      }