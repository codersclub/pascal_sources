#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>
#include<math.h>

    struct{ short x,y; } circle [36];


    main()
    {
    short i,nv,xrad,yrad,cx,cy;
    float theta,step;

        init(1);
	nv=36;          /*  Number of vertices  */
	cx=300;
	cy=175;
	xrad=118;
	yrad=100;
	theta=0.;
	step= 6.2831853/nv;    /*  2 PI divided by the number of vertices  */

        for( i=0; i<nv; ++i, theta+=step )  {
		circle[i].x=(xrad*cos(theta))+cx;
		circle[i].y=(yrad*sin(theta))+cy;
	}

/*   Move to the last point to close the region  */

        moveab(circle[nv-1].x, circle[nv-1].y);
	dcolor(LIGHT_BLUE);
        polyab( nv, circle, OUTLINED);
        printf("Press Return to Exit...\n");
        getchar();
        finit();
        exit(0);
    }



