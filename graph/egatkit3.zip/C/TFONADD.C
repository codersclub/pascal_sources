#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short fadd[2];

        init(1);
        dcolor(YELLOW);
        fonadd(8,1,fadd);
        moveab(100,100);
        text("This is an 8 x 8 text string");
        fonadd(14,0,fadd);
        dfnfnt(fadd,14,0);
        moveab(100,120);
        text("This is an 8 x 14 test string");
        printf("Press Return to Exit...\n");
        getchar();
        finit();
        exit(0);
    }



