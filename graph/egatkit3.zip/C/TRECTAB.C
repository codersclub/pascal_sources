#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
        init(1);
        dcolor(LIGHT_RED);
/*  Draw a filled rectangle  */

        rectab(10,100,200,200,FILLED);

/*  Draw an outlined rectangle  */

        rectab(300,100,500,200,OUTLINED);
        printf("Press any key to continue...\n");
        getchar();
        finit();
        exit(0);
    }