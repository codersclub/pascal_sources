#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short mask;

        init(1);
        dcolor(DARK_BLUE);
        rectab(10,110,300,200,FILLED);

/*  Line with a background color  */

        dcolor(LIGHT_GREEN);
        mask=0xF0F0;           /*  4 pixels on, 4 off, ...*/
        lnstyl(mask);
        patbcl(LIGHT_RED);
        moveab(10,110);
        drawab(200,200);

/*  Line with a transparent background  */

        patbcl(TRANSPARENT);
        moveab(50,110);
        drawab(250,200);
        printf("Press return to exit...\n");
        getchar();
        finit();
        exit(0);
    }



