#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short i;

        init(1);
        split(25);
	text("This is a text string");
	dcolor(LIGHT_RED);
	rectab(0,26,639,349,0);
	vwait(100);
    /*  Reset according to BIOS  */
        split(511);
        printf("Press Return to Exit...\n");
        getchar();
        finit();
        exit(0);
    }