#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    struct{short x,y;}hexagon[6] = { {200,100},{350,150},
                                     {350,200},{200,250},
                                     {50,200},{50,150}};

    main()
    {
    short i;

        init(1);
        dcolor(LIGHT_GREEN);

/*  Draw a solid filled polygon   */

        polyab(6,&hexagon,FILLED);

/*  Move over and draw an outlined polygon  */

        for(i=0;i<6;++i)hexagon[i].x+=200;

/*   move to the last point to close the region  */

        moveab(hexagon[5].x,hexagon[5].y);
        polyab(6,&hexagon,OUTLINED);
        printf("Press return to continue...\n");
        getchar();
        finit();
        exit(0);
    }



