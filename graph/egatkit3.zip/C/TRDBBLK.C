#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    char buff[5000];

    main()
    {
    short i;

        init(1);
  /*  Write something to read  */

        for(i=0;i<10;++i){
            moveab(100,100+(i*14));
            text("This is a text string");
            }
        moveab(150,110);
        rdbblk(100,100,buff);   /*  Read 10,000  */
        moveab(400,200);
        wrbblk(100,100,buff);    /*  Write 10,000  */
        printf("Press return to exit...\n");
        getchar();
        finit();
        exit(0);
    }