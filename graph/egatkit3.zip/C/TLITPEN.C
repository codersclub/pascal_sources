#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short x,y;

        init(1);
        litpen(&x,&y);
        printf("Current pen position x,y = %d,%d\n");
        printf("Press return to exit...\n");
        getchar();
        finit();
        exit(0);
    }



