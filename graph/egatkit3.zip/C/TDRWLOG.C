#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
        init(1);
        dcolor(LIGHT_BLUE);
        rectab(10,100,100,200,FILLED);
        dcolor(YELLOW);

    /*  Set logic to "xor" */

        drwlog(3);
        rectab(60,150,100,250,FILLED);
        printf("Press return to restore rectangle\n");
        getchar();
        rectab(60,150,100,250,FILLED);
        printf("Press return to exit...\n");
        getchar();
        finit();
        exit(0);
    }



