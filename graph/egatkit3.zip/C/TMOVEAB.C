#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
        init(1);
        dcolor(BROWN);
        moveab(10,10);
        drawab(100,200);
        printf("Press return to continue...\n");
        getchar();
        finit();
        exit(0);
    }



