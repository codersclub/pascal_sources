#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
        init(1);

   /*  Draw something to copy  */

        dcolor(LIGHT_GREEN);
        rectab(110,110,200,200,OUTLINED);

   /*  Outline green rectangle with red one  */

        dcolor(LIGHT_RED);
        rectab(109,109,201,201,OUTLINED);

   /*  Copy a green one out with overlapping destination.   */

        cpyblk(110,110,150,150,91,91);
        printf("Press return to continue\n");
        getchar();
        finit();
        exit(0);
    }



