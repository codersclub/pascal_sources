#define DEFAULT_COLORS
#include<stdio.h>
#ifdef __TURBOC__
#include<stdlib.h>           /*  For Turbo C  */
#else
#include <malloc.h>          /*  For Microsoft C  */
#endif
#include<hlev.h>

    main()
    {
    short fadd[2];
    char *fbuff;

        init(1);
        fbuff=malloc(30000);
        ldfont("fnt1.sfp",fbuff);
        moveab(5,70);
        dcolor(LIGHT_BLUE);
        text("Laser Soft Font");
    /*  Dump the font  */
        free(fbuff);
    /*  Restore 8 x 14 font  */
        fonadd(14,1,fadd);
        printf("Press Return to Exit...\n");
        getchar();
        finit();
        exit(0);
    }



