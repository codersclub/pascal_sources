#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    static char*str = {"This is a text string"};

        init(1);
        dcolor(LIGHT_BLUE);
        rectab(150,80,300,250,FILLED);
        dcolor(WHITE);
        patbcl(DARK_RED);
        moveab(100,100);
        text(str);
        patbcl(TRANSPARENT);
        moveab(100,120);
        text("This is a string without a background cell");
        printf("Press Return to Continue...\n");
        getchar();
        finit();
        exit(0);
    }



