#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short i;

        init(1);
        rectab(10,10,300,200,FILLED);
        printf("Press return to cycle through colors...\n");
        for(i=1;i<16;++i){
            rdmask(i);
            getchar();
        }
        printf("Press return to exit...\n");
        getchar();
        finit();
        exit(0);
    }