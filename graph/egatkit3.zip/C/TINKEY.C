#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short ascii=0,scan=0;

    while(ascii!='\x'){
      INKEY(&scan,&ascii);
      printf("Scan code = %d, ASCII code = %d",scan,ascii);
    }
    exit(0);
    }



