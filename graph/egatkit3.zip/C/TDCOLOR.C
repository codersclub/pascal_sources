#define DEFAULT_COLORS
    #include<stdio.h>
    #include<hlev.h>

    main()
    {
        init(1);
        dcolor(LIGHT_BLUE);
        moveab(10,10);
        drawab(200,200);
        printf("Press any key...\n");
        getchar();
        finit();
        exit(0);
    }