#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

     char buff[1200];

     struct{short dim,med,bri;}cols[4] = {8,1,9,
                                         8,2,10,
                                         8,3,11,
                                         8,4,12};

     main()
     {
     short rad,i;

          init(1);
          rad=20;
          gensph(rad,buff);
          for(i=0;i<4;++i){
               drwsph((i*50)+30,150,rad,(short*)&cols[i],buff);
               }
          printf("Press Return to exit...\n");
          getchar();
          finit();
          exit(0);
      }