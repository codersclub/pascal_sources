#define DEFAULT_COLORS
#include <hlev.h>
#include <stdio.h>

    main()
    {
    short orgx,orgy,finished,scr_xmax,scr_ymax;
    short curx, cury;
    short m1,m2,m3,m4;
    char str[80],*sformat;

/*  Calculate some variables and draw screen  */
    scr_xmax=639;
    scr_ymax=349;
    orgx=scr_xmax-(30*8);
    orgy=10;
    finished=0;

    init(1);
    dcolor(DARK_CYAN);
    rectab(0,0,scr_xmax,scr_ymax,FILLED);
    dcolor(LIGHT_RED);
    rectab(0,0,scr_xmax,scr_ymax,OUTLINED);

/*  Initialize the mouse  */
    m1=0;
    TKMOUS(&m1,&m2,&m3,&m4);
    if(! m1)  {
	finit();
	printf("Mouse not installed..\n");
	exit(1);
    }
/*  Set screen extents  */
    m1=7;
    m3=0;
    m4=scr_xmax;
    TKMOUS(&m1,&m2,&m3,&m4);
    m1=8;
    m3=0;
    m4=scr_ymax;
    TKMOUS(&m1,&m2,&m3,&m4);
/*  Set the cursor position  */
    m1=4;
    m3=scr_xmax/2;
    m4=scr_ymax/2;
    curx=m3;
    cury=m4;
    TKMOUS(&m1,&m2,&m3,&m4);
    setcur(SHOW,curx,cury);
/*  Track cursor  */
    dcolor(BLACK);
    patbcl(LIGHT_CYAN);
    sformat="Button = %d X = %3d Y = %3d";
    moveab(orgx,orgy);
    sprintf(str,sformat,0,curx,cury);
    text(str);
    m1=3;
    while(! finished)  {
	TKMOUS(&m1,&m2,&m3,&m4);
	if(m2)  {
		moveab(orgx,orgy);
		sprintf(str,sformat,m2,curx,cury);
		text(str);
		if(m2==3)finished=1;
	}
	if(m3 != curx)  {
		curx=m3;
		setcur(SHOW,curx,cury);
	}
	if(m4 != cury)  {
		cury=m4;
		setcur(SHOW,curx,cury);
	}
    }
/*  All done !  */
    finit();
    exit(0);
    }

