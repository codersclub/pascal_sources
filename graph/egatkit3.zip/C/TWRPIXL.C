#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short i,color;

        init(1);
        for(i=0;i<16;++i){
            wrpixl(200+i,10,i);
        }
        for(i=0;i<16;++i){
            rdpixl(200+i,10,&color);
            printf("Color %d is %d\n",i,color);
        }
        printf("Press Return to Exit...\n");
        getchar();
        finit();
        exit(0);
    }