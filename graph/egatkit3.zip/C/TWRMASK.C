#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {

        init(1);
   /*  Draw the first rectangle  */
        dcolor(WHITE);
        rectab(10,10,100,100,FILLED);
   /*  Set write mask and draw second rectangle  */
        wrmask(1);
        rectab(200,10,300,100,FILLED);
   /*  Restore write mask for normal drawing   */
        wrmask(15);
        printf("Press Return to Continue...\n");
        getchar();
        finit();
        exit(0);
    }