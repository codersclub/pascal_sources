#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    char str[10];
    short func,port,i;
    static short setup[11] = { 0,0,0,0, 800,1100, 0,0,0,0,0 };

        func = 1;
	port = 0;
        printf("Print Mode [0-5]:  ");
	scanf("%hd",&setup[0]);
	printf("Portrait or Landscape [0-1]:  ");
	scanf("%hd",&setup[1]);
	printf("Print Position X:  ");
	scanf("%hd",&setup[2]);
	printf("Print Position Y:  ");
	scanf("%hd",&setup[3]);

        init(1);
  /*  Initialize the printer driver  */
	IBMGPI(&func,&port,setup);
	dcolor(WHITE);
        rectab(0,0,639,349,OUTLINED);
	moveab(100,150);
	text("This is an 8 x 14 text string");
  /*  Draw some colored rectangles to print  */
        for(i=0; i<14; ++i){
            dcolor(i+1);
            rectab( (i*30)+10, 10, (i*30)+30, 100, FILLED);
            }
  /*  Print the screen and sheck if error condition  */
	if( IBMGPP () ) {
	    printf("Output error\n");
	    exit( 1 );
	}
  /*  Restore previous print screen handler  */
	func=2;
	IBMGPI(&func, &port, setup );

        printf("Press Return to Exit...\n");
        getchar();
        finit();
        exit(0);
    }
