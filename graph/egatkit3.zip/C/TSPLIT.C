#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short i;

        init(1);
        dcolor(LIGHT_RED);
        rectab(0,0,639,349,OUTLINED);
        moveab(100,100);
        text("This is page 0");
        rwpage(1,1);
        dcolor(LIGHT_BLUE);
        rectab(0,0,639,349,OUTLINED);
        text("This page 1");
        vpage(1);
        for(i=350;i>100;--i)
           split(i);
        for(i=100;i<350;++i)
           split(i);
    /*  Reset according to BIOS  */
        split(511);
        moveab(20,20);
        text("Press Return to Exit");
        getchar();
        finit();
        exit(0);
    }