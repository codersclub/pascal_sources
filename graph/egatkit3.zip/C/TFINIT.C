#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
        init(1);
        dcolor(DARK_GREEN);
        rectab(0,0,639,349,OUTLINED);
        moveab(100,200);
        dcolor(YELLOW);
        text("This is 640 x 350 graphics mode");
        printf("Press any key...\n");
        getchar();
        finit();
        exit(0);
    }



