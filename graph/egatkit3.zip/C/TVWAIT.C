#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
        init(1);
        dcolor(YELLOW);
        rectab(100,100,200,150,FILLED);
        vwait(100);
        dcolor(DARK_CYAN);
	rectab(300,100,400,150,FILLED);
        printf("Press Return to Exit...\n");
        getchar();
        finit();
        exit(0);
    }