#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>
#include<math.h>

    struct{ float sin,cos; } UnitCircle[36];

    main()
    {
    short i,nv,xrad,yrad,cx,cy;
    float theta,step;
    struct { short x,y; } ellipse[36];

    theta=0.;
    step=.1745;
    nv=36;

    for( i=0; i<nv; ++i,theta+=step ) {
	    UnitCircle[i].cos=cos( theta );
	    UnitCircle[i].sin=sin( theta );
    }

    /*  Now use the data to generate an ellipse  */
	xrad=75;
	yrad=120;
        cx=320;
        cy=175;

        for( i=0; i<nv; ++i )  {
		ellipse[i].x=(xrad*UnitCircle[i].cos)+cx;
		ellipse[i].y=(yrad*UnitCircle[i].sin)+cy;
	}

        init(1);
	dcolor(LIGHT_RED);
        moveab( ellipse[nv-1].x, ellipse[nv-1].y );
        polyab( nv, ellipse, FILLED);
        printf("Press Return to Exit...\n");
        getchar();
        finit();
        exit(0);
    }



