#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short i,x,wpage;

        init(1);
        wpage=0;
        x=0;
        for(i=0;i<100;++i){
            wpage=1-wpage;  /*  Flip page  */
            rwpage(0,wpage);
            derase();       /*  Erase old page  */
            dcolor(LIGHT_BLUE);     /*  Draw new  */
            x+=5;
            rectab(x,100,x+100,150,FILLED);
            vpage(wpage);         /*  Display new  */
        }
   /*  Set visual page back to 0 to see BIOS output  */
        vpage(0);
        printf("Press Return to Exit...\n");
        getchar();
        finit();
        exit(0);
    }