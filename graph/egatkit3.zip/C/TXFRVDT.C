#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short setup[12];

        init(1);
    /*  Draw something to read  */
        dcolor(DARK_BLUE);
        rectab(8,100,119,200,FILLED);
    /*  Copy from plane 0, 2D format to linear off screen  */
        setup[0]=0;               /*  source plane 0   */
        setup[1]=1;               /*  source 2D format  */
        setup[2]=0;               /*  destination plane 0  */
        setup[3]=0;               /*  destination linear format  */
        setup[4]=14;              /*  14 bytes (112 pixels) wide   */
        setup[5]=101;             /*  height in rows  */
        setup[6]=1;               /*  source X, byte offset */
        setup[7]=100;             /*  source Y, row offset  */
        setup[8]=0;               /*  destination X, byte offset  */
        setup[9]=350;             /*  destination Y, row offset  */
        XFRVDT(setup);

    /*  Copy from off screen linear to 2D plane 1  */
        setup[0]=0;               /*  source plane 0   */
        setup[1]=0;               /*  source linear format  */
        setup[2]=1;               /*  destination plane 1  */
        setup[3]=1;               /*  destination 2D format  */
        setup[4]=14;              /*  14 bytes (112 pixels) wide   */
        setup[5]=101;             /*  height in rows  */
        setup[6]=0;               /*  source X, byte offset */
        setup[7]=350;             /*  source Y, row offset  */
        setup[8]=40;               /*  destination X, byte offset  */
        setup[9]=100;             /*  destination Y, row offset  */
        XFRVDT(setup);
        printf("Press return to exit...\n");
        getchar();
        finit();
        exit(0);
    }