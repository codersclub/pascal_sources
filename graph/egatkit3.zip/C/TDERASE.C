
#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
        init(1);
    /*  Draw something to erase */

        dcolor(DARK_GREEN);
        rectab(10,100,100,200,FILLED);
        printf("Press return to erase screen...\n");
        getchar();

    /*  Erase the screen   */

        derase();
        printf("Press Return to Continue...\n");
        getchar();
        finit();
        exit(0);
    }



