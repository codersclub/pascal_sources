#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short i;

        init(1);
        dcolor(LIGHT_GREEN);
/*  Draw a filled rectangle  to save  */
        rectab(100,200,400,250,FILLED);
        moveab(150,225);
        dcolor(WHITE);
        text("This is a protected region");

/*  Animate a box across the screen  */
        dcolor(LIGHT_BLUE);
        for(i=0;i<300;++i){
            moveab(50+i,210);
            savreg(50,31,0x6D60,SAVE);
            rectab(50+i,210,100+i,240,FILLED);
            vwait(1);
            savreg(50,31,0x6D60,RESTORE);
        }
        printf("Press Return to exit...\n");
        getchar();
        finit();
        exit(0);
    }