#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

     main()
     {
          init(1);
     /* Draw a blue box */
          dcolor(1);
          rectab( 10,100,100,200,FILLED);
          printf("Press return to turn box red\n");
          getchar();
     /* Draw a red box */
          colmap(1,3,0,0);
          printf("Press return to turn box to blue\n");
          getchar();
     /* Make box blue again */
          colmap(1,0,0,2);
          printf("Press return to exit...\n");
          getchar();
          finit();
          exit(0);
      }