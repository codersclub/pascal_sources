#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    void sub1(void);

    main()
    {
    short vadd[2],aadd[2],fadd[2];
    short myvar,myarray[10];

    /*  Get the address of "myvar"  */

        GETADD((char*)&myvar,vadd);

    /*  Get the address of "myarray"   */

        GETADD((char*)myarray,aadd);

    /*  Get the address of "sub1"  */

        GETADD((char*)sub1,fadd);
        exit(0);
    }

    void sub1()
    {
        return;
    }