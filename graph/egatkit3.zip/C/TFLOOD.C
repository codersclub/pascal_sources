#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
        init(1);
        dcolor(LIGHT_RED);
        rectab(10,100,500,300,OUTLINED);
        rectab(100,150,300,250,FILLED);
        dcolor(DARK_GREEN);
        printf("Press return to flood fill rectangle\n");
        getchar();
        flood(20,120);
        printf("Press return to continue...\n");
        getchar();
        finit();
        exit(0);
    }



