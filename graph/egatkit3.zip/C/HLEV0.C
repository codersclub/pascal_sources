/****************************************************************
* HLEV0.C * Created: 11/29/87		Revised: 3/07/88	*
*---------* By: Ed Connell					*
*     This module contains the "C" layer of functions used to	*
* interface with the assembly language portion of the toolkit.	*
* This module was developed with MS C 5.0.  This module should  *
* also work without modification with TURBO C.			*
****************************************************************/
#include <string.h>			/* These headers must */
#include "hlev.h"			/* be included.       */

	static short pt[60];
	char far **badd2 = (char far **)&pt[2];
	char far **badd0 = (char far **)&pt[0];

/*****************************************************************
*	This routine initializes the display.
*/
	void init( mode )
	short mode;
	{
	static short func[2] = { 0,0 };
	short fadd[2];
	pt[0]=mode;			/* Graphics mode */
	pt[1]=0;

		EGAC16( func,pt );
		return;
	}
/*****************************************************************
*	This routine terminates graphics mode.
*/
	void finit()
	{
	static short func[2] = { 0,0 };
	pt[0]=0;			/* Text mode */

		EGAC16( func,pt );
		return;
	}
/*****************************************************************
*	This routine erases the display.
*/
	void derase()
	{
	static short func[2] = { 1, 0 };

		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine sets a colormap register.
*/
	void colmap( index , red , green , blue )
	short index,red,green,blue;
	{
	static short func[2] = { 2,0 };
		pt[0]=index;
		pt[1]=red;
		pt[2]=green;
		pt[3]=blue;

		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to inquire on a colormap register.
*/
	void inqmap( index , red , green , blue )
	short index,*red,*green,*blue;
	{
	static short func[2] = { 3,0 };
	
		pt[0]=index;
		EGAC16( func , pt );
		*red=pt[1];
		*green=pt[2];
		*blue=pt[3];
		return;
	}
/*****************************************************************
*	This routine is used to set the drawing logic
*/
	void drwlog( ltype )
	short ltype;
	{
	static short func[2] = { 4,0 };
		
		EGAC16( func , &ltype );
		return;
	}
/*****************************************************************
*	This routine is used to set the drawing color
*/
	void dcolor( icol )
	short icol;
	{
	static short func[2] = { 5,0 };
		
		EGAC16( func , &icol );
		return;
	}
/*****************************************************************
*	This routine is used to set the current position.
*/
	void moveab( ix,iy )
	short ix,iy;
	{
	static short func[2] = { 6,0 };
		
		pt[0]=ix;
		pt[1]=iy;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to draw a line from the current
*	position to the specified point.
*/
	void drawab( ix,iy )
	short ix,iy;
	{
	static short func[2] = { 7,0 };
		
		pt[0]=ix;
		pt[1]=iy;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to draw a polygon.
*/
	void polyab( nv,pnts,fill )
	short nv,pnts[],fill;
	{
	short func[2];
		
		func[0]=( fill ) ? (9):(8);
		func[1]=nv;
		EGAC16( func,pnts );
		return;
	}
/*****************************************************************
*	This routine is used to draw a rectangle.
*/
	void rectab( ix1,iy1,ix2,iy2,fill )
	short ix1,iy1,ix2,iy2,fill;
	{
	static short func[2] = { 0,0 };
		
		func[0]=( fill ) ? (11):(10);
		pt[0]=ix1;
		pt[1]=iy1;
		pt[2]=ix2;
		pt[3]=iy2;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to flood a region.
*/
	void flood( ix,iy )
	short ix,iy;
	{
	static short func[2] = { 12,0 };
		
		pt[0]=ix;
		pt[1]=iy;
		EGAC16( func,pt );
		return;
	}
/*****************************************************************
*	This routine is used to perform a run length fill.
*	Direction specifies whether fill is horizontal or vertical.
*	0 = horizontal
*	1 = vertical
*/
	void rlenfl( icol , icnt , direction )
	short icol,icnt,direction;
	{
	static short func[2] = { 13,0 };
		
		pt[0]=icol;
		pt[1]=icnt;
		pt[2]=direction;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to set the line style.
*/
	void lnstyl( istyle )
	short istyle;
	{
	static short func[2] = { 14,0 };
		
		EGAC16( func , &istyle );
		return;
	}
/*****************************************************************
*	This routine is used to set the fill style.
	Data is passed as an unsigned character array.
*/
	void flstyl( fstyle )
	char *fstyle;
	{
	static short func[2] = { 15,0 };
		
		EGAC16( func , (short *)fstyle );
		return;
	}
/*****************************************************************
*	This routine is used to set the pattern background color.
*/
	void patbcl( ibcol )
	short ibcol;
	{
	static short func[2] = { 16,0 };
		
		EGAC16( func , &ibcol );
		return;
	}
/*****************************************************************
*	This routine is used to output a text string.
*/
	void text( str )
	char *str;
	{
	static short func[2] = { 17, 0 };
		
		func[1]=strlen( str );
		EGAC16( func,(short *)str );
		return;
	}
/*****************************************************************
*	This routine is used to define a raster font.
*/
	void dfnfnt( fadd,height,hp )
	short fadd[2],height,hp;
	{
	static short func[2] = { 18,0 };
	
		pt[0]=fadd[0];
		pt[1]=fadd[1];
		pt[2]=height;
		pt[3]=hp;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to read a pixel block.
*	pt[2] holds the offset of buff
*	pt[3] holds the segment of buff
*/
	void rdpblk( width,height,buff )
	short width,height;
	char  *buff;
	{
	static short func[2] = { 19,0 };

		pt[0]=width;
		pt[1]=height;
		*badd2=buff;

		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to write a pixel block.
*	pt[2] holds the offset of buff
*	pt[3] holds the segment of buff
*/

	void wrpblk( width,height,buff )
	short width,height;
	char  *buff;
	{
	static short func[2] = { 20,0 };

		pt[0]=width;
		pt[1]=height;
		*badd2=buff;

		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to read a bit block.
*/
	void rdbblk( width,height,buff )
	short width,height;
	char  *buff;
	{
	static short func[2] = { 21,0 };

		pt[0]=width;
		pt[1]=height;
		*badd2=buff;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to write a bit block.
*/
	void wrbblk( width,height,buff )
	short width,height;
	char  *buff;
	{
	static short func[2] = { 22,0 };

		pt[0]=width;
		pt[1]=height;
		*badd2=buff;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to copy a pixel block.
*/
	void cpyblk( sx,sy,dx,dy,width,height )
	short  sx,sy,dx,dy,width,height;
	{
	static short func[2] = { 23,0 };

		pt[0]=sx;
		pt[1]=sy;
		pt[2]=dx;
		pt[3]=dy;
		pt[4]=width;
		pt[5]=height;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to set the plane read mask.
*/
	void rdmask( mask )
	short mask;
	{
	static short func[2] = { 24,0 };

		EGAC16( func , &mask );
		return;
	}
/*****************************************************************
*	This routine is used to set the plane write mask.
*/
	void wrmask( mask )
	short mask;
	{
	static short func[2] = { 25,0 };

		EGAC16( func , &mask );
		return;
	}
/*****************************************************************
*	This routine is used to set the read/write enabled pages.
*/
	void rwpage( iread,iwrite )
	short iread,iwrite;
	{
	static short func[2] = { 26,0 };

		pt[0]=iread;
		pt[1]=iwrite;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to set the visual page.
*/
	void vpage( ipage )
	short ipage;
	{
	static short func[2] = { 27,0 };

		EGAC16( func , &ipage );
		return;
	}
/*****************************************************************
*	This routine is used to pan the display.
*/
	void pan( ulx,uly )
	short ulx,uly;
	{
	static short func[2] = { 28,0 };

		pt[0]=ulx;
		pt[1]=uly;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to wait for vertical retrace.
*/
	void vwait( icnt )
	short icnt;
	{
	static short func[2] = { 29,0 };
	short i;

		for( i=1 ; i <= icnt ; ++i ) EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to determine the amount of graphics
*	memory installed.
*/
	void inqmem( imem )
	short *imem;
	{
	static short func[2] = { 30,0 };

		EGAC16( func , imem );
		return;
	}
/*****************************************************************
*	This routine is used to create a split screen.
*/
	void split( line )
	short line;
	{
	static short func[2] = { 31,0 };

		EGAC16( func , &line );
		return;
	}
/*****************************************************************
*	This routine is used to set the logical screen width.
*/
	void swidth( iwid )
	short iwid;
	{
	static short func[2] = { 32,0 };

		EGAC16( func , &iwid );
		return;
	}
/****************************************************************
*	This routine is used to retrieve the 8x8 and 8x14 font
*	addresses from the system ROM.
*/
	void fonadd( height,inst,fadd )
	short  height,inst,fadd[];
	{
	static short func[2] = { 33,0 };

		pt[0]=height;
		pt[1]=inst;
		EGAC16( func , pt );
		if( pt[0] ) {
			fadd[0]=pt[1];
			fadd[1]=pt[2];
		} else {
			fadd[0]=0;
			fadd[1]=0;
		}
		return;
	}
/*****************************************************************
*	This routine is used to save a byte region of the display.
*/
	void savreg( width,height,offset,SorR )
	short width,height,offset,SorR;
	{
	static short func[2] = { 34,0 };

		pt[0]=width;
		pt[1]=height;
		pt[2]=offset;
		pt[3]=SorR;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to read the light pen register.
*/
	void litpen( x,y )
	short *x,*y;
	{
	static short func[2] = { 35,0 };

		EGAC16( func , pt );
		*x=pt[0];
		*y=pt[1];
		return;
	}
/****************************************************************
*	This routine is used to show or hide the cursor at the
*	specified position on the display.
*/
	void setcur( ifunc , ix , iy )
	short ifunc,ix,iy;
	{
	static short func[2]= { 36,0 };

		if( ifunc == 0 ) {
		  pt[0]=0;  pt[1]=ix;  pt[2]=iy;
		} else {
		  pt[0]=1;
		}
		EGAC16( func , pt );
		return;
	}
/****************************************************************
*	This routine is used to define the color and shape of the
*	graphics cursor.  The shape is determined by two contiguous
*	sets of bits masks background defined first.
*/
	void defcur( ifc , ibc , imask , ihotx , ihoty )
	short ifc,ibc,imask[],ihotx,ihoty;
	{
	static short func[2] = { 36 ,0 };
	short j;
/*----- set colors
*/
		pt[0]=2;
		pt[1]=ifc;
		pt[2]=ibc;
		EGAC16( func , pt );
		pt[0]=3;
		for( j=1 ; j < 33 ; ++j ) {
			pt[j]=imask[j-1];
		}
		pt[33]=ihotx;
		pt[34]=ihoty;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to set the object clipping boundaries.
*/
	void oclip( ix1,iy1,ix2,iy2 )
	short  ix1,iy1,ix2,iy2;
	{
	static short func[2] = { 37 , 0 };

		pt[0]=ix1;
		pt[1]=iy1;
		pt[2]=ix2;
		pt[3]=iy2;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to generate a shaded sphere.
*/
	void gensph( rad , buff )
	short rad;
	char  *buff;
	{
	static short func[2] = { 38,0 };

		*badd0=buff;
		pt[2]=rad;
		EGAC16( func , pt );
		return;
	}
/*****************************************************************
*	This routine is used to draw a shaded sphere.
*/
	void drwsph( ix , iy , rad , icols , buff )
	short ix,iy,rad,icols[];
	char  *buff;
	{
	static short func[2] = { 39,0 };

		*badd0=buff;
		pt[2]=rad;
		pt[3]=ix;
		pt[4]=iy;
		pt[5]=icols[0];
		pt[6]=icols[1];
		pt[7]=icols[2];
		EGAC16( func , pt );
		return;
	}
/****************************************************************
* 	This routine is used to read a single pixel from the screen.
*/
	void rdpixl( ix, iy, icol )
	short ix,iy,*icol;
	{
	static short func[2] = { 40,0 };
		pt[0]=ix;
		pt[1]=iy;
		EGAC16( func, pt );
		*icol=pt[2];
		return;
	}
/****************************************************************
* 	This routine is used to write a single pixel to the screen.
*/
	void wrpixl( ix, iy, icol )
	short ix,iy,icol;
	{
	static short func[2] = { 41,0 };
		pt[0]=ix;
		pt[1]=iy;
		pt[2]=icol;
		EGAC16( func, pt );
		return;
	}
/****************************************************************
*	This routine is used to inquire on the current position
*/
	void inqpos( ix, iy )
	short *ix, *iy;
	{
	static short func[2] = { 42,0 };
		EGAC16( func, pt );
		*ix=pt[0];
		*iy=pt[1];
		return;
	}

