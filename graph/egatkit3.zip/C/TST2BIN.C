#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short slen,value;

	slen=16;
        ST2BIN( "0000000000000101",&slen,"B",&value);
        printf("The converted value is = %d\n",value);
        exit(0);
    }