#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short i;

        init(1);
        swidth(50);        /*  screen of 800 wide  */
        dcolor(LIGHT_GREEN);
        rectab(0,0,799,599,OUTLINED);
        dcolor(DARK_CYAN);
        rectab(500,250,700,450,FILLED);

  /*  Pan the viewable window to the rectangle  */
        for(i=0;i<199;++i){
            pan(i,i);
            }
        moveab(200,200);
	dcolor(15);
        text("Press return to exit...");
        getchar();
        finit();
        exit(0);
    }