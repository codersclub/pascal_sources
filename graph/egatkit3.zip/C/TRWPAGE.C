#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
        init(1);
        moveab(200,10);
        text("This is page 0");
    /*  Go to page 1 and draw a red box  */
        rwpage(1,1);
        dcolor(LIGHT_RED);
        rectab(100,100,200,200,FILLED);
    /*  Go back to page 0 and copy the red box to this page  */
        rwpage(1,0);
        moveab(200,30);
        text("We now have a red box on page 0");
        cpyblk(100,100,200,100,101,101);
        printf("Press Return to Exit...\n");
        getchar();
        finit();
        exit(0);
    }