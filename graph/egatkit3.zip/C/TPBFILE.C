#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short setup[4],error,i;

        init(1);
    /*  Frame the screen  */
        dcolor(DARK_GREEN);
        rectab(0,0,639,349,OUTLINED);
        for(i=1;i<16;++i){
            dcolor(i);
            rectab((i*30),10,20+(i*30),100,FILLED);
            }
    /*  Save the screen to a .PCX file  */
        setup[0]=0;               /*  .PCX   */
        setup[1]=1;               /*  write to a file  */
        setup[2]=640;             /*  width of region  */
        setup[3]=350;             /*  height of region  */
        pbfile("fullscr.pcx",setup,&error);
        if(error)  {
            printf("Error writing screen\n");
        }
        printf("Return to read image back\n");
        getchar();
        derase();                 /*  clear screen  */
        setup[1]=0;               /*  read file  */
        pbfile("fullscr.pcx",setup,&error);
        if(error) {
            printf("Error reading screen\n");
        }
    /*  Save a portion of the screen to a .PCC file  */

        moveab(30,10);
        setup[0]=1;               /*  .PCC  */
        setup[1]=1;               /*  write to a file  */
        setup[2]=200;             /*  width of region  */
        setup[3]=100;             /*  height of region  */
        pbfile("partial.pcc",setup,&error);
        if(error) {
            printf("Error writing screen\n");
        }
    /*  Retrieve the .PCC file and write to the screen  */
        moveab(30,200);
        setup[1]=0;               /*  read a file  */
        pbfile("partial.pcc",setup,&error);
        if(error)  {
            printf("Error reading the file\n");
        }
        printf("Press return to exit...\n");
        getchar();
        finit();
        exit(0);
    }