#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

     main()
     {
     short mem;

          init(1);
          inqmem(&mem);
          switch(mem) {
            case 0:
               printf("64K of memory is installed\n");
               break;
            case 1:
               printf("128K of memory is installed\n");
               break;
            case 2:
               printf("192K of memory is installed\n");
               break;
            case 3:
               printf("256K of memory is installed\n");
               break;
          }
          printf("Return to exit...\n");
          getchar();
          finit();
          exit(0);
          }
