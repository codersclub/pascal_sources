/****************************************************************
* LDFONT *							*
*--------*							*
*     This routine is used to load a laser font and define	*
* it to be used.						*
****************************************************************/
#include "hlev.h"
#include <string.h>
#include <fcntl.h>
#include <io.h>
#ifdef M_I86				/* MSC Predefined Symbol */
 #include <sys\types.h>
 #include <sys\stat.h>
#endif

	static short fadd[2];
	static char far **fadd0 = (char far **)&fadd[0];



	void ldfont( fnt_name, buff )
	char *fnt_name,*buff;
	{
	int fh1;

		fh1 = open( fnt_name,O_RDONLY );
		if( fh1 == -1 ) {
			perror("Font Open Failed");
			return;
		}

		if( (read( fh1, buff, filelength(fh1) )) == -1 ) {
			perror( "Font File Read Error" );
			close( fh1 );
			return;
		}
		close( fh1 );
		*fadd0=buff;
		dfnfnt( fadd, 0, 1 );
	}
