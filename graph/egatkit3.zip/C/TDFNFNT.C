#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short smallfont[2];

        init(1);
        dcolor(LIGHT_BLUE);
        fonadd(8,0,smallfont);     /* get 8x8 address */
        moveab(100,100);
        text("This is an 8 x 14 font");     /* Default size */

    /*  Define 8 x 8 raster font as current font */

        dfnfnt(smallfont,8,0);
        moveab(100,120);
        text("This is an 8 x 8 font");
        printf("Press return to continue...\n");
	getchar();
        finit();
        exit(0);
    }
