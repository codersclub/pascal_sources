#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    short shape[32] = {
        /* background mask values */
        0xFFFF,0x8001,0x8001,0x8001,
        0x8001,0x8001,0x8001,0x8001,
        0x8001,0x8001,0x8001,0x8001,
        0x8001,0x8001,0x8001,0xFFFF,
        /* foreground mask values */
        0x0180,0x0180,0x0180,0x0180,
        0x0180,0x0180,0x0180,0xFFFF,
        0xFFFF,0x0180,0x0180,0x0180,
        0x0180,0x0180,0x0180,0x0180 };

        main()
        {
            init(1);

   /* put the default cursor up */

            setcur(SHOW,100,100);
            printf("Press Return to change cursor...\n");
            getchar();

   /* define a new shape and color */

            defcur(LIGHT_BLUE,LIGHT_GREEN,shape,8,8);
   /* show the new cursor */
            setcur(SHOW,100,100);
            printf("Press return to exit...\n");
            getchar();
            finit();
            exit(0);
        }