#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    main()
    {
    short x,y;

        init(1);
        dcolor(LIGHT_MAGENTA);
        moveab(100,100);
        text("This is a string");
        inqpos(&x,&y);
        printf("New position x,y = %d,%d\n");
        printf("Press return to exit...\n");
        getchar();
        finit();
        exit(0);
    }



