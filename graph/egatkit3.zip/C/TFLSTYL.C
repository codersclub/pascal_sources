#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    char style1[64] = {9,9,9,9,9,9,9,9,
                       9,7,7,7,7,7,7,9,
                       9,7,1,1,1,1,7,9,
                       9,7,1,8,8,1,7,9,
                       9,7,1,8,8,1,7,9,
                       9,7,1,1,1,1,7,9,
                       9,7,7,7,7,7,7,9,
                       9,9,9,9,9,9,9,9};

    main()
    {
    short i;

        init(1);
    /*  Draw a solid filled rectangle */

        dcolor(LIGHT_RED);
        rectab(10,10,100,100,FILLED);

    /*  Draw a patterned filled rectangle */

        flstyl(style1);
        rectab(200,10,400,200,FILLED);

    /*  Draw a patterned-filled rectangle transparency  */

        patbcl(TRANSPARENT);
        dcolor(LIGHT_BLUE);
        rectab(50,50,150,150,FILLED);

    /*  Reset the pattern to a solid fill by making all the
        elements the same  */

        for(i=0;i<64;++i)
            style1[i]=1;
        flstyl(style1);

    /* Draw a solid filled rectangle  */

        dcolor(DARK_GREEN);
        rectab(10,10,100,100,FILLED);
        printf("Press return to exit...\n");
        getchar();
        finit();
        exit(0);
    }



