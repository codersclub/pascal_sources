#define DEFAULT_COLORS
#include<stdio.h>
#include<hlev.h>

    char buff[10000];

    main()
    {
    short i;

        init(1);

    /*  Write something to read  */

        for(i=0;i<10;++i){
            moveab(100,100+(i*14));
            text("This is a text string");
            }

        moveab(150,110);
        rdpblk(100,100,buff);     /*  read 10,000  */
        moveab(400,200);
        wrpblk(100,100,buff);     /*  write 10,000  */
        printf("Press return to continue...\n");
        getchar();
        finit();
        exit(0);
    }



