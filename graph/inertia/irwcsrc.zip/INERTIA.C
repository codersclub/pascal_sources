/*
�����������������������������������������������������������������������������
                   Inertia/32 Realtime 3D Rendering Engine
     Copyright (c) 1996, Alex Chalfin, Jeroen Bouwens. All Rights Reserved.
           DISTRIBUTION OF THIS SOURCE CODE IS STRICTLY PROHIBITED
�����������������������������������������������������������������������������
*/
#include "inertia.h"
#include "polygon.h"
#include "cull.h"
#include "shade.h"
#include "xform.h"
#include "pcx.h"
#include "matrix.h"
#include "clip.h"
#include "pool.h"

#ifdef __USE_GLIDE__
#include <glide.h>
#endif

/* global variables */
ShaderFunction   Shaders[256];
TriangleFiller   TriFillers[256];
float            AspectRatio;
tLightList       Lights;
Palette          GlobalPalette;
char             *IntensityTable;
char             *TransparencyTable;
tRenderList      RenderList;
TextureRec       TextureList[MAXTEXTURES];
int              GlideFlag = 0;

/*=========================================================================*
  InitInertia
 *=========================================================================*/
void InitInertia()
{
  Shaders[AMBIENT]  = ShadeAmbient;
  Shaders[LAMBERT]  = ShadeLambert;
  Shaders[GOURAUD]  = ShadeGouraud;
  Shaders[PHONG]    = ReflectionMap;
  Shaders[UNSHADED] = ShadeNull;

  TriFillers[UNSHADED | SMOOTH] = UnshadedPolygon;
  TriFillers[AMBIENT  | SMOOTH] = AmbientPolygon;
  TriFillers[LAMBERT  | SMOOTH] = LambertPolygon;
  TriFillers[GOURAUD  | SMOOTH] = GouraudPolygon;
  TriFillers[PHONG    | SMOOTH] = PhongPolygon;

  TriFillers[UNSHADED | TEXTURE] = UnshadedTexturePolygon;
  TriFillers[AMBIENT  | TEXTURE] = AmbientTexturePolygon;
  TriFillers[LAMBERT  | TEXTURE] = LambertTexturePolygon;
  TriFillers[GOURAUD  | TEXTURE] = GouraudTexturePolygon;
  TriFillers[PHONG    | TEXTURE] = PhongTexturePolygon;

  TriFillers[UNSHADED | PERSPTEXTURE] = UnshadedPerspTexturePolygon;
  TriFillers[AMBIENT  | PERSPTEXTURE] = AmbientPerspTexturePolygon;
  TriFillers[LAMBERT  | PERSPTEXTURE] = LambertPerspTexturePolygon;
  TriFillers[GOURAUD  | PERSPTEXTURE] = GouraudPerspTexturePolygon;
  TriFillers[PHONG    | PERSPTEXTURE] = PhongPerspTexturePolygon;

  TriFillers[UNSHADED | REFLECTION] = UnshadedReflectionPolygon;
  TriFillers[AMBIENT  | REFLECTION] = AmbientReflectionPolygon;
  TriFillers[LAMBERT  | REFLECTION] = LambertReflectionPolygon;
  TriFillers[GOURAUD  | REFLECTION] = GouraudReflectionPolygon;
  TriFillers[PHONG    | REFLECTION] = PhongReflectionPolygon;

  TriFillers[TRANSPARENT | UNSHADED | SMOOTH] = TransUnshadedPolygon;
  TriFillers[TRANSPARENT | AMBIENT | SMOOTH] = TransAmbientPolygon;
  TriFillers[TRANSPARENT | LAMBERT | SMOOTH] = TransLambertPolygon;
  TriFillers[TRANSPARENT | GOURAUD | SMOOTH] = TransGouraudPolygon;
  TriFillers[TRANSPARENT | PHONG   | SMOOTH] = TransPhongPolygon;

  TriFillers[TRANSPARENT | UNSHADED | TEXTURE] = TransUnshadedTexturePolygon;
  TriFillers[TRANSPARENT | AMBIENT | TEXTURE] = TransAmbientTexturePolygon;
  TriFillers[TRANSPARENT | LAMBERT | TEXTURE] = TransLambertTexturePolygon;
  TriFillers[TRANSPARENT | GOURAUD | TEXTURE] = TransGouraudTexturePolygon;
  TriFillers[TRANSPARENT | PHONG   | TEXTURE] = TransPhongTexturePolygon;

  TriFillers[TRANSPARENT | UNSHADED | PERSPTEXTURE] = TransUnshadedPerspTexturePolygon;
  TriFillers[TRANSPARENT | AMBIENT  | PERSPTEXTURE] = TransAmbientPerspTexturePolygon;
  TriFillers[TRANSPARENT | LAMBERT  | PERSPTEXTURE] = TransLambertPerspTexturePolygon;
  TriFillers[TRANSPARENT | GOURAUD  | PERSPTEXTURE] = TransGouraudPerspTexturePolygon;
  TriFillers[TRANSPARENT | PHONG    | PERSPTEXTURE] = TransPhongPerspTexturePolygon;


  TriFillers[TRANSPARENT | UNSHADED | REFLECTION] = TransUnshadedReflectionPolygon;
  TriFillers[TRANSPARENT | AMBIENT | REFLECTION] = TransAmbientReflectionPolygon;
  TriFillers[TRANSPARENT | LAMBERT | REFLECTION] = TransLambertReflectionPolygon;
  TriFillers[TRANSPARENT | GOURAUD | REFLECTION] = TransGouraudReflectionPolygon;
  TriFillers[TRANSPARENT | PHONG   | REFLECTION] = TransPhongReflectionPolygon;

  AspectRatio = 1.2 / 1.33333;

  memset(GlobalPalette, 0, sizeof(GlobalPalette));

  IntensityTable    = NULL;
  TransparencyTable = NULL;

  RenderList.SortList  = NULL;
  RenderList.Allocated = 0;
  RenderList.Count     = 0;

  Lights.NumLights     = 0;

  InitVertexPool();
  InitPolygonPool();
}

/*=========================================================================*
  ShutDownInertia
 *=========================================================================*/
void ShutDownInertia()
{
  if (RenderList.SortList != NULL)
    free(RenderList.SortList);

  FreeVertexPool();
  FreePolygonPool();
}

/*=========================================================================*
  InitVectorObject
 *=========================================================================*/
void InitVectorObject(VectorObject *Obj)
{
  Obj->NumVert      = 0;
  Obj->NumPoly      = 0;
  Obj->Vertexs      = NULL;
  Obj->Polygons     = NULL;

  Obj->Cull         = 1;
  Obj->RenderMask   = AMBIENT | SMOOTH;
  Obj->Radius       = 0;
  Obj->CorrectCount = 0;

  InitMatrix(Obj->Orientation);
}

/*=========================================================================*
  AllocObject
 *=========================================================================*/
int AllocObject(VectorObject *Obj, int NumVert, int NumPoly)
{
  InitVectorObject(Obj);

  Obj->NumVert = NumVert;
  Obj->NumPoly = NumPoly;

  Obj->Vertexs  = malloc(Obj->NumVert * sizeof(Vertex));
  if (Obj->Vertexs == NULL)
    return(I_MEMERR);

  Obj->Polygons = malloc(Obj->NumPoly * sizeof(Triangle));
  if (Obj->Polygons == NULL)
  {
    free(Obj->Vertexs);
    return(I_MEMERR);
  }

  return(I_OK);
}

/*=========================================================================*
  FreeVectorObject
 *=========================================================================*/
void FreeVectorObject(VectorObject *Obj)
{
  if (Obj->Vertexs  != NULL) free(Obj->Vertexs);
  if (Obj->Polygons != NULL) free(Obj->Polygons);

  Obj->NumVert = 0;
  Obj->NumPoly = 0;
  Obj->Radius  = 0;
}

/*=========================================================================*
  CopyVectoeObject
 *=========================================================================*/
int CopyVectorObject(VectorObject *Source, VectorObject *Dest)
{
  int i, j;

  if (AllocObject(Dest, Source->NumVert, Source->NumPoly) != I_OK)
    return(I_MEMERR);

  for (i = 0; i < Source->NumVert; i++)
  {
    Dest->Vertexs[i].Loc.x = Source->Vertexs[i].Loc.x;
    Dest->Vertexs[i].Loc.y = Source->Vertexs[i].Loc.y;
    Dest->Vertexs[i].Loc.z = Source->Vertexs[i].Loc.z;

    Dest->Vertexs[i].N.x = Source->Vertexs[i].N.x;
    Dest->Vertexs[i].N.y = Source->Vertexs[i].N.y;
    Dest->Vertexs[i].N.z = Source->Vertexs[i].N.z;
  }

  for (i = 0; i < Source->NumPoly; i++)
  {
    Dest->Polygons[i].N.x = Source->Polygons[i].N.x;
    Dest->Polygons[i].N.y = Source->Polygons[i].N.y;
    Dest->Polygons[i].N.z = Source->Polygons[i].N.z;

    Dest->Polygons[i].UV1.x = Source->Polygons[i].UV1.x;
    Dest->Polygons[i].UV1.y = Source->Polygons[i].UV1.y;
    Dest->Polygons[i].UV2.x = Source->Polygons[i].UV2.x;
    Dest->Polygons[i].UV2.y = Source->Polygons[i].UV2.y;
    Dest->Polygons[i].UV3.x = Source->Polygons[i].UV3.x;
    Dest->Polygons[i].UV3.y = Source->Polygons[i].UV3.y;

    Dest->Polygons[i].Texture = Source->Polygons[i].Texture;
    Dest->Polygons[i].IBuffer = Source->Polygons[i].IBuffer;

    Dest->Polygons[i].Color = Source->Polygons[i].Color;

    for (j = 0; j < Source->NumVert; j++)
    {
      if (&Source->Vertexs[j] == Source->Polygons[i].A)
        Dest->Polygons[i].A = &Dest->Vertexs[j];

      if (&Source->Vertexs[j] == Source->Polygons[i].B)
        Dest->Polygons[i].B = &Dest->Vertexs[j];

      if (&Source->Vertexs[j] == Source->Polygons[i].C)
        Dest->Polygons[i].C = &Dest->Vertexs[j];
    }
  }

  MatrixCopy(Source->Orientation, Dest->Orientation);

  Dest->RenderMask   = Source->RenderMask;
  Dest->Radius       = Source->Radius;
  Dest->CorrectCount = Source->CorrectCount;
  Dest->ClipMask     = Source->ClipMask;
  Dest->Cull         = Source->Cull;

  return(I_OK);
}

/*=========================================================================*
  CalcBoundaryVolume
 *=========================================================================*/
void CalcBoundaryVolume(VectorObject *Obj)
{
  float Error;
  float Temp;
  float x, y, z;
  int   i;

  if (Obj->NumVert == 0) return;

  Error = 0;
  for (i = 0; i < Obj->NumVert; i++)
    {
      x = Obj->Vertexs[i].Loc.x;
      y = Obj->Vertexs[i].Loc.y;
      z = Obj->Vertexs[i].Loc.z;

      Temp = SQR(x) + SQR(y) + SQR(z);

      if (Temp > Error) Error = Temp;
    }

  Obj->Radius = sqrt(Error);
}

/*=========================================================================*
  LoadGVO
 *=========================================================================*/
int LoadGVO(VectorObject *Obj, char *Filename, int FOfs)
{
  FILE      *fp;
  char      GVOTag[3];
  short int Flag;
  short int ShortInt;
  short int DiskPos;
  int       i;
  char      TempChar;

  InitVectorObject(Obj);

  fp = fopen(Filename, "rb");

  if (fp == NULL)
    return(I_FILEERR);

  fseek(fp, FOfs, SEEK_SET);

  fread(GVOTag, sizeof(GVOTag), 1, fp);
  if ((GVOTag[0] != 'G') && (GVOTag[1] != 'V') && (GVOTag[2] != 'O'))
    {
      fclose(fp);
      return(I_FORMATERR);
    }

  fread(&Flag, sizeof(Flag), 1, fp);

  if (((Flag & 0x01) != 0) && ((Flag & 0x02) != 0))
    {
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->NumVert = ShortInt;
      DiskPos = ftell(fp);
      fseek(fp, DiskPos + (Obj->NumVert * 6), SEEK_SET);
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->NumPoly = ShortInt;
      fseek(fp, DiskPos, SEEK_SET);
    }
  else
    {
      fclose(fp);
      return(I_FILEERR);
    }

  if (AllocObject(Obj, Obj->NumVert, Obj->NumPoly) != I_OK)
  {
    fclose(fp);
    return(I_MEMERR);
  }

  if ((Flag & 1) != 0)
  {
    for (i = 0; i < Obj->NumVert; i++)
    {
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->Vertexs[i].Loc.x = ShortInt;
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->Vertexs[i].Loc.y = ShortInt;
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->Vertexs[i].Loc.z = ShortInt;
    }
  }

  if ((Flag & 2) != 0)
  {
    fread(&ShortInt, sizeof(ShortInt), 1, fp);
    for (i = 0; i < Obj->NumPoly; i++)
    {
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->Polygons[i].A = &(Obj->Vertexs[ShortInt]);
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->Polygons[i].B = &(Obj->Vertexs[ShortInt]);
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->Polygons[i].C = &(Obj->Vertexs[ShortInt]);
    }
  }

  if ((Flag & 4) != 0)
  {
    for (i = 0; i < Obj->NumPoly; i++)
    {
      fread(&ShortInt, sizeof(ShortInt), 1, fp);

      Obj->Polygons[i].N.x = (float)ShortInt / 256.0;
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->Polygons[i].N.y = (float)ShortInt / 256.0;
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->Polygons[i].N.z = (float)ShortInt / 256.0;
    }
  }

  if ((Flag & 8) != 0)
  {
    for (i = 0; i < Obj->NumVert; i++)
    {
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->Vertexs[i].N.x = (float)ShortInt / 256.0;
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->Vertexs[i].N.y = (float)ShortInt / 256.0;
      fread(&ShortInt, sizeof(ShortInt), 1, fp);
      Obj->Vertexs[i].N.z = (float)ShortInt / 256.0;
    }
  }

  if ((Flag & 16) != 0)
  {
    for (i = 0; i < Obj->NumPoly; i++)
    {
      fread(&TempChar, sizeof(TempChar), 1, fp);
      Obj->Polygons[i].UV1.x = (float)TempChar / 255.0;
      fread(&TempChar, sizeof(TempChar), 1, fp);
      Obj->Polygons[i].UV1.y = (float)TempChar / 255.0;

      fread(&TempChar, sizeof(TempChar), 1, fp);
      Obj->Polygons[i].UV2.x = (float)TempChar / 255.0;
      fread(&TempChar, sizeof(TempChar), 1, fp);
      Obj->Polygons[i].UV2.y = (float)TempChar / 255.0;

      fread(&TempChar, sizeof(TempChar), 1, fp);
      Obj->Polygons[i].UV3.x = (float)TempChar / 255.0;
      fread(&TempChar, sizeof(TempChar), 1, fp);
      Obj->Polygons[i].UV3.y = (float)TempChar / 255.0;
    }
  }

  fclose(fp);

  CalcBoundaryVolume(Obj);
  return(I_OK);
}

/*=========================================================================*
  SetAbsoluteRotation
 *=========================================================================*/
void SetAbsoluteRotation(VectorObject *Obj, float rx, float ry, float rz)
{
  SetRotationMatrix(Obj->Orientation, rx, ry, rz);
  Obj->CorrectCount = 0;
}

/*=========================================================================*
  SetDeltaRotation
 *=========================================================================*/
void SetDeltaRotation(VectorObject *Obj, float dx, float dy, float dz)
{
  Matrix4x3  TempMat;
  Matrix4x3  TempMat2;

  SetRotationMatrix(TempMat, dx, dy, dz);
  MatrixCopy(Obj->Orientation, TempMat2);
  MatrixMul(Obj->Orientation, TempMat, TempMat2);

  Obj->CorrectCount++;

  if (Obj->CorrectCount >= CORRECTRES)
  {
    MatrixOrthoNormalize(Obj->Orientation);
    Obj->CorrectCount = 0;
  }
}

/*=========================================================================*
  SetAbsoluteLocation
 *=========================================================================*/
void SetAbsoluteLocation(VectorObject *Obj, float tx, float ty, float tz)
{
  Obj->Orientation[XLOC] = tx;
  Obj->Orientation[YLOC] = ty;
  Obj->Orientation[ZLOC] = tz;
}

/*=========================================================================*
  SetDeltaLocation
 *=========================================================================*/
void SetDeltaLocation(VectorObject *Obj, float dx, float dy, float dz)
{
  Obj->Orientation[XLOC] += dx;
  Obj->Orientation[YLOC] += dy;
  Obj->Orientation[ZLOC] += dz;
}

/*=========================================================================*
  SetBaseColor
 *=========================================================================*/
void SetBaseColor(VectorObject *Obj, char C)
{
  int i;

  for (i = 0; i < Obj->NumPoly; i++)
    Obj->Polygons[i].Color = C;
}

/*=========================================================================*
  SetPolygonColor
 *=========================================================================*/
void SetPolygonColor(VectorObject *Obj, int Poly, char C)
{
  Obj->Polygons[Poly].Color = C;
}

/*=========================================================================*
  SetObjectTexture
 *=========================================================================*/
void SetObjectTexture(VectorObject *Obj, int C)
{
  int i;

  for (i = 0; i < Obj->NumPoly; i++)
    Obj->Polygons[i].Texture = TextureList[C].Texture;
}

/*=========================================================================*
  SetPolygonTexture
 *=========================================================================*/
void SetPolygonTexture(VectorObject *Obj, int Poly, int C)
{
  Obj->Polygons[Poly].Texture = TextureList[C].Texture;
}

/*=========================================================================*
  SetObjectPhongMap
 *=========================================================================*/
void SetObjectPhongMap(VectorObject *Obj, int C)
{
  int i;

  for (i = 0; i < Obj->NumPoly; i++)
    Obj->Polygons[i].IBuffer = TextureList[C].Texture;
}

/*=========================================================================*
  SetPolygonPhongMap
 *=========================================================================*/
void SetPolygonPhongMap(VectorObject *Obj, int Poly, int C)
{
  Obj->Polygons[Poly].IBuffer = TextureList[C].Texture;
}

/*=========================================================================*
  SetRenderMask
 *=========================================================================*/
void SetRenderMask(VectorObject *Obj, int Mask)
{
  Obj->RenderMask = Mask;
  Obj->ClipMask   = 0;

  switch (Obj->RenderMask & SURFACE_MASK)
  {
    case TEXTURE      : Obj->ClipMask |= CLIP_TEXTURE;  break;
    case PERSPTEXTURE : Obj->ClipMask |= CLIP_TEXTURE;  break;
    case REFLECTION   : Obj->ClipMask |= CLIP_ENV;  break;
  }

#ifdef __USE_GLIDE__
  if ((Obj->RenderMask & SHADE_MASK) == PHONG)
    Obj->RenderMask = (Obj->RenderMask & ~SHADE_MASK) | GOURAUD;
#endif

  switch (Obj->RenderMask & SHADE_MASK)
  {
    case GOURAUD : Obj->ClipMask |= CLIP_GOURAUD;  break;
    case PHONG   : Obj->ClipMask |= CLIP_ENV;      break;
  }
}

/*=========================================================================*
  SetCull
 *=========================================================================*/
void SetCull(VectorObject *Obj, int Cull)
{
  Obj->Cull = Cull;
}

/*=========================================================================*
  SetAspectRatio
 *=========================================================================*/
void SetAspectRatio(float ARatio)
{
  AspectRatio = ARatio;
}

/*=========================================================================*
  SetFocalLength
 *=========================================================================*/
void SetFocalLength(ViewObject *View, float fl)
{
  View->FocalLength = fl;
  SetFieldOfView(View, (15.0 / fl) * 160.0);
}

/*=========================================================================*
  SetFieldOfView
 *=========================================================================*/
void SetFieldOfView(ViewObject *View, float FOV)
{
  View->FieldOfView = FOV;
  View->CamZFac     = tan(DEG2RAD(View->FieldOfView / 2.0));
  View->InvCamZFac  = 1.0 / View->CamZFac;
}

/*=========================================================================*
  InitView
 *=========================================================================*/
void InitView(ViewObject *View)
{
  SetViewPort(View, 0, 0, 319, 199, 1);
  InitMatrix(View->Camera);

  SetFieldOfView(View, 65);

  SetViewFustrum(View, 1.0, 100000.0);
}

/*=========================================================================*
  FreeView
 *=========================================================================*/
void FreeView(ViewObject *View)
{
}

/*=========================================================================*
  GetObjectAsCamera
 *=========================================================================*/
void GetObjectAsCamera(ViewObject *View, VectorObject *Obj)
{
  MatrixCopy(View->Camera, Obj->Orientation);
}

/*=========================================================================*
  SetViewFustrum
 *=========================================================================*/
void SetViewFustrum(ViewObject *View, float MinZ, float MaxZ)
{
  View->FustrumMinZ   = MinZ;
  View->FustrumMaxZ   = MaxZ;
}

/*=========================================================================*
  SetViewPort
 *=========================================================================*/
void SetViewPort(ViewObject *View, float X1, float Y1, float X2, float Y2, char Update)
{
  float Temp;

  if (X1 > X2) SWAP(X1, X2, Temp);
  if (Y1 > Y2) SWAP(Y1, Y2, Temp);

  View->WinMinX = X1;
  View->WinMinY = Y1;
  View->WinMaxX = X2;
  View->WinMaxY = Y2;

  View->CamYFac    = ((X2 - X1 + 1) / (Y2 - Y1 + 1)) * AspectRatio;
  View->InvCamYFac = 1.0 / View->CamYFac;

  if (Update)
  {
    View->CenterX = (float)(X2 + X1) / 2.0;
    View->CenterY = (float)(Y2 + Y1) / 2.0;
  }
}

/*=========================================================================*
  SetViewLocation
 *=========================================================================*/
void SetViewLocation(ViewObject *View, float X, float Y, float Z)
{
  View->Camera[XLOC] = X;
  View->Camera[YLOC] = Y;
  View->Camera[ZLOC] = Z;
}

/*=========================================================================*
  SetFocusPoint
 *=========================================================================*/
void SetFocusPoint(ViewObject *View, float TargetX, float TargetY, float TargetZ, float Roll)
{
  Matrix4x3 ViewMat;
  Matrix4x3 RollMat;
  float zx, zy, zz;
  float yx, yy, yz;
  float xx, xy, xz;
  float gx, gy, gz;
  float Len;

  zx = TargetX - View->Camera[XLOC];
  zy = TargetY - View->Camera[YLOC];
  zz = TargetZ - View->Camera[ZLOC];

  if ((zx == 0) && (zy == 0) && (zz == 0)) return;

  Len = sqrt(SQR(zx) + SQR(zy) + SQR(zz));

  zx = (zx/Len);
  zy = (zy/Len);
  zz = (zz/Len);

  if ((zx == 0) && (zz == 0))
  {
    gx = -zy;
    gy = 0;
    gz = 0;
  }
  else
  {
    gx = 0;
    gy = -1;
    gz = 0;
  }

  /* cross G vector with Z vector */
  xx = gy*zz - gz*zy;
  xy = gz*zx - gx*zz;
  xz = gx*zy - gy*zx;
  Len = sqrt(SQR(xx) + SQR(xy) + SQR(xz));
  xx = xx/Len;
  xy = xy/Len;
  xz = xz/Len;

  yx = xy*zz - xz*zy;
  yy = xz*zx - xx*zz;
  yz = xx*zy - xy*zx;
  Len = sqrt(SQR(yx) + SQR(yy) + SQR(yz));
  yx = yx/Len;
  yy = yy/Len;
  yz = yz/Len;

  ViewMat[0] = xx;
  ViewMat[3] = xy;
  ViewMat[6] = xz;
  ViewMat[1] = yx;
  ViewMat[4] = yy;
  ViewMat[7] = yz;
  ViewMat[2] = zx;
  ViewMat[5] = zy;
  ViewMat[8] = zz;

  /* Note: this can be made a bit faster using dedicated z-rotation formulation */
  SetRotationMatrix(RollMat, 0, 0, Roll);

  /* Note: This multiplication can be made faster using a dedicated multiplier */
  MatrixMul(View->Camera, ViewMat, RollMat);
}

/*=========================================================================*
  PushLightSource
 *=========================================================================*/
void PushLightSource(float X, float Y, float Z)
{
  int   Index;
  float Len;
  Index = Lights.NumLights;

  Len = 1.0 / sqrt(SQR(X) + SQR(Y) + SQR(Z));

  Lights.Light[Index].x = X * Len;
  Lights.Light[Index].y = Y * Len;
  Lights.Light[Index].z = Z * Len;

  Lights.NumLights++;
}

/*=========================================================================*
  PopLightSource
 *=========================================================================*/
void PopLightSource()
{
  if (Lights.NumLights > 0)
    Lights.NumLights--;
}

/*=========================================================================*
  RotateLightSource
 *=========================================================================*/
void RotateLightSource(int Index, float Xa, float Ya, float Za)
{
  SingleRotate(&Lights.Light[Index], Xa, Ya, Za);
}

/*=========================================================================*
  ByteSort
 *=========================================================================*/
void ByteSort()
{
  int Index, i;
  SortRec *TempPtr;

  for (i = 0; i < 256; i++)
  {
    RenderList.LSBList[i] = NULL;
    RenderList.MSBList[i] = NULL;
  }

  for (i = 0; i < RenderList.Count; i++)
  {
    Index = RenderList.SortList[i].ZMid & 0xff;
    RenderList.SortList[i].Next = RenderList.LSBList[Index];
    RenderList.LSBList[Index] = &(RenderList.SortList[i]);
  }

  for (i = 0; i < 256; i++)
  {
    while (RenderList.LSBList[i] != NULL)
    {
      Index   = (RenderList.LSBList[i]->ZMid >> 8) & 0xff;
      TempPtr = RenderList.MSBList[Index];
      RenderList.MSBList[Index] = RenderList.LSBList[i];
      RenderList.LSBList[i] = RenderList.LSBList[i]->Next;
      RenderList.MSBList[Index]->Next = TempPtr;
    }
  }
}

/*=========================================================================*
  Render
 *=========================================================================*/
void Render(char *VPage, int x, int y)
{
  int  i;

  ByteSort();

  for (i = 255; i >= 0; i--)
    {
      while (RenderList.MSBList[i] != NULL)
      {
        TriFillers[RenderList.MSBList[i]->ShadeSurface](RenderList.MSBList[i]->Poly, VPage, x, y);
        RenderList.MSBList[i] = RenderList.MSBList[i]->Next;
      }
    }

  RenderList.Count = 0;
  ResetVertexPool();
  ResetPolygonPool();
}

/*=========================================================================*
  ObjectVisible
 *=========================================================================*/
int ObjectVisible(ViewObject *View, VectorObject *Obj, float *M, float Dot)
{
  float box_x1, box_x2;
  float box_y1, box_y2;
  float box_z1, box_z2;

  Obj->ClipMask &= CLIP_SHADEMASK;

  /* build a basic bounding box */
  box_z1 = (M[ZLOC] - Obj->Radius) * View->CamZFac;
  box_z2 = (M[ZLOC] + Obj->Radius) * View->CamZFac;
  box_x1 = M[XLOC] - Obj->Radius;
  box_x2 = M[XLOC] + Obj->Radius;
  box_y1 = (M[YLOC] - Obj->Radius) * View->CamYFac;
  box_y2 = (M[YLOC] + Obj->Radius) * View->CamYFac;

  /* complete rejection tests */
  if ((box_x2 < -box_z1) && (box_x2 < -box_z2))
    return(0);

  if ((box_x1 > box_z1)  && (box_x1 > box_z2))
    return(0);

  if ((box_y2 < -box_z1) && (box_y2 < -box_z2))
    return(0);

  if ((box_y1 > box_z1)  && (box_y1 > box_z2))
    return(0);

  if ((M[ZLOC] + (Obj->Radius * View->CamZFac)) < View->FustrumMinZ)
    return(0);

  /* clipping tests */

  if (box_z1 < View->FustrumMinZ)
    Obj->ClipMask |= CLIP_Z;

  if (box_x1 < -box_z1)
    Obj->ClipMask |= CLIP_LEFT;

  if (box_x2 > box_z1)
    Obj->ClipMask |= CLIP_RIGHT;

  if (box_y1 < -box_z1)
    Obj->ClipMask |= CLIP_BOTTOM;

  if (box_y2 > box_z1)
    Obj->ClipMask |= CLIP_TOP;

  return(1);
}

/*=========================================================================*
  AddToRenderList
 *=========================================================================*/
void AddToRenderList(ViewObject *View, VectorObject *Obj)
{
  Vertex3d  CullVector;
  Vertex3d  TempVec;
  Vertex3d  FustrumZ;
  Matrix4x3 TempMat;
  Matrix4x3 ScaleMat;
  Matrix4x3 TempCamera;
  int       i;
  Vertex    *V;
  Triangle  *P;
  float     Dot;

  TempVec.x = Obj->Orientation[XLOC] - View->Camera[XLOC];
  TempVec.y = Obj->Orientation[YLOC] - View->Camera[YLOC];
  TempVec.z = Obj->Orientation[ZLOC] - View->Camera[ZLOC];

  FustrumZ.x = View->Camera[2];
  FustrumZ.y = View->Camera[5];
  FustrumZ.z = View->Camera[8];

  Dot = DOTPRODUCT(TempVec, FustrumZ);

  TempMat[XLOC] = View->Camera[0] * TempVec.x + View->Camera[3] * TempVec.y + View->Camera[6] * TempVec.z;
  TempMat[YLOC] = View->Camera[1] * TempVec.x + View->Camera[4] * TempVec.y + View->Camera[7] * TempVec.z;
  TempMat[ZLOC] = View->Camera[2] * TempVec.x + View->Camera[5] * TempVec.y + View->Camera[8] * TempVec.z;

  if (!ObjectVisible(View, Obj, TempMat, Dot)) return;

  MatrixMul(TempMat, View->Camera, Obj->Orientation);

  CullVector.x = -TempMat[XLOC] * View->InvCamZFac;
  CullVector.y = -TempMat[YLOC] * View->InvCamZFac;
  CullVector.z = -TempMat[ZLOC] * View->InvCamZFac;

  /* If culling vector is zero, use the z-axis vector */
  /* in rotation matrix to perform culling            */
  if ((CullVector.x == 0) && (CullVector.y == 0) && (CullVector.z == 0))
  {
    CullVector.x = -TempMat[2];
    CullVector.y = -TempMat[5];
    CullVector.z = -TempMat[8];
  }
  else
  {
    InvXForm(&CullVector, TempMat);
  }

  /* Inversely transform the light positions */
  for (i = 0; i < Lights.NumLights; i++)
  {
    Lights.TempLight[i].x = Lights.Light[i].x;
    Lights.TempLight[i].y = Lights.Light[i].y;
    Lights.TempLight[i].z = Lights.Light[i].z;

    InvXForm(&Lights.TempLight[i], Obj->Orientation);
  }

  if (Obj->Cull)
  {
    for (i = 0, V = Obj->Vertexs;  i < Obj->NumVert; i++, V++) V->Visible = 0;
    CullPolys(Obj, &CullVector);
  }
  else
  {
    for (i = 0, V = Obj->Vertexs;  i < Obj->NumVert; i++, V++) V->Visible = 1;
    for (i = 0, P = Obj->Polygons; i < Obj->NumPoly; i++, P++) P->Visible = 1;
  }

  SetScaleMatrix(ScaleMat, 1.0, View->CamYFac, View->CamZFac);
  MatrixCopy(TempMat,   TempCamera);
  MatrixMul(TempCamera, TempMat, ScaleMat);

  ShadeXForm(View, Obj, TempCamera);
}

/*=========================================================================*
  LoadIntensityTable
 *=========================================================================*/
int LoadIntensityTable(char *Filename, int FOfs)
{
  FILE *fp;
  int  i;

  IntensityTable = (char *)malloc(256*64);
  if (IntensityTable == NULL)
    return(I_MEMERR);

  fp = fopen(Filename, "rb");
  if (fp == NULL)
  {
    free(IntensityTable);
    return(I_FILEERR);
  }

  fseek(fp, FOfs, SEEK_SET);

  for (i = 63; i >= 0; i--)
    fread(&IntensityTable[i*256], 256, 1, fp);

  fclose(fp);
  return(I_OK);
}

/*=========================================================================*
  FreeIntensityTable
 *=========================================================================*/
void FreeIntensityTable()
{
  if (IntensityTable != NULL)
    free(IntensityTable);
}

/*=========================================================================*
  LoadTransparencyTable
 *=========================================================================*/
int LoadTransparencyTable(char *Filename, int FOfs)
{
  FILE *fp;

  TransparencyTable = (char *)malloc(256*256);
  if (TransparencyTable == NULL)
    return(I_MEMERR);

  fp = fopen(Filename, "rb");
  if (fp == NULL)
  {
    free(TransparencyTable);
    return(I_FILEERR);
  }

  fseek(fp, FOfs, SEEK_SET);
  fread(TransparencyTable, 256*256, 1, fp);

  fclose(fp);

  return(I_OK);
}

/*=========================================================================*
  FreeTransparencyTable
 *=========================================================================*/
void FreeTransparencyTable()
{
  if (TransparencyTable != NULL)
    free(TransparencyTable);
}

/*=========================================================================*
  LoadPalette
 *=========================================================================*/
int LoadPalette(char *Filename, int FOfs)
{
  FILE *fp;

  fp = fopen(Filename, "rb");
  if (fp == NULL)
    return(I_FILEERR);

  fread(GlobalPalette, sizeof(GlobalPalette), 1, fp);

  fclose(fp);
  return(I_OK);
}

/*=========================================================================*
  FreeTexture
 *=========================================================================*/
void FreeTexture(int Index)
{
#ifdef __USE_GLIDE__
  if (GlideFlag)
    G_FreeTexture(TextureList[Index].Texture);
#endif

  if (TextureList[Index].Texture != NULL)
    free(TextureList[Index].Texture);
}

/*=========================================================================*
  LoadPCXTexture
 *=========================================================================*/
int LoadPCXTexture(int Index, char *Filename, int FOfs)
{
  int T;
  int RetCode;

  RetCode = LoadPCXFile(Filename, &TextureList[Index].Texture, (char *)TextureList[Index].Pal, &T, FOfs);

  if (RetCode == 0)
    return(I_OK);
  else
    return(I_FILEERR);
}

/*=========================================================================*
  GetTexturePalette
 *=========================================================================*/
void GetTexturePalette(int Index)
{
  memcpy(GlobalPalette, TextureList[Index].Pal, sizeof(GlobalPalette));
}

/*=========================================================================*
  MakePhongMap
 *=========================================================================*/
int MakePhongMap(int Index)
{
  int   t, x, y;
  float tx, ty;
  char  *Adr;

  TextureList[Index].Texture = malloc(256 * 256);
  if (TextureList[Index].Texture == NULL)
    return(I_MEMERR);

  Adr = TextureList[Index].Texture;

  for (y = 0; y < 256; y++)
    for (x = 0; x < 256; x++)
      {
        tx = 127.5 - (float)x;
        ty = 127.5 - (float)y;
        t  = CLIP(sqrt(SQR(tx) + SQR(ty)) / 2.0, 0, 63);
        *Adr++ = 63 - t;
      }

  return(I_OK);
}


