/*
�����������������������������������������������������������������������������
                       Inerita Realtime 3D Rendering Engine
            Copyright (c) 1997, Alex Chalfin. All Rights Reserved.
           DISTRIBUTION OF THIS SOURCE CODE IS STRICTLY PROHIBITED
�����������������������������������������������������������������������������
*/
#include "matrix.h"

void MatrixCopy(float *Source, float *Dest)
{
  memcpy(Dest, Source, sizeof(Matrix4x3));
}

void InitMatrix(float *M)
{
  memset(M, 0, sizeof(Matrix4x3));
  M[0] = 1.0; M[4] = 1.0; M[8] = 1.0;
}

void SetRotationMatrix(float *M, float xa, float ya, float za)
{
  float sx, sy, sz;
  float cx, cy, cz;

  sx = sin(xa); sy = sin(ya); sz = sin(za);
  cx = cos(xa); cy = cos(ya); cz = cos(za);

  M[0] = (cz * cy) + (sx * sz * sy);
  M[3] = (cy * -sz) + (cz * sx * sy);
  M[6] = (cx * sy);
  M[1] = (sz * cx);
  M[4] = (cz * cx);
  M[7] = (-sx);
  M[2] = (-sy * cz) + (sz * sx * cy);
  M[5] = (sz * sy) + (cz * sx * cy);
  M[8] = (cx * cy);
}

void SetScaleMatrix(float *M, float sx, float sy, float sz)
{
  memset(M, 0, sizeof(Matrix4x3));

  M[0] = sx; M[4] = sy; M[8] = sz;
}

void MatrixMul(float *Result, float *A, float *B)
{
  Result[0] = (A[0] * B[0]) + (A[1] * B[3]) + (A[2] * B[6]);
  Result[1] = (A[0] * B[1]) + (A[1] * B[4]) + (A[2] * B[7]);
  Result[2] = (A[0] * B[2]) + (A[1] * B[5]) + (A[2] * B[8]);

  Result[3] = (A[3] * B[0]) + (A[4] * B[3]) + (A[5] * B[6]);
  Result[4] = (A[3] * B[1]) + (A[4] * B[4]) + (A[5] * B[7]);
  Result[5] = (A[3] * B[2]) + (A[4] * B[5]) + (A[5] * B[8]);

  Result[6] = (A[6] * B[0]) + (A[7] * B[3]) + (A[8] * B[6]);
  Result[7] = (A[6] * B[1]) + (A[7] * B[4]) + (A[8] * B[7]);
  Result[8] = (A[6] * B[2]) + (A[7] * B[5]) + (A[8] * B[8]);
}

void MatrixOrthoNormalize(float *M)
{
  float dot1, dot2;
  float len;

  dot1 = M[0] * M[1] + M[3] * M[4] + M[6] * M[7];
  dot2 = M[0] * M[2] + M[3] * M[5] + M[6] * M[8];

  M[0] -= dot1 * M[1];
  M[3] -= dot1 * M[4];
  M[6] -= dot1 * M[7];
  M[0] -= dot2 * M[2];
  M[3] -= dot2 * M[5];
  M[6] -= dot2 * M[8];

  len = 1.0 / sqrt(SQR(M[0]) + SQR(M[3]) + SQR(M[6]));

  M[0] *= len;
  M[3] *= len;
  M[6] *= len;

  dot1 = M[1] * M[0] + M[4] * M[3] + M[7] * M[6];
  dot2 = M[1] * M[2] + M[4] * M[5] + M[7] * M[8];

  M[1] -= dot1 * M[0];
  M[4] -= dot1 * M[3];
  M[7] -= dot1 * M[6];
  M[1] -= dot2 * M[2];
  M[4] -= dot2 * M[5];
  M[7] -= dot2 * M[8];

  len = 1.0 / sqrt(SQR(M[1]) + SQR(M[4]) + SQR(M[7]));
  M[1] *= len;
  M[4] *= len;
  M[7] *= len;

  M[2] = M[3] * M[7] - M[6] * M[4];
  M[5] = M[6] * M[1] - M[0] * M[7];
  M[8] = M[0] * M[4] - M[3] * M[1];
}

void AxisRotate(float *M, float angle, float x, float y, float z)
{
  float cosa, sina;
  float dot, dx, dy, dz;
  float rx, ry, rz;
  float cx, cy, cz;
  int   i;

  cosa = cos(angle);
  sina = sin(angle);

  for (i = 0; i < 3; i++)
  {
    dot = (x * M[i+0] + y * M[i+3] + z * M[i+6]);

    dx = dot * x * (1.0 - cosa);
    dy = dot * y * (1.0 - cosa);
    dz = dot * z * (1.0 - cosa);

    rx = M[i+0] * cosa;
    ry = M[i+3] * cosa;
    rz = M[i+6] * cosa;

    cx = (y * M[i+6] - z * M[i+3]) * sina;
    cy = (z * M[i+0] - x * M[i+6]) * sina;
    cz = (x * M[i+3] - y * M[i+0]) * sina;

    M[i+0] = rx + dx + cx;
    M[i+3] = ry + dy + cy;
    M[i+6] = rz + dz + cz;
  }
}
