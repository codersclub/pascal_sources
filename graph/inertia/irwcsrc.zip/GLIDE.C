/*
�����������������������������������������������������������������������������
                   Inertia/32 Realtime 3D Rendering Engine
  Copyright (c) 1996,97  Alex Chalfin, Jeroen Bouwens. All Rights Reserved.
           DISTRIBUTION OF THIS SOURCE CODE IS STRICTLY PROHIBITED
�����������������������������������������������������������������������������
*/

#include "types.h"

#ifdef __USE_GLIDE__

#include "inertia.h"
#include <glide.h>
#include <time.h>

int   PreviousState = -1;

float pAMBIENT   =  0.10;
float pDIFFUSE   =  0.70;
float pSPECULAR  =  0.20;
float pGLOSS     =  75;

#define ROUND_16th(a)  ((float)FLT2INT((a)*16.0) / 16.0)

#define STD_TRI_SETUP                      \
{                                          \
  A.x = ROUND_16th(Poly->A->Scr.x);        \
  A.y = ROUND_16th(Poly->A->Scr.y);        \
  A.oow = Poly->A->OneOverZ;               \
  A.ooz = Poly->A->OneOverZ * 65536;       \
  B.x = ROUND_16th(Poly->B->Scr.x);        \
  B.y = ROUND_16th(Poly->B->Scr.y);        \
  B.oow = Poly->B->OneOverZ;               \
  B.ooz = Poly->B->OneOverZ * 65536;       \
  C.x = ROUND_16th(Poly->C->Scr.x);        \
  C.y = ROUND_16th(Poly->C->Scr.y);        \
  C.oow = Poly->C->OneOverZ;               \
  C.ooz = Poly->C->OneOverZ * 65536;       \
}

#define STD_ENV_SETUP                                               \
{                                                                   \
  A.tmuvtx[GR_TMU0].oow = Poly->A->OneOverZ;                        \
  A.tmuvtx[GR_TMU0].sow = 255 * Poly->A->Env.x * Poly->A->OneOverZ; \
  A.tmuvtx[GR_TMU0].tow = 255 * Poly->A->Env.y * Poly->A->OneOverZ; \
  B.tmuvtx[GR_TMU0].oow = Poly->B->OneOverZ;                        \
  B.tmuvtx[GR_TMU0].sow = 255 * Poly->B->Env.x * Poly->B->OneOverZ; \
  B.tmuvtx[GR_TMU0].tow = 255 * Poly->B->Env.y * Poly->B->OneOverZ; \
  C.tmuvtx[GR_TMU0].oow = Poly->C->OneOverZ;                        \
  C.tmuvtx[GR_TMU0].sow = 255 * Poly->C->Env.x * Poly->C->OneOverZ; \
  C.tmuvtx[GR_TMU0].tow = 255 * Poly->C->Env.y * Poly->C->OneOverZ; \
  G_LoadAndSetTexture(Poly->Texture);                               \
}

#define STD_TEX_SETUP                                               \
{                                                                   \
  A.tmuvtx[GR_TMU0].oow = Poly->A->OneOverZ;                        \
  A.tmuvtx[GR_TMU0].sow = 255 * Poly->UV1.x * Poly->A->OneOverZ;    \
  A.tmuvtx[GR_TMU0].tow = 255 * Poly->UV1.y * Poly->A->OneOverZ;    \
  B.tmuvtx[GR_TMU0].oow = Poly->B->OneOverZ;                        \
  B.tmuvtx[GR_TMU0].sow = 255 * Poly->UV2.x * Poly->B->OneOverZ;    \
  B.tmuvtx[GR_TMU0].tow = 255 * Poly->UV2.y * Poly->B->OneOverZ;    \
  C.tmuvtx[GR_TMU0].oow = Poly->C->OneOverZ;                        \
  C.tmuvtx[GR_TMU0].sow = 255 * Poly->UV3.x * Poly->C->OneOverZ;    \
  C.tmuvtx[GR_TMU0].tow = 255 * Poly->UV3.y * Poly->C->OneOverZ;    \
  G_LoadAndSetTexture(Poly->Texture);                               \
}



typedef struct
{
  int   StartAddress;
  int   Valid;
  int   Time;
  char *Texture;
} GTMemEntry;

GTMemEntry G_TextureMemory[MAXTEXTURES];
int        G_NumTextureSlots;

void G_UnshadedPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_AmbientPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_LambertPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_GouraudPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_PhongPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_UnshadedTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_AmbientTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_LambertTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_GouraudTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_PhongTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_UnshadedPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_AmbientPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_LambertPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_GouraudPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_PhongPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_UnshadedReflectionPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_AmbientReflectionPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_LambertReflectionPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_GouraudReflectionPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_PhongReflectionPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransUnshadedPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransAmbientPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransLambertPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransGouraudPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransPhongPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransUnshadedTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransAmbientTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransLambertTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransGouraudTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransPhongTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransUnshadedPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransAmbientPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransLambertPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransGouraudPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransPhongPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransUnshadedReflectionPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransAmbientReflectionPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransLambertReflectionPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransGouraudReflectionPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TransPhongReflectionPolygon(Triangle *Poly, char *VPage, int x, int y);
void G_TMemInit(int Low, int High);
void G_LoadAndSetTexture(char *Texture);

float GlossTable[1024];

/*=========================================================================*
  G_Flip
 *=========================================================================*/
void G_Flip()
{
  static int Page = GR_BUFFER_BACKBUFFER;

  grBufferSwap(1);  /* swap and wait for retrace */

  if (Page == GR_BUFFER_FRONTBUFFER)
    Page = GR_BUFFER_BACKBUFFER;
  else
    Page = GR_BUFFER_FRONTBUFFER;

  grBufferClear(0, 0, 0);
}

/*=========================================================================*
  G_Flip
 *=========================================================================*/
int G_InitInertia()
{
  GrHwConfiguration    HwConfig;

  /* inertia init */
  InitInertia();

  /* polygon filler init */
  TriFillers[UNSHADED | SMOOTH] = G_UnshadedPolygon;
  TriFillers[AMBIENT  | SMOOTH] = G_AmbientPolygon;
  TriFillers[LAMBERT  | SMOOTH] = G_LambertPolygon;
  TriFillers[GOURAUD  | SMOOTH] = G_GouraudPolygon;
  TriFillers[PHONG    | SMOOTH] = G_PhongPolygon;

  TriFillers[UNSHADED | TEXTURE] = G_UnshadedTexturePolygon;
  TriFillers[AMBIENT  | TEXTURE] = G_AmbientTexturePolygon;
  TriFillers[LAMBERT  | TEXTURE] = G_LambertTexturePolygon;
  TriFillers[GOURAUD  | TEXTURE] = G_GouraudTexturePolygon;
  TriFillers[PHONG    | TEXTURE] = G_PhongTexturePolygon;

  TriFillers[UNSHADED | PERSPTEXTURE] = G_UnshadedPerspTexturePolygon;
  TriFillers[AMBIENT  | PERSPTEXTURE] = G_AmbientPerspTexturePolygon;
  TriFillers[LAMBERT  | PERSPTEXTURE] = G_LambertPerspTexturePolygon;
  TriFillers[GOURAUD  | PERSPTEXTURE] = G_GouraudPerspTexturePolygon;
  TriFillers[PHONG    | PERSPTEXTURE] = G_PhongPerspTexturePolygon;

  TriFillers[UNSHADED | REFLECTION] = G_UnshadedReflectionPolygon;
  TriFillers[AMBIENT  | REFLECTION] = G_AmbientReflectionPolygon;
  TriFillers[LAMBERT  | REFLECTION] = G_LambertReflectionPolygon;
  TriFillers[GOURAUD  | REFLECTION] = G_GouraudReflectionPolygon;
  TriFillers[PHONG    | REFLECTION] = G_PhongReflectionPolygon;

  TriFillers[TRANSPARENT | UNSHADED | SMOOTH] = G_TransUnshadedPolygon;
  TriFillers[TRANSPARENT | AMBIENT | SMOOTH] = G_TransAmbientPolygon;
  TriFillers[TRANSPARENT | LAMBERT | SMOOTH] = G_TransLambertPolygon;
  TriFillers[TRANSPARENT | GOURAUD | SMOOTH] = G_TransGouraudPolygon;
  TriFillers[TRANSPARENT | PHONG   | SMOOTH] = G_TransPhongPolygon;

  TriFillers[TRANSPARENT | UNSHADED | TEXTURE] = G_TransUnshadedTexturePolygon;
  TriFillers[TRANSPARENT | AMBIENT | TEXTURE] = G_TransAmbientTexturePolygon;
  TriFillers[TRANSPARENT | LAMBERT | TEXTURE] = G_TransLambertTexturePolygon;
  TriFillers[TRANSPARENT | GOURAUD | TEXTURE] = G_TransGouraudTexturePolygon;
  TriFillers[TRANSPARENT | PHONG   | TEXTURE] = G_TransPhongTexturePolygon;

  TriFillers[TRANSPARENT | UNSHADED | PERSPTEXTURE] = G_TransUnshadedPerspTexturePolygon;
  TriFillers[TRANSPARENT | AMBIENT  | PERSPTEXTURE] = G_TransAmbientPerspTexturePolygon;
  TriFillers[TRANSPARENT | LAMBERT  | PERSPTEXTURE] = G_TransLambertPerspTexturePolygon;
  TriFillers[TRANSPARENT | GOURAUD  | PERSPTEXTURE] = G_TransGouraudPerspTexturePolygon;
  TriFillers[TRANSPARENT | PHONG    | PERSPTEXTURE] = G_TransPhongPerspTexturePolygon;


  TriFillers[TRANSPARENT | UNSHADED | REFLECTION] = G_TransUnshadedReflectionPolygon;
  TriFillers[TRANSPARENT | AMBIENT | REFLECTION] = G_TransAmbientReflectionPolygon;
  TriFillers[TRANSPARENT | LAMBERT | REFLECTION] = G_TransLambertReflectionPolygon;
  TriFillers[TRANSPARENT | GOURAUD | REFLECTION] = G_TransGouraudReflectionPolygon;
  TriFillers[TRANSPARENT | PHONG   | REFLECTION] = G_TransPhongReflectionPolygon;


  /* glide init */
  grGlideShamelessPlug( FXFALSE );  /* turn off the shameless plug "feature" */

  if (grSstQueryBoards( &HwConfig ) == FXFALSE)
    return( I_MEMERR );

  grGlideInit();

  if (grSstQueryHardware( &HwConfig ) == FXFALSE)
    return( I_MEMERR );

  grSstSelect( 0 );  /* right now Inertia only supports 1 TMU */

  G_TMemInit(grTexMinAddress(GR_TMU0), grTexMaxAddress(GR_TMU0));

  GlideFlag = 1;

  G_Phong( 0.1, 0.7, 0.2, 75 );

  return( I_OK );
}

/*=========================================================================*
  G_SetPalette
 *=========================================================================*/
void G_SetPalette()
{
  GuTexPalette GPalette;
  int i;

  for (i = 0; i < 256; i++)
    {
      GPalette.data[i] = 0xff000000 | ((int)(GlobalPalette[i].r << 2) << 16) |
                    ((int)(GlobalPalette[i].g << 2) << 8) | (GlobalPalette[i].b << 2);
    }

  grTexDownloadTable(GR_TMU0, GR_TEXTABLE_PALETTE, &GPalette);
}

/*=========================================================================*
  G_TMemInit
 *=========================================================================*/
void G_TMemInit(int Low, int High)
{
  int AddressTraverse = Low;

  G_NumTextureSlots = 0;

  while (AddressTraverse < High)
    {
      G_TextureMemory[G_NumTextureSlots].StartAddress = AddressTraverse;
      G_TextureMemory[G_NumTextureSlots].Valid        = 0;
      G_TextureMemory[G_NumTextureSlots].Time         = clock();
      G_TextureMemory[G_NumTextureSlots].Texture      = NULL;

      AddressTraverse += grTexCalcMemRequired(GR_LOD_256, GR_LOD_256,
                                              GR_ASPECT_1x1,
                                              GR_TEXFMT_P_8);
      G_NumTextureSlots++;
    }
}

/*=========================================================================*
  G_Phong
 *=========================================================================*/
void G_Phong(float a, float d, float s, float Gloss)
{
  int i;

  float sum = a + d + s;

  pAMBIENT  = a / sum;
  pDIFFUSE  = d / sum;
  pSPECULAR = s / sum;

  for (i = 0; i < 1024; i++)
    GlossTable[i] = 255 * pow((float)i / 1023.0, Gloss);
}

/*=========================================================================*
  G_OpenWindow
 *=========================================================================*/
int G_OpenWindow()
{

  if (grSstWinOpen(NULL, GR_RESOLUTION_640x480, GR_REFRESH_60Hz,
               GR_COLORFORMAT_ARGB, GR_ORIGIN_UPPER_LEFT, 2, 1) == FXFALSE)
    return(I_MEMERR);

  grRenderBuffer(GR_BUFFER_BACKBUFFER);

  /* set up the zbuffer */
  grDepthBufferMode( GR_DEPTHBUFFER_ZBUFFER );
  grDepthBufferFunction( GR_CMP_GREATER );
  grDepthMask( FXTRUE );
  grBufferClear(0, 0, 0);

  grTexClampMode(GR_TMU0, GR_TEXTURECLAMP_CLAMP, GR_TEXTURECLAMP_CLAMP);
  grTexFilterMode(GR_TMU0, GR_TEXTUREFILTER_BILINEAR, GR_TEXTUREFILTER_BILINEAR);

  /* set the texture combine mode. This is the same for all polygon fillers */
  grTexCombine(GR_TMU0,
               GR_COMBINE_FUNCTION_LOCAL, GR_COMBINE_FACTOR_NONE,
               GR_COMBINE_FUNCTION_LOCAL, GR_COMBINE_FACTOR_NONE,
               FXFALSE, FXFALSE);

  return(I_OK);
}

/*=========================================================================*
  G_Shutdown
 *=========================================================================*/
void G_Shutdown()
{
  grGlideShutdown();

  ShutDownInertia();
}

/*=========================================================================*
  G_FreeTexture
 *=========================================================================*/
void G_FreeTexture(char *Texture)
{
  int i;

  for (i = 0; i < G_NumTextureSlots; i++)
    {
      if (G_TextureMemory[i].Valid && (G_TextureMemory[i].Texture == Texture))
        {
          G_TextureMemory[i].Valid   = 0;
          G_TextureMemory[i].Texture = NULL;
        }
    }
}

/*=========================================================================*
  G_LoadAndSetTexture
 *=========================================================================*/
void G_LoadAndSetTexture(char *Texture)
{
  int i;
  int CurrentTime = clock();
  int Oldest;
  int MatchIndex = -1;
  int TimeMatchIndex;
  static GrTexInfo TexInfo = {GR_LOD_256, GR_LOD_256,
                              GR_ASPECT_1x1,
                              GR_TEXFMT_P_8, NULL};

  /* look and see of the texture is currently in memory */
  for (i = 0; i < G_NumTextureSlots; i++)
    if (G_TextureMemory[i].Valid && (G_TextureMemory[i].Texture == Texture))
      MatchIndex = i;

  /* we found the texture in tmem. Lets use it and point the hardware to it */
  if (MatchIndex >= 0)
    {
      G_TextureMemory[i].Time = CurrentTime;  /* update the access time */
      TexInfo.data = Texture;

      grTexSource(GR_TMU0, G_TextureMemory[MatchIndex].StartAddress,
                  GR_MIPMAPLEVELMASK_BOTH, &TexInfo);
      return;
    }

  Oldest = CurrentTime;
  MatchIndex = -1;

  /* if we made it this far, the texture isn't in tmem */
  for (i = 0; i < G_NumTextureSlots; i++)
    {
      if (!G_TextureMemory[i].Valid)  /* check for an open location */
        {
          MatchIndex = i;
          break;
        }
      if (G_TextureMemory[i].Time < Oldest) /* lets also find the oldest texture */
        {
          TimeMatchIndex = i;
          Oldest = G_TextureMemory[i].Time;
        }
    }

  /* check and see if we found a valid location to load the texture. */
  /* if so, load the texture, update cache stuff, set start address  */
  /* and return.                                                     */
  if (MatchIndex >= 0)
    {
      G_TextureMemory[MatchIndex].Valid   = 1;
      G_TextureMemory[MatchIndex].Time    = CurrentTime;
      G_TextureMemory[MatchIndex].Texture = Texture;

      TexInfo.data = Texture;

      grTexDownloadMipMap(GR_TMU0, G_TextureMemory[MatchIndex].StartAddress,
                          GR_MIPMAPLEVELMASK_BOTH, &TexInfo);
      grTexSource(GR_TMU0, G_TextureMemory[MatchIndex].StartAddress,
                  GR_MIPMAPLEVELMASK_BOTH, &TexInfo);
      return;
    }

  /* if we made it this far, a texture needs to be replaced. */
  /* we will replace the least recently used texture.        */

  G_TextureMemory[TimeMatchIndex].Valid   = 1;
  G_TextureMemory[TimeMatchIndex].Time    = CurrentTime;
  G_TextureMemory[TimeMatchIndex].Texture = Texture;

  TexInfo.data = Texture;

  grTexDownloadMipMap(GR_TMU0, G_TextureMemory[TimeMatchIndex].StartAddress,
                      GR_MIPMAPLEVELMASK_BOTH, &TexInfo);
  grTexSource(GR_TMU0, G_TextureMemory[TimeMatchIndex].StartAddress,
              GR_MIPMAPLEVELMASK_BOTH, &TexInfo);
}


/* static vars used in all polygon fillers */
static GrVertex A;
static GrVertex B;
static GrVertex C;


#include "g_smth.inc"    /* opaque      smooth polygon fills     */
#include "g_tex.inc"     /* opaque      texture polygon fills    */
#include "g_ref.inc"     /* opaque      reflection polygon fills */
#include "g_tsmth.inc"   /* transparent smooth polygon fills     */
#include "g_ttex.inc"    /* transparent texture polygon fills    */
#include "g_tref.inc"    /* transparent reflection polygon fills */

#endif