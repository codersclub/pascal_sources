/*
�����������������������������������������������������������������������������
                       Inertia Realtime 3D Rendering Engine
            Copyright (c) 1997, Alex Chalfin. All Rights Reserved.
           DISTRIBUTION OF THIS SOURCE CODE IS STRICTLY PROHIBITED
�����������������������������������������������������������������������������
*/
#include "shade.h"

int AddPolygonToRenderList(Triangle *P, int FillerIndex, int CalcZMid)
{
  int Index     = RenderList.Count;
  SortRec        *TempPtr;

#ifdef SHAREWARE
  if (Index > MAX_POLYGONS)
    return(0);
#endif

  if (Index >= RenderList.Allocated)
  {
    if (RenderList.Allocated == 0)
      TempPtr = (SortRec *)malloc((RenderList.Allocated + 64) * sizeof(SortRec));
    else
      TempPtr = (SortRec *)realloc(RenderList.SortList, (RenderList.Allocated + 64) * sizeof(SortRec));

    if (TempPtr == NULL)
      return(I_MEMERR);

    RenderList.SortList   = TempPtr;
    RenderList.Allocated += 64;
  }

  RenderList.SortList[Index].ZMid         = FLT2FXD( (P->A->Cam.z + P->B->Cam.z + P->C->Cam.z) * (1.0 / 32767.0) );

  RenderList.SortList[Index].Next         = NULL;
  RenderList.SortList[Index].ShadeSurface = FillerIndex;
  RenderList.SortList[Index].Poly         = P;

  RenderList.Count++;

  return(I_OK);
}

void ShadeNull(ViewObject *View, VectorObject *Obj, float *M)
{
}

void ShadeAmbient(ViewObject *View, VectorObject *Obj, float *M)
{
  int i;
  Triangle *P;

  for (i = 0, P = Obj->Polygons; i < Obj->NumPoly; i++, P++)
    P->Shade = 0.30;
}

void ShadeLambert(ViewObject *View, VectorObject *Obj, float *M)
{
  int  i, lc;
  float Dot, LDot;
  Triangle *P;

  for (i = 0, P = Obj->Polygons; i < Obj->NumPoly; i++, P++)
  {
    if (P->Visible == 1)
    {
      LDot = 0;
      for (lc = 0; lc < Lights.NumLights; lc++)
      {
        Dot = DOTPRODUCT(Lights.TempLight[lc], P->N);
        if (Dot > 0)
          LDot += Dot;
      }
    }

    P->Shade = CLIP(LDot, 0, 1);
  }
}

void ShadeGouraud(ViewObject *View, VectorObject *Obj, float *M)
{
  int   i, lc;
  float  Dot, LDot;
  Vertex   *V;

  for (i = 0, V = Obj->Vertexs; i < Obj->NumVert; i++, V++)
  {
    if (V->Visible == 1)
    {
      LDot = 0;
      for (lc = 0; lc < Lights.NumLights; lc++)
      {
        Dot = DOTPRODUCT(Lights.TempLight[lc], V->N);

        if (Dot > 0)
          LDot += Dot;
      }
    }

    V->Shade = CLIP(LDot, 0, 1);
  }
}


void ReflectionMap(ViewObject *View, VectorObject *Obj, float *M)
{
  int  i;
  float Temp;
  Vertex3d xAxis;
  Vertex3d yAxis;
  float  CenterX = 1.0;
  float  CenterY = 1.0;


  xAxis.x = M[0];  xAxis.y = M[3];  xAxis.z = M[6];
  yAxis.x = -M[1]; yAxis.y = -M[4]; yAxis.z = -M[7];

  for (i = 0; i < Obj->NumVert; i++)
  {
    if (Obj->Vertexs[i].Visible == 1)
    {
      Temp = (DOTPRODUCT(xAxis, Obj->Vertexs[i].N) + CenterX) * 0.5;
      Obj->Vertexs[i].Env.x = CLIP(Temp, 0, 1);
      Temp = (DOTPRODUCT(yAxis, Obj->Vertexs[i].N) * View->InvCamYFac + CenterY) * 0.5;
      Obj->Vertexs[i].Env.y = CLIP(Temp, 0, 1);
    }
  }
}
