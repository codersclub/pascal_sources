#include "polygon.h"

Vertex *VertPtrA;
Vertex *VertPtrB;
Vertex *VertPtrC;
Vertex2d *TVA;
Vertex2d *TVB;
Vertex2d *TVC;
int      TotalHeight;
int      TopHeight;
int      BottomHeight;
int      CeilY1;
int      CeilY2;
int      CeilY3;
int      FXDLongX;
int      FXDLongDX;
int      FXDShortX;
int      FXDShortDX;
int      FXDSide1C;
int      FXDSide1DC;
int      FXDSide2C;
int      FXDSide2DC;
int      FXDSide1U;
int      FXDSide1DU;
int      FXDSide2U;
int      FXDSide2DU;
int      FXDSide1V;
int      FXDSide1DV;
int      FXDSide2V;
int      FXDSide2DV;
int      FXDSide1S;
int      FXDSide1DS;
int      FXDSide2S;
int      FXDSide2DS;
int      FXDSide1T;
int      FXDSide1DT;
int      FXDSide2T;
int      FXDSide2DT;
int      FXDSide1Z;
int      FXDSide1DZ;
int      FXDSide2Z;
int      FXDSide2DZ;
float    FLTInten1;
float    FLTInten2;
float    FLTInten3;
float    FLTZ1;
float    FLTZ2;
float    FLTZ3;
float    FLTTextureX1;
float    FLTTextureX2;
float    FLTTextureX3;
float    FLTTextureY1;
float    FLTTextureY2;
float    FLTTextureY3;
float    FLTEnvX1;
float    FLTEnvX2;
float    FLTEnvX3;
float    FLTEnvY1;
float    FLTEnvY2;
float    FLTEnvY3;
float    FLTLongDX;
float    FLTShortDX;
float    OneOverTotalDY;
float    OneOverTopDY;
float    OneOverBotDY;
float    PolyDX;
int      HorizontalDC;
int      HorizontalDU;
int      HorizontalDV;
int      HorizontalDZ;
int      HorizontalDS;
int      HorizontalDT;
int      YAddress;
int      Color;
int      UStart;
int      VStart;
int      SStart;
int      TStart;
int      SStart8;
int      TStart8;
int      CStart;
int      TextureOfsTable;
int      IBufferTable;
int      Count;
int      HDU8;
int      HDV8;
int      HDS8;
int      HDT8;
int      LAffU;
int      LAffV;
int      RAffU;
int      RAffV;
int      AffDU;
int      AffDV;
int      DrawWidth;
float    hpu;
float    hpv;
float    hpz;
float    SpanCount;
float    DivTable[16+1] = {1.0,           1.0,
                           0.5,           0.3333333333,
                           0.25,          0.20,
                           0.16666666667, 0.1428571428,
                           0.125,         0.1111111111,
                           0.1,           0.0909090909,
                           0.08333333333, 0.0769230769,
                           0.07142857142, 0.0666666667,
                           0.0625};


int      VirtualAddress;
int      LineSize;

float    _tmp_flt     = 0.0;
float    _tmp_half    = 0.50;
float    _tmp_fixone  = 65536.0;
float    _tmp_flt_63  = 63.0;
float    _tmp_flt_255 = 255.0;
float    _tmp_fxd2flt = 1.0 / 65536.0;
float    FUDGE_FACTOR = 0.995;

extern void _FlatPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _FlatPolygonASM parm [edi] [esi] [eax];

extern void _GouraudPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _GouraudPolygonASM parm [edi] [esi] [eax];

extern void _FlatTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _FlatTexturePolygonASM parm [edi] [esi] [eax];

extern void _GouraudTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _GouraudTexturePolygonASM parm [edi] [esi] [eax];

extern void _PhongSmoothPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _PhongSmoothPolygonASM parm [edi] [esi] [eax];

extern void _FlatReflectionPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _FlatReflectionPolygonASM parm [edi] [esi] [eax];

extern void _GouraudReflectionPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _GouraudReflectionPolygonASM parm [edi] [esi] [eax];

extern void _PhongTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _PhongTexturePolygonASM parm [edi] [esi] [eax];

extern void _PhongReflectionPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _PhongReflectionPolygonASM parm [edi] [esi] [eax];

extern void _UnshadedPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _UnshadedPolygonASM parm [edi] [esi] [eax];

extern void _UnshadedTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _UnshadedTexturePolygonASM parm [edi] [esi] [eax];

extern void _UnshadedReflectionPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _UnshadedReflectionPolygonASM parm [edi] [esi] [eax];

extern void _TransUnshadedPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransUnshadedPolygonASM parm [edi] [esi] [eax];

extern void _TransFlatPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransFlatPolygonASM parm [edi] [esi] [eax];

extern void _TransGouraudPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransGouraudPolygonASM parm [edi] [esi] [eax];

extern void _TransPhongPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransPhongPolygonASM parm [edi] [esi] [eax];

extern void _TransUnshadedTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransUnshadedTexturePolygonASM parm [edi] [esi] [eax];

extern void _TransFlatTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransFlatTexturePolygonASM parm [edi] [esi] [eax];

extern void _TransGouraudTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransGouraudTexturePolygonASM parm [edi] [esi] [eax];

extern void _TransPhongTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransPhongTexturePolygonASM parm [edi] [esi] [eax];

extern void _TransUnshadedReflectionPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransUnshadedReflectionPolygonASM parm [edi] [esi] [eax];

extern void _TransFlatReflectionPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransFlatReflectionPolygonASM parm [edi] [esi] [eax];

extern void _TransGouraudReflectionPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransGouraudReflectionPolygonASM parm [edi] [esi] [eax];

extern void _TransPhongReflectionPolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransPhongReflectionPolygonASM parm [edi] [esi] [eax];

extern void _UnshadedPerspTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _UnshadedPerspTexturePolygonASM parm [edi] [esi] [eax];

extern void _FlatPerspTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _FlatPerspTexturePolygonASM parm [edi] [esi] [eax];

extern void _GouraudPerspTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _GouraudPerspTexturePolygonASM parm [edi] [esi] [eax];

extern void _PhongPerspTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _PhongPerspTexturePolygonASM parm [edi] [esi] [eax];

extern void _TransUnshadedPerspTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransUnshadedPerspTexturePolygonASM parm [edi] [esi] [eax];

extern void _TransFlatPerspTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransFlatPerspTexturePolygonASM parm [edi] [esi] [eax];

extern void _TransGouraudPerspTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransGouraudPerspTexturePolygonASM parm [edi] [esi] [eax];

extern void _TransPhongPerspTexturePolygonASM(Triangle *Poly, char *VPage, int x);
#pragma aux _TransPhongPerspTexturePolygonASM parm [edi] [esi] [eax];


void UnshadedPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _UnshadedPolygonASM(Poly, VPage, x);
}

void AmbientPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _FlatPolygonASM(Poly, VPage, x);
}

void LambertPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _FlatPolygonASM(Poly, VPage, x);
}

void GouraudPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _GouraudPolygonASM(Poly, VPage, x);
}

void PhongPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _PhongSmoothPolygonASM(Poly, VPage, x);
}

void UnshadedTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _UnshadedTexturePolygonASM(Poly, VPage, x);
}

void AmbientTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _FlatTexturePolygonASM(Poly, VPage, x);
}

void LambertTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _FlatTexturePolygonASM(Poly, VPage, x);
}

void GouraudTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _GouraudTexturePolygonASM(Poly, VPage, x);
}

void PhongTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _PhongTexturePolygonASM(Poly, VPage, x);
}

void UnshadedPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _UnshadedPerspTexturePolygonASM(Poly, VPage, x);
}

void AmbientPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _FlatPerspTexturePolygonASM(Poly, VPage, x);
}

void LambertPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _FlatPerspTexturePolygonASM(Poly, VPage, x);
}

void GouraudPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _GouraudPerspTexturePolygonASM(Poly, VPage, x);
}

void PhongPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _PhongPerspTexturePolygonASM(Poly, VPage, x);
}

void UnshadedReflectionPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _UnshadedReflectionPolygonASM(Poly, VPage, x);
}

void AmbientReflectionPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _FlatReflectionPolygonASM(Poly, VPage, x);
}

void LambertReflectionPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _FlatReflectionPolygonASM(Poly, VPage, x);
}

void GouraudReflectionPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _GouraudReflectionPolygonASM(Poly, VPage, x);
}

void PhongReflectionPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _PhongReflectionPolygonASM(Poly, VPage, x);
}

void TransUnshadedPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransUnshadedPolygonASM(Poly, VPage, x);
}

void TransAmbientPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransFlatPolygonASM(Poly, VPage, x);
}

void TransLambertPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransFlatPolygonASM(Poly, VPage, x);
}

void TransGouraudPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransGouraudPolygonASM(Poly, VPage, x);
}

void TransPhongPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransPhongPolygonASM(Poly, VPage, x);
}

void TransUnshadedTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransUnshadedTexturePolygonASM(Poly, VPage, x);
}

void TransAmbientTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransFlatTexturePolygonASM(Poly, VPage, x);
}

void TransLambertTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransFlatTexturePolygonASM(Poly, VPage, x);
}

void TransGouraudTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransGouraudTexturePolygonASM(Poly, VPage, x);
}

void TransPhongTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransPhongTexturePolygonASM(Poly, VPage, x);
}

void TransUnshadedReflectionPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransUnshadedReflectionPolygonASM(Poly, VPage, x);
}

void TransAmbientReflectionPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransFlatReflectionPolygonASM(Poly, VPage, x);
}

void TransLambertReflectionPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransFlatReflectionPolygonASM(Poly, VPage, x);
}

void TransGouraudReflectionPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransGouraudReflectionPolygonASM(Poly, VPage, x);
}

void TransPhongReflectionPolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransPhongReflectionPolygonASM(Poly, VPage, x);
}

void TransUnshadedPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransUnshadedPerspTexturePolygonASM(Poly, VPage, x);
}

void TransAmbientPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransFlatPerspTexturePolygonASM(Poly, VPage, x);
}

void TransLambertPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransFlatPerspTexturePolygonASM(Poly, VPage, x);
}

void TransGouraudPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransGouraudPerspTexturePolygonASM(Poly, VPage, x);
}

void TransPhongPerspTexturePolygon(Triangle *Poly, char *VPage, int x, int y)
{
  _TransPhongPerspTexturePolygonASM(Poly, VPage, x);
}

