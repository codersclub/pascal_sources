#include "trkball.h"

#define sqr(a) ((a)*(a))

typedef struct
{
  float x, y, z;
} fVector3d;

fVector3d  xaxis = {1,0,0};
fVector3d  yaxis = {0,1,0};
fVector3d  zaxis = {0,0,1};

void AxisRotate(fVector3d *v, float a, float x, float y, float z)
{
  float cosa, sina;
  float dot, dx, dy, dz;
  float rx, ry, rz;
  float cx, cy, cz;

  cosa = cos(a);
  sina = sin(a);
  dot = (x * v->x + y * v->y + z * v->z);
  dx = dot * x * (1 - cosa);
  dy = dot * y * (1 - cosa);
  dz = dot * z * (1 - cosa);
  rx = v->x * cosa;
  ry = v->y * cosa;
  rz = v->z * cosa;
  cx = (y * v->z - z * v->y)*sina;
  cy = (z * v->x - x * v->z)*sina;
  cz = (x * v->y - y * v->x)*sina;

  v->x = rx + dx + cx;
  v->y = ry + dy + cy;
  v->z = rz + dz + cz;
}

void FixAxis()
{
  float dot1, dot2;
  float len;

  dot1 = xaxis.x * yaxis.x + xaxis.y * yaxis.y + xaxis.z * yaxis.z;
  dot2 = xaxis.x * zaxis.x + xaxis.y * zaxis.y + xaxis.z * zaxis.z;
  xaxis.x = xaxis.x - dot1 * yaxis.x;
  xaxis.y = xaxis.y - dot1 * yaxis.y;
  xaxis.z = xaxis.z - dot1 * yaxis.z;
  xaxis.x = xaxis.x - dot2 * zaxis.x;
  xaxis.y = xaxis.y - dot2 * zaxis.y;
  xaxis.z = xaxis.z - dot2 * zaxis.z;
  len = 1/sqrt(sqr(xaxis.x) + sqr(xaxis.y) + sqr(xaxis.z));
  xaxis.x = xaxis.x*len;
  xaxis.y = xaxis.y*len;
  xaxis.z = xaxis.z*len;

  dot1 = xaxis.x * yaxis.x + xaxis.y * yaxis.y + xaxis.z * yaxis.z;
  dot2 = yaxis.x * zaxis.x + yaxis.y * zaxis.y + yaxis.z * zaxis.z;
  yaxis.x = yaxis.x - dot1 * xaxis.x;
  yaxis.y = yaxis.y - dot1 * xaxis.y;
  yaxis.z = yaxis.z - dot1 * xaxis.z;
  yaxis.x = yaxis.x - dot2 * zaxis.x;
  yaxis.y = yaxis.y - dot2 * zaxis.y;
  yaxis.z = yaxis.z - dot2 * zaxis.z;
  len = 1/sqrt(sqr(yaxis.x) + sqr(yaxis.y) + sqr(yaxis.z));
  yaxis.x = yaxis.x*len;
  yaxis.y = yaxis.y*len;
  yaxis.z = yaxis.z*len;

  zaxis.x = xaxis.y*yaxis.z - xaxis.z*yaxis.y;
  zaxis.y = xaxis.z*yaxis.x - xaxis.x*yaxis.z;
  zaxis.z = xaxis.x*yaxis.y - xaxis.y*yaxis.x;
}

void SetObjectMatrix(VectorObject *Obj, float x, float y, float z)
{
  float phi, theta;

  phi = x;
  theta = y;
  AxisRotate(&xaxis, theta, xaxis.x, xaxis.y, xaxis.z);
  AxisRotate(&yaxis, theta, xaxis.x, xaxis.y, xaxis.z);
  AxisRotate(&zaxis, theta, xaxis.x, xaxis.y, xaxis.z);

  AxisRotate(&xaxis, phi, yaxis.x, yaxis.y, yaxis.z);
  AxisRotate(&yaxis, phi, yaxis.x, yaxis.y, yaxis.z);
  AxisRotate(&zaxis, phi, yaxis.x, yaxis.y, yaxis.z);

  phi = z;
  AxisRotate(&xaxis, phi, zaxis.x, zaxis.y, zaxis.z);
  AxisRotate(&yaxis, phi, zaxis.x, zaxis.y, zaxis.z);
  AxisRotate(&zaxis, phi, zaxis.x, zaxis.y, zaxis.z);

  FixAxis();

  Obj->Orientation[0] = xaxis.x;
  Obj->Orientation[3] = xaxis.y;
  Obj->Orientation[6] = xaxis.z;

  Obj->Orientation[1] = yaxis.x;
  Obj->Orientation[4] = yaxis.y;
  Obj->Orientation[7] = yaxis.z;

  Obj->Orientation[2] = zaxis.x;
  Obj->Orientation[5] = zaxis.y;
  Obj->Orientation[8] = zaxis.z;
}
