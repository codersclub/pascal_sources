#include "mouse.h"

void SetMouseLocation(int x, int y)
{
  union REGS inregs, outregs;
  inregs.w.ax = 0x04;
  inregs.w.cx = x;
  inregs.w.dx = y;
  int386(0x33, &inregs, &inregs);
}

void SetRange(int x1, int y1, int x2, int y2)
{
  union REGS inregs, outregs;
  inregs.w.ax = 0x07;
  inregs.w.cx = x1;
  inregs.w.dx = x2*2;
  int386(0x33, &inregs, &outregs);

  inregs.w.ax = 0x08;
  inregs.w.cx = y1;
  inregs.w.dx = y2;
  int386(0x33, &inregs, &outregs);
}

short int InitMouse(void)
{
  union REGS inregs, outregs;
  inregs.w.ax = 0;
  int386(0x33, &inregs, &outregs);
  return(outregs.w.ax);
}

void ShowMouse(void)
{
  union REGS inregs, outregs;
  inregs.w.ax = 1;
  int386(0x33, &inregs, &outregs);
}

void HideMouse(void)
{
  union REGS inregs, outregs;
  inregs.w.ax = 2;
  int386(0x33, &inregs, &inregs);
}

void  ReadMouse(short int *x, short int *y, short int *b)
{
  int i, j, k;
  union REGS inregs, outregs;

  inregs.w.ax = 0x03;
  int386(0x33, &inregs, &inregs);

  *b = inregs.w.bx;
  *x = inregs.w.cx / 2;
  *y = inregs.w.dx;
}

void  ReadMickey(short int *x, short int *y)
{
  int i, j;
  union REGS inregs, outregs;

  inregs.w.ax = 0x0b;
  int386(0x33, &inregs, &outregs);

  *x = outregs.w.cx;
  *y = outregs.w.dx;
}

int LeftButtonPressed(void)
{
  union REGS inregs, outregs;

  inregs.w.ax = 5;
  inregs.w.bx = 0;
  int386(0x33, &inregs, &outregs);

  if (outregs.w.bx != 0)
    outregs.w.bx = 1;

  outregs.w.ax &= 1;
  return (outregs.w.bx | outregs.w.ax);
}

int RightButtonPressed(void)
{
  union REGS inregs, outregs;

  inregs.w.ax = 5;
  inregs.w.bx = 1;
  int386(0x33, &inregs, &outregs);

  if (outregs.w.bx != 0)
    outregs.w.bx = 1;

  outregs.w.ax >>= 1;
  return (outregs.w.ax | outregs.w.bx);
}

int LeftButtonReleased(void)
{
  union REGS inregs, outregs;

  inregs.w.ax = 6;
  inregs.w.bx = 0;
  int386(0x33, &inregs, &outregs);

  if (outregs.w.bx == 0)
    return(0);
  else
    return(1);
}

int RightButtonReleased(void)
{
  union REGS inregs, outregs;

  inregs.w.ax = 6;
  inregs.w.bx = 1;
  int386(0x33, &inregs, &outregs);

  if (outregs.w.bx == 0)
    return(0);
  else
    return(1);
}

void WaitBClear(void)
{
  short int a, b, c;

  do
    {
      ReadMouse(&a, &b, &c);
    }
  while (c != 0);
}
