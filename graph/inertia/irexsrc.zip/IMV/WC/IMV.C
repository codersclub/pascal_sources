/*=========================================================================*
              Inerta Mesh Viewer for Inertia/32 (Watcom C)
 *=========================================================================*/

/*-------------------------------------------------------------------------*
  Include files
 *-------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include "types.h"
#include "inertia.h"
#include "menu.h"
#include "vesa20.h"
#include "mouse.h"
#include "trkball.h"

/*-------------------------------------------------------------------------*
  Constants (callback lookup tables)
 *-------------------------------------------------------------------------*/
char *ObjectList[5] ={"TORUS.GVO",
                      "HEAD.GVO",
                      "CHRMFACE.GVO",
                      "SKULL.GVO",
                      "DUCK.GVO"};

int ShadingTable[5] = {UNSHADED,
                       AMBIENT,
                       LAMBERT,
                       GOURAUD,
                       PHONG};

int SurfaceTable[4] = {SMOOTH,
                       TEXTURE,
                       PERSPTEXTURE,
                       REFLECTION};


char MouseCursor[7*7] = {0,0,0,1,0,0,0,
                         0,0,0,1,0,0,0,
                         0,0,1,1,1,0,0,
                         1,1,1,0,1,1,1,
                         0,0,1,1,1,0,0,
                         0,0,0,1,0,0,0,
                         0,0,0,1,0,0,0};


/*-------------------------------------------------------------------------*
  Globals (yuck)
 *-------------------------------------------------------------------------*/
int          XRes        = 320;
int          YRes        = 200;
int          TransFlag   = 0;
int          SurfaceFlag = SMOOTH;
int          ShadeFlag   = LAMBERT;
ViewObject   View;
VectorObject Obj;
float        ZLoc;
float        zscale;
char        *VirtualPage;

/*-------------------------------------------------------------------------*
  Function Headers
 *-------------------------------------------------------------------------*/
void ObjectCallback     (int Data);
void SurfaceCallback    (int Data);
void ShadeCallback      (int Data);
void TransparentCallback(int Data);
void ResolutionCallback (int Data);
void QuitCallback       (int Data);
void InitMenu (void);
void Init3D   (void);
void InitMisc (void);
void TextQuit (char *S);
void RunApplication(void);
void PutPixel      (int x, int y, int c);
void PutMouseCursor(int x, int y);

/*=========================================================================*
  Main
 *=========================================================================*/
main(int argc, char **argv)
{
  printf("Initializing\n");

  switch (argv[1][0])
    {
    case '1': XRes = 320;  YRes = 200; break;
    case '2': XRes = 640;  YRes = 480; break;
    case '3': XRes = 800;  YRes = 600; break;
    case '4': XRes = 1024; YRes = 768; break;
    }

  InitMenu();

  Init3D();
  InitMisc();

  RunApplication();
}

/*=========================================================================*
  InitMenu - Initializes the menu system
/*=========================================================================*/ 
void InitMenu(void)
{
  int i;

  SubMenu("Objects");        /* set up the object menu */
    for (i = 0; i < 5; i++)
      MenuItem(ObjectList[i], ObjectCallback, i);
  EndSubMenu();

  SubMenu("Surface");        /* set up the surface types menu */
    MenuItem("Smooth",        SurfaceCallback, 0);
    MenuItem("Texture",       SurfaceCallback, 1);
    MenuItem("Persp Texture", SurfaceCallback, 2);
    MenuItem("Reflection",    SurfaceCallback, 3);
  EndSubMenu();

  SubMenu("Shading");        /* set up the shading types menu */
    MenuItem("Unshaded",   ShadeCallback, 0);
    MenuItem("Ambient",    ShadeCallback, 1);
    MenuItem("Lambert",    ShadeCallback, 2);
    MenuItem("Gouraud",    ShadeCallback, 3);
    MenuItem("Phong",      ShadeCallback, 4);
  EndSubMenu();

  ToggleMenuItem("Transparent", TransparentCallback, 0); /* add a toggle selection for transparency */

  SubMenu("Resolution");
    MenuItem("320 x 200",  ResolutionCallback, 0);
    MenuItem("640 x 480",  ResolutionCallback, 1);
    MenuItem("800 x 600",  ResolutionCallback, 2);
    MenuItem("1024 x 768", ResolutionCallback, 3);
  EndSubMenu();

  MenuItem("Quit",  QuitCallback, 0);   /* make things so we can quit */  

  EndMenu();
}

/*=========================================================================*
  Initializes the 3D system
 *=========================================================================*/
void Init3D(void)
{
  InitInertia();

  if (InitMouse() != -1)
    TextQuit("A mouse is required to run this program.");

  if (LoadIntensityTable("COPPRENV.IT", 0) != I_OK)
    TextQuit("Error Loading Intensity Table");

  if (LoadTransparencyTable("COPPRENV.TT", 0) != I_OK)
    TextQuit("Error Loading Transparency Table");

  if (LoadPCXTexture(1, "COPPRENV.PCX", 0) != I_OK)
    TextQuit("Error Loading Texture");

  if (MakePhongMap(0) != 0)
    TextQuit("Error making phong buffer");

  InitView(&View);

  SetViewPort(&View, 0, 0, XRes - 1, YRes - 1, 1);

  GetTexturePalette(1);
  PushLightSource(0, 0, -1);
}

/*=======================================================================*
  Initializes a few other things
 *=======================================================================*/
void InitMisc()
{
  int Mode;
  int i;

  if (!InitVESA())
    {
      printf("Vesa driver not found!");
      exit(0);
    }

  if (!VESASetGraphics(XRes, YRes, 8, VESA_LFB))
    {
      printf("Error! VESA %dx%d mode could not be initialized.", XRes, YRes);
      exit(0);
    }

  InitMouse();

  for (i = 0; i < 256; i++)
    {
      SetRGB(i, GlobalPalette[i].r, GlobalPalette[i].g, GlobalPalette[i].b);
    }

  VirtualPage = malloc(XRes * YRes);
  memset (VirtualPage, 0, XRes * YRes);

  SetVirtualPage(VirtualPage);
  SetScreenSize(XRes, YRes);
  SetMenuColors(253, 254, 255);

  SetRGB(253, 63, 63, 63);
  SetRGB(254, 45, 45, 45);
  SetRGB(255, 32, 32, 32);

  SetRange(0, 0, XRes - 1, YRes - 1);
  SetMouseLocation(XRes / 2, YRes / 2);
}

/*========================================================================*
  Main application even loop
 *========================================================================*/
void RunApplication()
{
  short int x, y, b;
  int ox, oy;
  int Event, ButtonFlag;
  short int rotx, roty;
  Sprite *S;

  ox = -1;
  oy = -1;

  ButtonFlag = 0;
  Event      = 0;

  ReadMouse(&x, &y, &b);

  do
    {
      ReadMickey(&rotx, &roty);

      x += rotx;
      y += roty;

      if (x > (XRes - 1)) x = XRes - 1;
      if (x < 0)          x = 0;
      if (y > (YRes - 1)) y = YRes - 1;
      if (y < 0)          y = 0;

      if (LeftButtonPressed())
        {
          Event = 1;
          ButtonFlag = ButtonFlag | MOUSE_BUTTON_1_PRESSED;
        }

      if (RightButtonPressed())
        {
          Event = 1;
          ButtonFlag = ButtonFlag | MOUSE_BUTTON_2_PRESSED;
        }

      if (LeftButtonReleased())
        {
          Event = 1;
          ButtonFlag = ButtonFlag | MOUSE_BUTTON_1_RELEASED;
        }

      if (RightButtonReleased())
        {
          Event = 1;
          ButtonFlag = ButtonFlag | MOUSE_BUTTON_2_RELEASED;
        }

      if (ButtonFlag & MOUSE_BUTTON_1_PRESSED)
        {           
          ZLoc += roty * zscale;
          SetAbsoluteLocation(&Obj, 0, 0, ZLoc);
          SetObjectMatrix(&Obj, 0, 0, rotx / 256.0);
        }

      if ((rotx != ox) || (roty != oy))
        {          
          Event = 1;
        }    

    SetObjectMatrix(&Obj, rotx / 256.0, roty / 256.0, 0);

    ReadMouse(&x, &y, &b);

    AddToRenderList(&View, &Obj);
    Render(VirtualPage, XRes, YRes);
    MenuAction(ButtonFlag, x, y);
    PutMouseCursor(x-4, y-4);

    BlitClear(VirtualPage, 0);

    Event      = 0;
    ButtonFlag = 0;
    ox         = rotx;
    oy         = roty;
  }
  while (1);

  CloseVESA();
}

void TextQuit(char *S)
{
  printf("%s", S);
  ShutdownInertia();
  exit(0);
}

void ObjectCallback(int Data)
{
  FreeVectorObject(&Obj);

  if (LoadGVO(&Obj, ObjectList[Data], 0) != I_OK)
    {
      FreeVectorObject(&Obj);
      return;
    }

  SetRenderMask(&Obj, TransFlag | ShadeFlag | SurfaceFlag);

  if (TransFlag != 0)
    SetCull(&Obj, 0);

  SetBaseColor(&Obj, 36);
  SetObjectTexture(&Obj, 1);
  SetObjectPhongMap(&Obj, 0);

  SetAbsoluteLocation(&Obj, 0, 0, 3 * Obj.Radius);

  ZLoc   = 3 * Obj.Radius;
  zscale = Obj.Radius / 20;
}

void SurfaceCallback(int Data)
{
  SurfaceFlag = SurfaceTable[Data];
  SetRenderMask(&Obj, TransFlag | ShadeFlag | SurfaceFlag);
}

void ShadeCallback(int Data)
{
  ShadeFlag = ShadingTable[Data];
  SetRenderMask(&Obj, TransFlag | ShadeFlag | SurfaceFlag);
}

void TransparentCallback(int Data)
{
  TransFlag = Data * TRANSPARENT;

  if (TransFlag == TRANSPARENT)
    SetCull(&Obj, 0);
  else
    SetCull(&Obj, 1);

  SetRenderMask(&Obj, TransFlag | ShadeFlag | SurfaceFlag);
}

void ResolutionCallback (int Data)
{
  int i;
  int LastXRes;
  int LastYRes;

  free (VirtualPage);   /* free the current virtual page */

  SetText();

  LastXRes = XRes;
  LastYRes = YRes;

  switch (Data)
    {
      case 0: XRes = 320;  YRes = 200; break;
      case 1: XRes = 640;  YRes = 480; break;
      case 2: XRes = 800;  YRes = 600; break;
      case 3: XRes = 1024; YRes = 768; break;
    }

  if (!VESASetGraphics(XRes, YRes, 8, VESA_LFB))
    {
      XRes = LastXRes;
      YRes = LastYRes;

      if (!VESASetGraphics(XRes, YRes, 8, VESA_LFB))
        {
          CloseVESA();
          printf("Error! VESA mode could not be initialized.\n");
          exit(0);
        }
    }

  InitMouse();

  for (i = 0; i < 256; i++)
    {
      SetRGB(i, GlobalPalette[i].r, GlobalPalette[i].g, GlobalPalette[i].b);
    }

  VirtualPage = malloc(XRes * YRes);
  memset (VirtualPage, 0, XRes * YRes);

  SetVirtualPage(VirtualPage);
  SetScreenSize(XRes, YRes);
  SetMenuColors(253, 254, 255);

  SetRGB(253, 63, 63, 63);
  SetRGB(254, 45, 45, 45);
  SetRGB(255, 32, 32, 32);

  SetRange(0, 0, XRes - 1, YRes - 1);
  SetMouseLocation(XRes / 2, YRes / 2);

  SetViewPort(&View, 0, 0, XRes - 1, YRes - 1, 1);
}

void QuitCallback(int Data)
{
  CloseVESA();
  ShutdownInertia();
  printf("Inertia Mesh Viewer\n\n");
  printf("Program Code: Alex Chalfin\n");
  printf("Inertia/32 Code: Alex Chalfin\n\n");
  exit(0);
}

void PutPixel(int x, int y, int c)
{
  int Addr;

  if ((x < 0) || (x >= XRes)) return;
  if ((y < 0) || (y >= YRes)) return;
  if (c == 0) return;

  Addr = (int)VirtualPage;
  Addr += y * XRes + x;

  *(char *)(Addr) = c;
}

void PutMouseCursor(int x, int y)
{
  int i, j;

  for (i = 0; i < 7; i++)
    for (j = 0; j < 7; j++)
      PutPixel(x + j, y + i, MouseCursor[i*7+j]);
}
