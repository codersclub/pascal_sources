#include "menu.h"
/*

{ Alex Chalfin 10/2/97        }
{ achalfin@one.net            }
{ Given to the Public Domain  }

{ A simple pop-up menu system for TMT Pascal.             }
{ Note! even though there are scroll bar options, they    }
{ remain un-implemented. They probably won't ever get done}
{ unless the demand becomes *very* high.                  }

*/

#define  STATE_IDLE        0 
#define  STATE_INIT        1 
#define  STATE_RUN         2 
#define  STATE_DEINIT      3 
#define  STATE_CALL_INIT   4 
#define  STATE_DOWN_ONE    5 

static int InMenu  = STATE_IDLE;

#include "FONT.INC"

#define  MAX_SUB_MENUS   16        /* maximum depth of sub menus           */
#define  MAX_ITEMS_NO_SCROLL   12  /* maximum items to be displayed before */
                                   /* a scroll bar is inserted             */

#define  MENU_TYPE_TOGGLE    1 
#define  MENU_TYPE_ITEM      2 
#define  MENU_TYPE_SUB       3 
#define  MENU_TYPE_NULL      4 

typedef struct pMenuSelection
{
  char Name[32];
  int  Kind;
  MenuCallback Callback;
  int  Client;
  struct pMenuSelection *SubMenuHead;
  struct pMenuSelection *SubMenuTail;
  struct pMenuSelection *Next;
} tMenuSelection;

typedef struct
{
  tMenuSelection *Head;
  tMenuSelection *Tail;
  int            x1, y1;
  int            x2, y2;
  int            Flag;
} MenuStackEntry;

int            ScreenWidth;
int            ScreenHeight;
MenuStackEntry MenuStack[MAX_SUB_MENUS];
int            MenuStackTop = 0;

char           MenuLightColor;
char           MenuMediumColor;
char           MenuDarkColor;

int            MenuStartX;
int            MenuStartY;

char           *VirtualPage;
int            MouseCoordX;
int            MouseCoordY;

int FindMaxWidth(int Index);
int CountMenuItems(int Index);

void SolidRectangle(int x1, int y1, int x2, int y2, char Color);
void VerticalLine(int x, int y1, int y2, char Color);
void HorizontalLine(int x1, int x2, int y, char Color);

void WriteString(int X, int Y, char *S, char Color);

void DrawMenu(void);
int  MouseInBox(int x1, int y1, int x2, int y2);
void RecordAction(int Button);
int  ExecMenuCommand(void);

int  IsInMenu(void)
{
  return (InMenu == STATE_RUN);
}

void SetMenuColors(int Light, int Medium, int Dark)
{
  MenuLightColor  = Light;
  MenuMediumColor = Medium;
  MenuDarkColor   = Dark;
}

void SetVirtualPage(char *P)
{
  VirtualPage = P;
}

void SetScreenSize(int Width, int Height)
{
  ScreenWidth  = Width;
  ScreenHeight = Height;
}

void MenuItem(char *Name, MenuCallback Callback, int ClientData)
{
  tMenuSelection *TempPtr;
  tMenuSelection *Traverse;

  TempPtr = (tMenuSelection *)malloc(sizeof(tMenuSelection));

  strcpy(TempPtr->Name, Name);

  TempPtr->Callback    = Callback;
  TempPtr->Client      = ClientData;
  TempPtr->Next        = NULL;
  TempPtr->SubMenuHead = NULL;
  TempPtr->SubMenuTail = NULL;

  if (MenuStack[MenuStackTop].Head == NULL)
    {
      MenuStack[MenuStackTop].Head = TempPtr;
      MenuStack[MenuStackTop].Tail = TempPtr;
    }
  else
    {
      MenuStack[MenuStackTop].Tail->Next = TempPtr;
      MenuStack[MenuStackTop].Tail       = MenuStack[MenuStackTop].Tail->Next;
    }

  MenuStack[MenuStackTop].Tail->Kind = MENU_TYPE_ITEM;
}

void ToggleMenuItem(char *Name, MenuCallback Callback, int InitialState)
{
  char TempStr[32];

  MenuItem(Name, Callback, InitialState);
  MenuStack[MenuStackTop].Tail->Kind = MENU_TYPE_TOGGLE;
}

void SubMenu(char *Name)
{
  static int Init = 0;

  if (!Init)
    {
      MenuStack[0].Head = NULL;
      MenuStack[0].Tail = NULL;
      MenuStackTop = 0;

      Init = 1;
    }

  MenuItem(Name, NULL, 0);
  MenuStack[MenuStackTop].Tail->Kind = MENU_TYPE_SUB;

  sprintf(MenuStack[MenuStackTop].Tail->Name, "%s %c", Name, 131);

  MenuStackTop++;
  MenuStack[MenuStackTop].Head = NULL;
  MenuStack[MenuStackTop].Tail = NULL;
}

void EndSubMenu(void)
{
  MenuStack[MenuStackTop - 1].Tail->SubMenuHead = MenuStack[MenuStackTop].Head;
  MenuStack[MenuStackTop - 1].Tail->SubMenuTail = MenuStack[MenuStackTop].Tail;

  MenuStackTop--;
}

void EndMenu(void)
{
  MenuStackTop = 0;
}

void MenuAction(int MouseButton, int MouseX, int MouseY)
{
  MouseCoordX = MouseX;
  MouseCoordY = MouseY;

  RecordAction(MouseButton);

  if (InMenu == STATE_RUN)
    DrawMenu();
}

void RecordAction(int Button)
{
  int i;

  if ((InMenu == STATE_IDLE) && (Button & MOUSE_BUTTON_2_PRESSED))
    {
      InMenu = STATE_INIT;
      MenuStack[0].Flag = 0;
      return;
    }

  if ((InMenu == STATE_INIT) && (Button & MOUSE_BUTTON_2_RELEASED))
    {
      MenuStartX = MouseCoordX;
      MenuStartY = MouseCoordY;
      InMenu = STATE_RUN;
      return;
    }

  if ((InMenu == STATE_RUN) && (Button & MOUSE_BUTTON_2_PRESSED))
    {
      if (MenuStackTop == 0)
        {
          InMenu = STATE_DEINIT;
        }
      else
        {
          InMenu = STATE_DOWN_ONE;
          MenuStack[MenuStackTop].Flag = 0;
          MenuStackTop--;
        }

      return;  
    }

  if ((InMenu == STATE_DOWN_ONE) && (Button & MOUSE_BUTTON_2_RELEASED))
    {
      InMenu = STATE_RUN;
      return;
    }

  if ((InMenu == STATE_DEINIT) && (Button & MOUSE_BUTTON_2_RELEASED))
    {
      InMenu = STATE_IDLE;
      return;
    }

  if ((InMenu == STATE_RUN) && (Button & MOUSE_BUTTON_1_PRESSED))
    {
      InMenu = STATE_CALL_INIT;
      return;        
    }

  if ((InMenu == STATE_CALL_INIT) && (Button & MOUSE_BUTTON_1_RELEASED))
    {
      MenuStartX = MouseCoordX;
      MenuStartY = MouseCoordY;

      i = ExecMenuCommand();

      if ((i == MENU_TYPE_ITEM) || (i == MENU_TYPE_TOGGLE))
        {
          MenuStackTop = 0;
          InMenu = STATE_IDLE;
        }
      else
        {
          InMenu = STATE_RUN;
        }
      return;
    }
}

int ExecMenuCommand(void)
{
  tMenuSelection *Traverse;
  int             Index;
  int             i;
  int             RetCode;

  if (MouseInBox(MenuStack[MenuStackTop].x1, MenuStack[MenuStackTop].y1, MenuStack[MenuStackTop].x2, MenuStack[MenuStackTop].y2))
    {
      Index = (MouseCoordY - MenuStack[MenuStackTop].y1) / 11;

      Traverse = MenuStack[MenuStackTop].Head;

      for (i = 0; i < Index; i++)
        Traverse = Traverse->Next;

      switch (Traverse->Kind)
        {
          case MENU_TYPE_TOGGLE:
              RetCode = MENU_TYPE_TOGGLE;
              Traverse->Client = 1 - Traverse->Client;
              Traverse->Callback(Traverse->Client);
              break;
          case MENU_TYPE_ITEM: 
              RetCode = MENU_TYPE_ITEM;
              Traverse->Callback(Traverse->Client);
              break;
          case MENU_TYPE_SUB:
              RetCode = MENU_TYPE_SUB;
              MenuStackTop++;
              MenuStack[MenuStackTop].Head = Traverse->SubMenuHead;
              MenuStack[MenuStackTop].Tail = Traverse->SubMenuTail;
              MenuStack[MenuStackTop].Flag = 0;
              break;
        }

      return(RetCode);
    }
  else
    {
      return (MENU_TYPE_NULL);
    }
}

void DrawMenu(void)
{
  int            i, j;
  int            NumItemsInMenu;
  int            WidthMenu;
  int            HeightMenu;
  int            HeightLoop;
  tMenuSelection *Traverse;
  int            MenuDrawX;
  int            MenuDrawY;
  char           TempName[32];


  for (i = 0; i <= MenuStackTop; i++)
    {
      NumItemsInMenu = CountMenuItems(i);
      WidthMenu      = FindMaxWidth(i) + 5;

      HeightMenu     = NumItemsInMenu;

      if (NumItemsInMenu > MAX_ITEMS_NO_SCROLL)
        {
          HeightMenu = MAX_ITEMS_NO_SCROLL;
          WidthMenu  = WidthMenu + 5;       /* add scrollbar width */
        }

      HeightLoop = HeightMenu;
      HeightMenu = HeightMenu * 11 + 1; /* each item in the menu is 10 pixels high */

      if (!MenuStack[i].Flag)
        {           
          if ((MenuStartX + WidthMenu) >= ScreenWidth)
            MenuDrawX = (ScreenWidth - WidthMenu - 1);
          else
            MenuDrawX = MenuStartX;

          if ((MenuStartY + HeightMenu) >= ScreenHeight)
            MenuDrawY = (ScreenHeight - HeightMenu - 1);
          else
            MenuDrawY = MenuStartY;

          MenuStack[i].x1 = MenuDrawX;
          MenuStack[i].y1 = MenuDrawY;
          MenuStack[i].x2 = MenuDrawX + WidthMenu;
          MenuStack[i].y2 = MenuDrawY + HeightMenu - 1;

          MenuStack[i].Flag = 1;
        }
      else
        {           
          MenuDrawX = MenuStack[i].x1;
          MenuDrawY = MenuStack[i].y1;
        }

      /* lets finally draw the menu */
      SolidRectangle(MenuDrawX, MenuDrawY, MenuDrawX + WidthMenu, MenuDrawY + HeightMenu - 1, MenuMediumColor);

      Traverse = MenuStack[i].Head;

      for (j = 0; j < HeightLoop; j++)
        {
          if ((i == MenuStackTop) && (MouseInBox(MenuDrawX, MenuDrawY + j*11, MenuDrawX + WidthMenu, MenuDrawY + j*11 + 10)))
            {
              switch (Traverse->Kind)
                {
                  case MENU_TYPE_TOGGLE:
                      if (Traverse->Client == 0)
                        {
                          sprintf(TempName, "%s %c", Traverse->Name, 133);
                          WriteString(MenuDrawX + 1 + 2, MenuDrawY + 2 + j*11, TempName, MenuDarkColor);
                        }
                      else
                        {
                          sprintf(TempName, "%s %c", Traverse->Name, 132);
                          WriteString(MenuDrawX + 1 + 2, MenuDrawY + 2 + j*11, TempName, MenuDarkColor);
                        }
                      break;
                  case MENU_TYPE_ITEM:
                      WriteString(MenuDrawX + 1 + 2, MenuDrawY + 2 + j*11, Traverse->Name, MenuDarkColor);
                      break;
                  case MENU_TYPE_SUB:
                      WriteString(MenuDrawX + 1 + 2, MenuDrawY + 2 + j*11, Traverse->Name, MenuDarkColor);
                      break;
                }
            }
          else
            {
              VerticalLine(MenuDrawX, MenuDrawY + j*11, MenuDrawY + j*11 + 10, MenuLightColor);
              VerticalLine(MenuDrawX + WidthMenu - 1, MenuDrawY + j*11, MenuDrawY + j*11 + 10, MenuDarkColor);

              HorizontalLine(MenuDrawX, MenuDrawX + WidthMenu, MenuDrawY + j*11, MenuLightColor);
              HorizontalLine(MenuDrawX, MenuDrawX + WidthMenu, MenuDrawY + j*11 + 10, MenuDarkColor);

              switch (Traverse->Kind)
                {
                case MENU_TYPE_TOGGLE:
                    if (Traverse->Client == 0)
                      {
                        sprintf(TempName, "%s %c", Traverse->Name, 133);
                        WriteString(MenuDrawX + 1 + 2, MenuDrawY + 2 + j*11, TempName, MenuLightColor);
                        WriteString(MenuDrawX + 1 + 2 + 1, MenuDrawY + 2 + j*11 + 1, TempName, MenuDarkColor);
                      }
                    else
                      {
                        sprintf(TempName, "%s %c", Traverse->Name, 132);
                        WriteString(MenuDrawX + 1 + 2, MenuDrawY + 2 + j*11, TempName, MenuLightColor);
                        WriteString(MenuDrawX + 1 + 2 + 1, MenuDrawY + 2 + j*11 + 1, TempName, MenuDarkColor);
                      }
                    break;
                case MENU_TYPE_ITEM:
                  WriteString(MenuDrawX + 1 + 2, MenuDrawY + 2 + j*11, Traverse->Name, MenuLightColor);
                  WriteString(MenuDrawX + 1 + 2 + 1, MenuDrawY + 2 + j*11 + 1, Traverse->Name, MenuDarkColor);
                  break;
                case MENU_TYPE_SUB:
                  WriteString(MenuDrawX + 1 + 2, MenuDrawY + 2 + j*11, Traverse->Name, MenuLightColor);
                  WriteString(MenuDrawX + 1 + 2 + 1, MenuDrawY + 2 + j*11 + 1, Traverse->Name, MenuDarkColor);
                  break;
                }
            }

          Traverse = Traverse->Next;
        }
    }
}

int FindMaxWidth(int Index)
{
  tMenuSelection *Traverse;
  int             MaxWidth;
  int             Width;

  MaxWidth = 0;
  Traverse = MenuStack[Index].Head;

  while (Traverse != NULL)
    {
      if (Traverse->Kind == MENU_TYPE_TOGGLE)
        Width = strlen(Traverse->Name) + 2;
      else
        Width = strlen(Traverse->Name);

      Width *= 5;  /* width in pixels */

      if (Width > MaxWidth)
        MaxWidth = Width;

      Traverse = Traverse->Next;
    }

  return(MaxWidth);
}

int CountMenuItems(int Index)
{
  tMenuSelection *Traverse;
  int            Count;

  Count    = 0;
  Traverse = MenuStack[Index].Head;

  while (Traverse != NULL)
    {
      Count++;
      Traverse = Traverse->Next;
    }

  return (Count);
}

void SolidRectangle(int x1, int y1, int x2, int y2, char Color)
{
  int vOfs;

  if (x1 >= x2)
    return;

  vOfs = (int)VirtualPage;
  vOfs += y1 * ScreenWidth + x1;

  while (y1 < y2)
    {
      memset((char *)vOfs, Color, x2 - x1);
      vOfs += ScreenWidth;
      y1++;
    }
}

void VerticalLine(int x, int y1, int y2, char Color)
{
  int vOfs;

  vOfs = (int)VirtualPage;
  vOfs += y1 * ScreenWidth + x;

  while (y1 < y2)
    {
      *(char *)vOfs = Color;
      vOfs += ScreenWidth;
      y1++;
    }
}

void HorizontalLine(int x1, int x2, int y, char Color)
{
  int vOfs;

  if (x1 >= x2)
    return;

  vOfs = (int)VirtualPage;
  vOfs += y * ScreenWidth + x1;

  memset((char *)vOfs, Color, x2-x1);
}

void WriteString(int X, int Y, char *S, char Color)
{
  int CharCount;
  int i;
  int CharIndex;
  int xc, yc;
  int sx, sy;
  int Offset;

  Offset = (int)VirtualPage;

  for (CharCount = 0; CharCount < strlen(S); CharCount++)
    {
      CharIndex = (int)(S[CharCount]) - 33;

      if ((CharIndex > 0) && (CharIndex < NUMCHAR))
        {
          for (yc = 0; yc < 7; yc++)
            for (xc = 0; xc < 4; xc++)
              if (CharSet[CharIndex * 4*7 + (yc << 2) + xc] == 1)
                {
                  sx = X+xc;
                  sy = Y+yc;
                  if (((sy >= 0) && (sy <= ScreenHeight)) && ((sx >= 0) && (sx <= ScreenWidth)))
                     *(char *)(Offset + sy * ScreenWidth + sx) = Color;
                }
        }

      X += 5;

      if (X > ScreenWidth)
        return;
    }
}

int MouseInBox(int x1, int y1, int x2, int y2)
{
  if ((x1 <= MouseCoordX) && (MouseCoordX <= x2))
    {
      if ((y1 <= MouseCoordY) && (MouseCoordY <= y2))
        return (1);
      else
        return (0);
    }
  else
    return(0);
}
