/*==========================================================================*
                      VESA (1.2 and 2.0) Graphics Library
           Copyright (c) 1997, Alex Chalfin. All Rights Reserved.
 *==========================================================================*/  
#include "vesa20.h"

VESACurrentModeBlock VESAVars;

struct
{
  int edi;
  int esi;
  int ebp;
  int reserved;
  int ebx;
  int edx;
  int ecx;
  int eax;
  short int flags;
  short int es;
  short int ds;
  short int fs;
  short int gs;
  short int ip;
  short int cs;
  short int sp;
  short int ss;
} RMCB;

int OldMode;   /* storage place for old video mode */

/*=========================================================================*
  Interrupt functions
 *=========================================================================*/

/*=========================================================================*
  RMint86 - Call real mode interrupt
 *=========================================================================*/
void RMint86(char intnum, union REGS *inregs, union REGS *outregs)
{
  struct SREGS sregs;

  RMCB.edi      = inregs->x.edi;
  RMCB.esi      = inregs->x.esi;
  RMCB.ebp      = 0;
  RMCB.reserved = 0;
  RMCB.ebx      = inregs->x.ebx;
  RMCB.edx      = inregs->x.edx;
  RMCB.ecx      = inregs->x.ecx;
  RMCB.eax      = inregs->x.eax;

  RMCB.es       = 0;
  RMCB.ds       = 0;
  RMCB.fs       = 0;
  RMCB.gs       = 0;

  inregs->w.ax  = 0x0300;
  inregs->h.bl  = (char)intnum;
  inregs->h.bh  = 0;
  inregs->w.cx  = 0;
  inregs->x.edi = FP_OFF(&RMCB);

  sregs.es      = FP_SEG(&RMCB);
  sregs.ds      = 0;
  sregs.fs      = 0;
  sregs.gs      = 0;

  int386x(0x31, inregs, outregs, &sregs); 

  outregs->x.eax = RMCB.eax;
  outregs->x.ebx = RMCB.ebx;
  outregs->x.ecx = RMCB.ecx;
  outregs->x.edx = RMCB.edx;
  outregs->x.esi = RMCB.esi;
  outregs->x.edi = RMCB.edi;
}

/*==========================================================================*
  RMint86x - Real mode interrupt with segment registers
 *==========================================================================*/
void RMint86x(char intnum, union REGS *inregs, union REGS *outregs, struct SREGS *sregs)
{
  RMCB.edi      = inregs->x.edi;
  RMCB.esi      = inregs->x.esi;
  RMCB.ebp      = 0;
  RMCB.reserved = 0;
  RMCB.ebx      = inregs->x.ebx;
  RMCB.edx      = inregs->x.edx;
  RMCB.ecx      = inregs->x.ecx;
  RMCB.eax      = inregs->x.eax;

  RMCB.es       = sregs->es;
  RMCB.ds       = sregs->ds;
  RMCB.fs       = sregs->fs;
  RMCB.gs       = sregs->gs;

  inregs->w.ax  = 0x0300;
  inregs->h.bl  = (char)intnum;
  inregs->h.bh  = 0;
  inregs->w.cx  = 0;
  inregs->x.edi = FP_OFF(&RMCB);

  sregs->es     = FP_SEG(&RMCB);
  sregs->ds     = 0;
  sregs->fs     = 0;
  sregs->gs     = 0;

  int386x(0x31, inregs, outregs, sregs);

  outregs->x.eax = RMCB.eax;
  outregs->x.ebx = RMCB.ebx;
  outregs->x.ecx = RMCB.ecx;
  outregs->x.edx = RMCB.edx;
  outregs->x.esi = RMCB.esi;
  outregs->x.edi = RMCB.edi;

  sregs->es      = RMCB.es;
  sregs->ds      = RMCB.ds;
  sregs->fs      = RMCB.fs;
  sregs->gs      = RMCB.gs;
}

/*==========================================================================*
  PMint86 - Protected mode interrupt
 *==========================================================================*/
void PMint86(char intnum, union REGS *inregs, union REGS *outregs)
{
  int386(intnum, inregs, outregs);
}

/*==========================================================================*
  PMint86x - Protected mode interrupt with segment registers
 *==========================================================================*/
void PMint86x(char intnum, union REGS *inregs, union REGS *outregs, struct SREGS *sregs)
{
  int386x(intnum, inregs, outregs, sregs);
}


/*=========================================================================*
  DPMI Functions
 *=========================================================================*/

/*=========================================================================*
  DPMI_AllocDOSMem - allocate DOS memory block
 *=========================================================================*/
int DPMI_AllocDOSMem(int size, int *selector)
{
  union REGS inregs;
  union REGS outregs;

  inregs.x.eax = 0x0100;
  inregs.x.ebx = (size + 15) / 16;
  PMint86(0x31, &inregs, &outregs);
  if (outregs.x.cflag)
    return(0);
  else
  {
    *selector = (int)(outregs.w.dx);
    return((unsigned int)outregs.w.ax);
  }
}

/*=========================================================================*
  DPMI_FreeDOSMem - free DOS memory block
 *=========================================================================*/
int DPMI_FreeDOSMem(int selector)
{
  union REGS inregs;
  union REGS outregs;

  inregs.x.eax = 0x0101;
  inregs.x.edx = selector;
  PMint86(0x31, &inregs, &outregs);
  if (outregs.x.cflag)
    return(0);
  else
    return(1);
}

/*=========================================================================*
  DPMI_MapPhysicalToLinear - maps a physical memory address to logical addr
 *=========================================================================*/
int DPMI_MapPhysicalToLinear(int PhysBasePtr, int limit)
{
  int PhysOfs;
  union REGS inregs;
  union REGS outregs;

  PhysOfs       = (PhysBasePtr & 0x00000fff);
  PhysBasePtr   = (PhysBasePtr & 0xfffff000);
  limit         = ((limit + PhysOfs + 4096) & 0xfffff000) - 1;

  inregs.w.ax   = 0x0800;
  inregs.w.bx   = (short int)(PhysBasePtr >> 16);
  inregs.w.cx   = (short int)(PhysBasePtr & 0x0000ffff);
  inregs.w.si   = (short int)(limit >> 16);
  inregs.w.di   = (short int)(limit & 0x0000ffff);

  PMint86(0x31, &inregs, &outregs);

  if (outregs.x.cflag)
    return(0);
  else
    return((((int)outregs.w.bx) << 16) + outregs.w.cx + PhysOfs);
}

/*=========================================================================*
  Vesa Functions
 *=========================================================================*/

/*=========================================================================*
  VEAS_Func00 - Get VESA Information
 *=========================================================================*/
int VESA_Func00(int RMSegAddr)
{
  union  REGS inregs;
  union  REGS outregs;
  struct SREGS sregs;

  sregs.es    = (short int)RMSegAddr;
  sregs.ds    = 0;
  sregs.fs    = 0;
  sregs.gs    = 0;

  inregs.w.ax = 0x4f00;
  inregs.w.di = 0;

  RMint86x(0x10, &inregs, &outregs, &sregs);

  if (outregs.h.al != 0x4f)
    return(0);
  else
    return(1);
}

/*=========================================================================*
  VEAS_Func01 - Get Mode Information
 *=========================================================================*/
int VESA_Func01(int RMSegAddr, int modenum)
{
  union  REGS inregs;
  union  REGS outregs;
  struct SREGS sregs;

  sregs.es    = (short int)RMSegAddr;
  sregs.ds    = 0;
  sregs.fs    = 0;
  sregs.gs    = 0;

  inregs.w.ax = 0x4f01;
  inregs.w.di = 0;
  inregs.w.cx = (short int)modenum;

  RMint86x(0x10, &inregs, &outregs, &sregs);

  if (outregs.h.al != 0x4f)
    return(0);
  else
    return(1);
}

/*=========================================================================*
  VEAS_Func02 - Set VESA video mode
 *=========================================================================*/
int VESA_Func02(int modenum)
{
  union  REGS inregs;
  union  REGS outregs;

  inregs.w.ax = 0x4f02;
  inregs.w.bx = (short int)modenum;

  RMint86(0x10, &inregs, &outregs);

  if (outregs.h.al != 0x4f)
    return(0);
  else
    return(1);
}

/*=========================================================================*
  VESA_Func05 - Set VESA window (bank)
 *=========================================================================*/
int VESA_Func05(int pagenum)
{
  union  REGS inregs;
  union  REGS outregs;

  inregs.w.ax = 0x4f05;
  inregs.w.bx = 0;
  inregs.w.dx = (short int)pagenum;

  RMint86(0x10, &inregs, &outregs);

  if (outregs.h.al != 0x4f)
    return(0);
  else
    return(1);
}

/*=========================================================================*
  VESA_Mode - Set video mode via standard int 0x10 call
 *=========================================================================*/
int VESA_Mode(int mode)
{
  union REGS inregs;
  union REGS outregs;

  inregs.x.eax = mode;
  RMint86(0x10, &inregs, &outregs);
  return(1);
}

/*=========================================================================*
  Memory Functions
 *=========================================================================*/

/*=========================================================================*
  DWordMemCpy - copies source to dest a dword at a time
 *=========================================================================*/
void DWordMemCpy(char *dest, char *src, int count);
#pragma aux DWordMemCpy = \
"  Mov  edx,ecx"          \
"  And  edx,3"            \
"  Shr  ecx,2"            \
"  Rep  Movsd"            \
"  Mov  ecx,edx"          \
"  Rep  Movsb"            \
modify [edx]              \
parm [edi] [esi] [ecx];

/*=========================================================================*
  DWordClearCopy - copies source to dest and clears source
 *=========================================================================*/
void DWordClearCopy(char *dest, char *src, int count, int value);
#pragma aux DWordClearCopy = \
"  Shr  ecx,3"         \
"  Mov  bh,bl"         \
"  Mov  eax,ebx"       \
"  Shl  ebx,16"        \
"  Mov  bx,ax"         \
"@@Loop:"              \
"  Mov  eax,[esi]"     \
"  Mov  edx,[esi+4]"   \
"  Mov  [esi],ebx"     \
"  Mov  [esi+4],ebx"   \
"  Mov  [edi],eax"     \
"  Mov  [edi+4],edx"   \
"  Add  esi,8"         \
"  Add  edi,8"         \
"  Dec  ecx"           \
"  Jnz @@Loop"         \
parm [edi] [esi] [ecx] [ebx]\
modify [edx ebx];

/*=========================================================================*
  Main Functions
 *=========================================================================*/

/*=========================================================================*
  InitVESA - initialize vesa system
 *=========================================================================*/
int InitVESA()
{
  int DOSSegAddrInfo;
  int DOSSegAddrMode;
  int DOSSelectorInfo;
  int DOSSelectorMode;
  short int *modeptr;
  short int *tempptr;
  int  i;

  /* Initialize interal variables */

  VESAVars.maxx        = 0;
  VESAVars.maxy        = 0;
  VESAVars.linesize    = 0;
  VESAVars.currentmode = 0;
  VESAVars.colordepth  = 0;
  VESAVars.granularity = 0;
  VESAVars.granmask    = 0;
  VESAVars.granshift   = 0;
  VESAVars.pagecache   = 0;
  VESAVars.ingraphics  = 0;
  VESAVars.isvesa      = 0;
  VESAVars.version     = 0x0000;
  VESAVars.errorflag   = 0;
  VESAVars.pagecache   = 0;
  VESAVars.VESAModes   = NULL;

  /* allocate a 512 byte DOS block */
  /* for VESA info                 */
  DOSSegAddrInfo = DPMI_AllocDOSMem(512, &DOSSelectorInfo);
  if (!(DOSSegAddrInfo))
    return(0);

  /* allocate another 512 byte DOS block */
  /* for VESA Mode info                  */
  DOSSegAddrMode = DPMI_AllocDOSMem(512, &DOSSelectorMode);
  if (!(DOSSegAddrMode))
  {
    DPMI_FreeDOSMem(DOSSelectorInfo);
    VESAVars.errorflag = 1;
    return(0);
  }

  /* map a real mode segment to pmode linear address */
  /* using DOS4GW's nice 1st meg linear mapping :)   */
  VESAVars.InfoBlock = (VESAInfoBlock *)((DOSSegAddrInfo << 4));

  /* set up for VESA 2.0 interface */
  VESAVars.InfoBlock->VESASignature[0] = 'V';
  VESAVars.InfoBlock->VESASignature[1] = 'B';
  VESAVars.InfoBlock->VESASignature[2] = 'E';
  VESAVars.InfoBlock->VESASignature[3] = '2';

  /* get the VESA information */
  if (!(VESA_Func00(DOSSegAddrInfo)))
    return(0);

  if ((VESAVars.InfoBlock->VESASignature[0] != 'V') || (VESAVars.InfoBlock->VESASignature[1] != 'E') ||
      (VESAVars.InfoBlock->VESASignature[2] != 'S') || (VESAVars.InfoBlock->VESASignature[3] != 'A'))
      {
        DPMI_FreeDOSMem(DOSSelectorMode);
        DPMI_FreeDOSMem(DOSSelectorInfo);
        return(0);
      }

  VESAVars.version     = VESAVars.InfoBlock->VESAVersion;
  VESAVars.totalmemory = ((int)VESAVars.InfoBlock->TotalMemory) * 0x10000;

  modeptr = (short int *)RMFP_LINEAR((unsigned int)VESAVars.InfoBlock->VideoModePtr);

  /* get a count on the number of video modes */
  VESAVars.nummodes = 0;
  tempptr = modeptr;
  while (*(tempptr++) != -1) VESAVars.nummodes++;

  VESAVars.nummodes++; /* allow for mode 13h */

  /* allocate a block for the complete mode list */
  VESAVars.VESAModes = (VESAMode *)malloc(VESAVars.nummodes * sizeof(VESAMode));
  if (VESAVars.VESAModes == NULL)  /* check to see if things were allocated correctly */
  {
    DPMI_FreeDOSMem(DOSSelectorMode);
    DPMI_FreeDOSMem(DOSSelectorInfo);
    return(0);
  }

  VESAVars.VESAModes[0].Mode    = 0x13;  /* store mode number */
  VESAVars.VESAModes[0].XRes    = 320;
  VESAVars.VESAModes[0].YRes    = 200;
  VESAVars.VESAModes[0].CDepth  = 8;

  i = 1;
  VESAVars.ModeBlock = (ModeInfoBlock *)(DOSSegAddrMode << 4);
  while (*modeptr != -1)
  {
    VESA_Func01(DOSSegAddrMode, *modeptr);
    VESAVars.VESAModes[i].Mode    = *modeptr;  /* store mode number */
    VESAVars.VESAModes[i].XRes    = VESAVars.ModeBlock->XResolution;
    VESAVars.VESAModes[i].YRes    = VESAVars.ModeBlock->YResolution;
    VESAVars.VESAModes[i].CDepth  = VESAVars.ModeBlock->BitsPerPixel;
    i++;
    modeptr++;
  }

  DPMI_FreeDOSMem(DOSSelectorMode);
  DPMI_FreeDOSMem(DOSSelectorInfo);

  VESAVars.isvesa = 1;

  return(1);
}

/*=========================================================================*
  CloseVESA - Shutdown VESA system freeing all memory
 *=========================================================================*/
void CloseVESA()
{
  if (VESAVars.ingraphics) SetText();
  if (VESAVars.VESAModes != NULL) free(VESAVars.VESAModes);
}

/*=========================================================================*
  VESASetGraphics - set the graphics mode
 *=========================================================================*/
int VESASetGraphics(int xres, int yres, int cdepth, int lfbflag)
{
  int DOSSegAddrMode;
  int DOSSelectorMode;

  int modenum = 0xffffffff;

  if (!(VESAVars.isvesa)) return(0);

  OldMode = *(char *)(0x449); /* read the bios table to get the old video */
                              /* mode. Note! this only works with         */
                              /* extenders that linearly map the first    */
                              /* megabyte of memory (DOS4GW, PMODE/W)     */

  modenum = ExactModeSearch(xres, yres, cdepth);

  if (modenum == 0xffffffff) return(0);

  /* special case the handling of mode 13h */      
  if (VESAVars.VESAModes[modenum].Mode == 0x13)
  {
    VESAVars.memmode = VESA_LFB;
    VESAVars.granularity    = 64;
    VESAVars.granmask       = 0xffff;
    VESAVars.granshift      = 16;
    VESAVars.VGAScreen      = (char *)0xa0000;
    VESAVars.maxx           = 320;
    VESAVars.maxy           = 200;
    VESAVars.linesize       = 320;
    VESAVars.colordepth     = 8;
    VESAVars.bytesperpixel  = 1;

    VESAVars.ingraphics     = 1;

    VESA_Mode(0x13);
    return(1);
  }

  DOSSegAddrMode  = DPMI_AllocDOSMem(512, &DOSSelectorMode);
  if (!(DOSSegAddrMode))
    return(0);

  VESAVars.ModeBlock = (ModeInfoBlock *)(DOSSegAddrMode << 4);
  VESA_Func01(DOSSegAddrMode, VESAVars.VESAModes[modenum].Mode);

  if (!(VESAVars.ModeBlock->ModeAttributes & 0x80))
    lfbflag = VESA_BANKED;

  VESAVars.memmode = lfbflag;

  if (VESAVars.memmode == VESA_LFB)
  {
    VESAVars.VGAScreen = (char *)DPMI_MapPhysicalToLinear((unsigned int)VESAVars.ModeBlock->PhysBasePtr, (unsigned int)VESAVars.totalmemory);
    if (!VESAVars.VGAScreen)
    {
      DPMI_FreeDOSMem(DOSSelectorMode);
      return(0);
    }
    VESA_Func02(VESAVars.VESAModes[modenum].Mode | 0x4000);
  }
  else
  {
    VESAVars.granularity    = VESAVars.ModeBlock->WinGranularity;
    VESAVars.granmask       = (VESAVars.granularity << 10) - 1;
    VESAVars.granshift      = log2(VESAVars.granularity) + 10;
    VESAVars.VGAScreen      = (char *)0xa0000;
    VESA_Func02(VESAVars.VESAModes[modenum].Mode);
  }

  VESAVars.maxx           = VESAVars.ModeBlock->XResolution;
  VESAVars.maxy           = VESAVars.ModeBlock->YResolution;
  VESAVars.linesize       = VESAVars.ModeBlock->BytesPerLine;
  VESAVars.colordepth     = VESAVars.ModeBlock->BitsPerPixel;
  VESAVars.bytesperpixel  = ceil((float)VESAVars.colordepth / (8.0));

  VESAVars.redsizeshift   = 8 - VESAVars.ModeBlock->RedMaskSize;
  VESAVars.greensizeshift = 8 - VESAVars.ModeBlock->GreenMaskSize;
  VESAVars.bluesizeshift  = 8 - VESAVars.ModeBlock->BlueMaskSize;

  VESAVars.redlocshift    = VESAVars.ModeBlock->RedFieldPosition;
  VESAVars.greenlocshift  = VESAVars.ModeBlock->GreenFieldPosition;
  VESAVars.bluelocshift   = VESAVars.ModeBlock->BlueFieldPosition;

  DPMI_FreeDOSMem(DOSSelectorMode);

  VESAVars.ingraphics = 1;

  return(1);
}


/*=========================================================================*
  ExactModeSearch - search the list of gfx modes for the one we want
 *=========================================================================*/
int ExactModeSearch(int xres, int yres, int cdepth)
{
  int retflag = 0xffffffff;
  int i;

  for (i = 0; i < VESAVars.nummodes; i++)
  {
    if ((xres == VESAVars.VESAModes[i].XRes) && (yres == VESAVars.VESAModes[i].YRes) && (cdepth == VESAVars.VESAModes[i].CDepth))
    {
      retflag = i;  /* found a mode number that works */
      break;
    }
  }
  return(retflag);
}


/*=========================================================================*
  SetText - return back to text mode                       
 *=========================================================================*/
int SetText()
{
  if (!(VESAVars.ingraphics)) return(0);
  VESA_Mode(OldMode);
  VESAVars.ingraphics = 0;
  return(1);
}

/*=========================================================================*
  PutPixel - sets an 8-bit palette driven pixel. Gotta have it :)
 *=========================================================================*/
void PutPixel(int x, int y, int c)
{
  int vofs, vpage;

  if (!(VESAVars.ingraphics)) return;

  if ((x < VESAVars.maxx) && (x >= 0) && (y < VESAVars.maxy) && (y >= 0))
  {
    vofs  = y*VESAVars.linesize + x;
    if (VESAVars.memmode == VESA_BANKED)
    {
      vpage = (vofs >> VESAVars.granshift);
      vofs &= VESAVars.granmask;
      if (vpage != VESAVars.pagecache)
      {
        VESA_Func05(vpage);
        VESAVars.pagecache = vpage;
      }
    }
    *(char *)(VESAVars.VGAScreen + vofs) = (char )c;
  }
}

/*=========================================================================*
  PutPixelRGB - sets an RGB driven pixel. Gotta have it :)
 *=========================================================================*/
void PutPixelRGB(int x, int y, int r, int g, int b)
{
  int vofs, vpage;

  if (!(VESAVars.ingraphics)) return;

  if ((x < VESAVars.maxx) && (x >= 0) && (y < VESAVars.maxy) && (y >= 0))
  {
    switch (VESAVars.colordepth)
    {
      case 15 : vofs  = y*VESAVars.linesize + x*2; break;
      case 16 : vofs  = y*VESAVars.linesize + x*2; break;
      case 24 : vofs  = y*VESAVars.linesize + x*3; break;
      case 32 : vofs  = y*VESAVars.linesize + x*4; break;
    }

    if (VESAVars.memmode == VESA_BANKED)
    {
      vpage = (vofs >> VESAVars.granshift);
      vofs &= VESAVars.granmask;
      if (vpage != VESAVars.pagecache)
      {
        VESA_Func05(vpage);
        VESAVars.pagecache = vpage;
      }
    }

    switch (VESAVars.colordepth)
    {
      case 15 : *(short int *)((int)VESAVars.VGAScreen + vofs) = (short int)TO_15BIT(r, g, b); break;
      case 16 : *(short int *)((int)VESAVars.VGAScreen + vofs) = (short int)TO_16BIT(r, g, b); break;
      case 24 : *(char *)((int)VESAVars.VGAScreen + vofs) = (char)r;
                *(char *)((int)VESAVars.VGAScreen + vofs + 1) = (char)g;
                *(char *)((int)VESAVars.VGAScreen + vofs + 2) = (char)b;
                break;
      case 32 : *(int *)(VESAVars.VGAScreen + vofs) = TO_32BIT(r, g, b); break;
    }
  }
}

/*=========================================================================*
  Blit - copies a virtual page the same size as video screen to screen
 *=========================================================================*/
void Blit(char *vpage)
{
  int screensize;
  int modbank, divbank;
  int i;
  char *vga;

  if (!(VESAVars.ingraphics)) return;

  vga = VESAVars.VGAScreen;
  screensize = VESAVars.linesize * VESAVars.maxy;

  if (VESAVars.memmode == VESA_BANKED)
  {
    i          = 0;
    modbank    = (screensize & VESAVars.granmask);
    divbank    = (screensize >> VESAVars.granshift);
    for (i = 0; i < divbank; i++)
    {
      VESA_Func05(i);
      VESAVars.pagecache = i;
      DWordMemCpy(vga, vpage, (VESAVars.granmask + 1));
      vpage += (VESAVars.granmask + 1);
    }
    if (modbank > 0)
    {
      VESA_Func05(i);
      VESAVars.pagecache = i;
      DWordMemCpy(vga, vpage, modbank);
    }
  }
  else
  {
    DWordMemCpy(vga, vpage, screensize);
  }
}

/*=========================================================================*
  BlitClear - same as Blit, bit clears vpage as well
 *=========================================================================*/
void BlitClear(char *vpage, int c)
{
  int screensize;
  int modbank, divbank;
  int i;
  char *vga;

  if (!(VESAVars.ingraphics)) return;

  vga = VESAVars.VGAScreen;
  screensize = VESAVars.linesize * VESAVars.maxy;

  if (VESAVars.memmode == VESA_BANKED)
  {
    i          = 0;
    modbank    = (screensize & VESAVars.granmask);
    divbank    = (screensize >> VESAVars.granshift);
    for (i = 0; i < divbank; i++)
    {
      VESA_Func05(i);
      VESAVars.pagecache = i;
      DWordClearCopy(vga, vpage, (VESAVars.granmask + 1), c);
      vpage += (VESAVars.granmask + 1);
    }
    if (modbank > 0)
    {
      VESA_Func05(i);
      VESAVars.pagecache = i;
      DWordClearCopy(vga, vpage, modbank, c);
    }
  }
  else
  {
    DWordClearCopy(vga, vpage, screensize, c);
  }
}

/*=========================================================================*
  CopyWindow - copies window from vpage. 
 *=========================================================================*/
void CopyWindow(char *vpage, int x1, int y1, int x2, int y2)
{
  int i;
  int vpage1, vpage2, vofs1, vofs2;
  int temp;

  if (!(VESAVars.ingraphics)) return;

  if (VESAVars.memmode == VESA_BANKED)
  {
    for (i = y1*VESAVars.linesize; i <= y2*VESAVars.linesize; i+=VESAVars.linesize)
    {
      vofs1  = (i + x1);
      vofs2  = (i + x2);
      vpage1 = (vofs1 >> VESAVars.granshift);
      vpage2 = (vofs2 >> VESAVars.granshift);
      vofs1 &= VESAVars.granmask;
      vofs2 &= VESAVars.granmask;

      if (vpage1 != VESAVars.pagecache)
      {
        VESA_Func05(vpage1);
        VESAVars.pagecache = vpage1;
      }

      if (vpage1 != vpage2)
      {
        temp = ((VESAVars.granmask + 1) - vofs1);
        DWordMemCpy((char *)((int)VESAVars.VGAScreen + vofs1), (char *)((int)vpage + i + x1), temp);

        VESA_Func05(vpage2);
        VESAVars.pagecache = vpage2;
        DWordMemCpy((char *)((int)VESAVars.VGAScreen), (char *)((int)vpage + i + x1 + temp), vofs2);
      }
      else
      {
        DWordMemCpy((char *)((int)VESAVars.VGAScreen + vofs1), (char *)((int)vpage + i + x1), (x2 - x1 + 1));
      }
    }
  }
  else
  {
    for (i = y1*VESAVars.linesize; i <= y2*VESAVars.linesize; i+=VESAVars.linesize)
      DWordMemCpy((char *)((int)VESAVars.VGAScreen + i + x1), (char *)((int)vpage + i + x1), (x2 - x1 + 1));
  }
}

/*=========================================================================*
  SetRGB - sets an RGB palette component. 
 *=========================================================================*/

void SetRGB(int c, int r, int g, int b)
{
  outp(0x3c8, c);
  outp(0x3c9, r);
  outp(0x3c9, g);
  outp(0x3c9, b);
}

/*=========================================================================*
  SetGammaRGB - sets an Gamma corrected RGB palette component. 
 *=========================================================================*/

void SetGammaRGB(int c, int r, int g, int b, float Gamma)
{
  outp(0x3c8, c);
  outp(0x3c9, (int)(63.0 * pow((float)r / 255.0, 1.0 / Gamma)));
  outp(0x3c9, (int)(63.0 * pow((float)g / 255.0, 1.0 / Gamma)));
  outp(0x3c9, (int)(63.0 * pow((float)b / 255.0, 1.0 / Gamma)));
}


/*=========================================================================*
  BitBlt Functions - These work for 8bpp modes only. 
 *=========================================================================*/


/*=========================================================================*
  ImageSize - returns the size of an image for getimage/putpimage. 
 *=========================================================================*/
int ImageSize(int x1, int y1, int x2, int y2)
{
  return((x2 - x1 + 1) * (y2 - y1 + 1) * VESAVars.bytesperpixel + 12);
}

/*=========================================================================*
  GetImage - gets an image. 
 *=========================================================================*/
void GetImage(int x1, int y1, int x2, int y2, Sprite *Spr)
{
  if (!(VESAVars.ingraphics)) return;

  if ((x1 >= VESAVars.maxx) || (x2 < 0))
  {
    Spr->Height = 0;
    Spr->Width  = 0;
    return;
  }

  if ((y1 >= VESAVars.maxy) || (y2 < 0))
  {
    Spr->Height = 0;
    Spr->Width  = 0;
    return;
  }

  if (VESAVars.memmode == VESA_BANKED)
    GetImageBanked(x1, y1, x2, y2, Spr);
  else
    GetImageLFB(x1, y1, x2, y2, Spr);
}


/*=========================================================================*
  PutImage - puts an image. 
 *=========================================================================*/
void PutImage(int x, int y, Sprite *Spr, int Style)
{
  if (VESAVars.memmode == VESA_BANKED)
  {
    if (Style == PUT_ALL)
      PutImageBankedAll(x, y, Spr);
    else
      PutImageBankedTrans(x, y, Spr);
  }
  else
  {
    if (Style == PUT_ALL)
      PutImageLFBAll(x, y, Spr);
    else
      PutImageLFBTrans(x, y, Spr);
  }
}

void GetImageBanked(int x1, int y1, int x2, int y2, Sprite *Spr)
{
  int  width, height;
  int  draw_width, draw_height;
  int  i, sx, sy, tx, ty;
  char *sprite_data;
  int vpage1, vpage2, vofs1, vofs2;
  int temp;
  int yofs;

  Spr->Width  = (x2 - x1 + 1);
  Spr->Height = (y2 - y1 + 1);
  width  = Spr->Width;
  height = Spr->Height;

  tx = x1 + width;
  ty = y1 + height;

  // make sure is on screen
  if ((tx < 0) || (x1 >= (VESAVars.maxx))) return;
  if ((ty < 0) || (y1 >= (VESAVars.maxy))) return;

  sx = 0;
  sy = 0;

  // left clipping
  if (tx < width)
  {
    draw_width = tx;
    sx = -x1;
    x1 = 0;
  }
  else draw_width = width;

  // right clipping
  if (tx > (VESAVars.maxx)) draw_width -= (tx - (VESAVars.maxx));

  // top clipping
  if (ty < height)
  {
    draw_height = ty;
    sy = -y1;
    y1 = 0;
  }
  else draw_height = height;

  // bottom clipping
  if (ty > (VESAVars.maxy)) draw_height -= (ty - (VESAVars.maxy));

  // set pointer to sprite data
  sprite_data = (char *)(&(Spr->Data[sy*width + sx]));

  tx = width - draw_width;
  ty = (VESAVars.maxx) - draw_width;

  for (i = sy, yofs = (y1*VESAVars.linesize); i < (sy+draw_height); i++, yofs+=VESAVars.linesize)
  {
    vofs1 = (yofs + x1);
    vofs2 = (yofs + x1 + draw_width - 1);
    vpage1 = (vofs1 >> VESAVars.granshift);
    vpage2 = (vofs2 >> VESAVars.granshift);
    vofs1 &= VESAVars.granmask;
    vofs2 &= VESAVars.granmask;

    if (vpage1 != VESAVars.pagecache)
    {
      VESA_Func05(vpage1);
      VESAVars.pagecache = vpage1;
    }

    if (vpage1 != vpage2)
    {
      temp = (VESAVars.granmask + 1) - vofs1;
      DWordMemCpy(sprite_data, (char *)(VESAVars.VGAScreen + vofs1), temp);
      sprite_data += temp;

      VESA_Func05(vpage2);
      VESAVars.pagecache = vpage2;
      DWordMemCpy(sprite_data, (char *)(VESAVars.VGAScreen), draw_width - temp);
      sprite_data += (width - temp);
    }
    else
    {
      DWordMemCpy(sprite_data, (char *)(VESAVars.VGAScreen + vofs1), draw_width);
      sprite_data += width;
    }
  }
}

void GetImageLFB(int x1, int y1, int x2, int y2, Sprite *Spr)
{
  int  width, height;
  int  draw_width, draw_height;
  int  i, sx, sy, tx, ty;
  char *sprite_data;
  int vofs1;
  int yofs;

  Spr->Width  = (x2 - x1 + 1);
  Spr->Height = (y2 - y1 + 1);
  width  = Spr->Width;
  height = Spr->Height;

  tx = x1 + width;
  ty = y1 + height;

  // make sure is on screen
  if ((tx < 0) || (x1 >= (VESAVars.maxx))) return;
  if ((ty < 0) || (y1 >= (VESAVars.maxy))) return;

  sx = 0;
  sy = 0;

  // left clipping
  if (tx < width)
  {
    draw_width = tx;
    sx = -x1;
    x1 = 0;
  }
  else draw_width = width;

  // right clipping
  if (tx > (VESAVars.maxx)) draw_width -= (tx - (VESAVars.maxx));

  // top clipping
  if (ty < height)
  {
    draw_height = ty;
    sy = -y1;
    y1 = 0;
  }
  else draw_height = height;

  // bottom clipping
  if (ty > (VESAVars.maxy)) draw_height -= (ty - (VESAVars.maxy));

  // set pointer to sprite data
  sprite_data = (char *)(&(Spr->Data[sy*width + sx]));

  tx = width - draw_width;
  ty = (VESAVars.maxx) - draw_width;

  for (i = sy, yofs = (y1*VESAVars.linesize); i < (sy+draw_height); i++, yofs+=VESAVars.linesize)
  {
    vofs1 = (yofs + x1);
    DWordMemCpy(sprite_data, (char *)(VESAVars.VGAScreen + vofs1), draw_width);
    sprite_data += width;
  }
}


void PutImageBankedTrans(int x, int y, Sprite *Spr)
{
  int  width, height;
  int  draw_width, draw_height;
  int  i, j, sx, sy, tx, ty;
  char t;
  char *sprite_data;
  int vpage1, vpage2, vofs1, vofs2;
  int temp;
  int yofs;

  // get the height and width of the sprite
  width  = Spr->Width;
  height = Spr->Height;

  tx = x + width;
  ty = y + height;

  // make sure is on screen
  if ((tx < 0) || (x >= (VESAVars.maxx))) return;
  if ((ty < 0) || (y >= (VESAVars.maxy))) return;

  sx = 0;
  sy = 0;

  // left clipping
  if (tx < width)
  {
    draw_width = tx;
    sx = -x;
    x = 0;
  }
  else draw_width = width;

  // right clipping
  if (tx > (VESAVars.maxx)) draw_width -= (tx - (VESAVars.maxx));

  // top clipping
  if (ty < height)
  {
    draw_height = ty;
    sy = -y;
    y = 0;
  }
  else draw_height = height;

  // bottom clipping
  if (ty > (VESAVars.maxy)) draw_height -= (ty - (VESAVars.maxy));

  // set pointer to sprite data
  sprite_data = (char *)(&(Spr->Data[sy*width + sx]));

  tx = width - draw_width;
  ty = (VESAVars.maxx) - draw_width;

  for (i = sy, yofs = (y*VESAVars.linesize); i < (sy+draw_height); i++, yofs+=VESAVars.linesize)
  {
    vofs1 = (yofs + x);
    vofs2 = (yofs + x + draw_width - 1);
    vpage1 = (vofs1 >> VESAVars.granshift);
    vpage2 = (vofs2 >> VESAVars.granshift);
    vofs1 &= VESAVars.granmask;
    vofs2 &= VESAVars.granmask;

    if (vpage1 != VESAVars.pagecache)
    {
      VESA_Func05(vpage1);
      VESAVars.pagecache = vpage1;
    }

    if (vpage1 != vpage2)
    {
      temp = (VESAVars.granmask + 1) - vofs1;
      for (j = sx; j < (sx+temp); j++)
      {
        t = *sprite_data++;
        if (t != 0) *(char *)(VESAVars.VGAScreen + vofs1) = t;
        vofs1++;
      }

      VESA_Func05(vpage2);
      VESAVars.pagecache = vpage2;
      vofs1 = 0;
      for (j = (sx+temp); j < (sx+draw_width); j++)
      {
        t = *sprite_data++;
        if (t != 0) *(char *)(VESAVars.VGAScreen + vofs1) = t;
        vofs1++;
      }
    }
    else
    {
      for (j = sx; j < (sx+draw_width); j++)
      {
        t = *sprite_data++;
        if (t != 0) *(char *)(VESAVars.VGAScreen + vofs1) = t;
        vofs1++;
      }
    }
    sprite_data+=tx;
  }
}

void PutImageBankedAll(int x, int y, Sprite *Spr)
{
  int  width, height;
  int  draw_width, draw_height;
  int  i, sx, sy, tx, ty;
  char *sprite_data;
  int vpage1, vpage2, vofs1, vofs2;
  int temp;
  int yofs;

  // get the height and width of the sprite
  width  = Spr->Width;
  height = Spr->Height;

  tx = x + width;
  ty = y + height;

  // make sure is on screen
  if ((tx < 0) || (x >= (VESAVars.maxx))) return;
  if ((ty < 0) || (y >= (VESAVars.maxy))) return;

  sx = 0;
  sy = 0;

  // left clipping
  if (tx < width)
  {
    draw_width = tx;
    sx = -x;
    x = 0;
  }
  else draw_width = width;

  // right clipping
  if (tx > (VESAVars.maxx)) draw_width -= (tx - (VESAVars.maxx));

  // top clipping
  if (ty < height)
  {
    draw_height = ty;
    sy = -y;
    y = 0;
  }
  else draw_height = height;

  // bottom clipping
  if (ty > (VESAVars.maxy)) draw_height -= (ty - (VESAVars.maxy));

  // set pointer to sprite data
  sprite_data = (char *)(&(Spr->Data[sy*width + sx]));

  tx = width - draw_width;
  ty = (VESAVars.maxx) - draw_width;

  for (i = sy, yofs = (y*VESAVars.linesize); i < (sy+draw_height); i++, yofs+=VESAVars.linesize)
  {
    vofs1 = (yofs + x);
    vofs2 = (yofs + x + draw_width - 1);
    vpage1 = (vofs1 >> VESAVars.granshift);
    vpage2 = (vofs2 >> VESAVars.granshift);
    vofs1 &= VESAVars.granmask;
    vofs2 &= VESAVars.granmask;

    if (vpage1 != VESAVars.pagecache)
    {
      VESA_Func05(vpage1);
      VESAVars.pagecache = vpage1;
    }

    if (vpage1 != vpage2)
    {
      temp = (VESAVars.granmask + 1) - vofs1;
      DWordMemCpy((char *)(VESAVars.VGAScreen + vofs1), sprite_data, temp);
      sprite_data += temp;

      VESA_Func05(vpage2);
      VESAVars.pagecache = vpage2;
      DWordMemCpy((char *)(VESAVars.VGAScreen), sprite_data, draw_width - temp);
      sprite_data += (width - temp);
    }
    else
    {
      DWordMemCpy((char *)(VESAVars.VGAScreen + vofs1), sprite_data, draw_width);
      sprite_data += width;
    }
  }
}

void PutImageLFBTrans(int x, int y, Sprite *Spr)
{
  int  width, height;
  int  draw_width, draw_height;
  int  i, j, sx, sy, tx, ty;
  char t;
  char *sprite_data;
  int vofs1;
  int yofs;

  // get the height and width of the sprite
  width  = Spr->Width;
  height = Spr->Height;

  tx = x + width;
  ty = y + height;

  // make sure is on screen
  if ((tx < 0) || (x >= (VESAVars.maxx))) return;
  if ((ty < 0) || (y >= (VESAVars.maxy))) return;

  sx = 0;
  sy = 0;

  // left clipping
  if (tx < width)
  {
    draw_width = tx;
    sx = -x;
    x = 0;
  }
  else draw_width = width;

  // right clipping
  if (tx > (VESAVars.maxx)) draw_width -= (tx - (VESAVars.maxx));

  // top clipping
  if (ty < height)
  {
    draw_height = ty;
    sy = -y;
    y = 0;
  }
  else draw_height = height;

  // bottom clipping
  if (ty > (VESAVars.maxy)) draw_height -= (ty - (VESAVars.maxy));

  // set pointer to sprite data
  sprite_data = (char *)(&(Spr->Data[sy*width + sx]));

  tx = width - draw_width;
  ty = (VESAVars.maxx) - draw_width;

  for (i = sy, yofs = (y*VESAVars.linesize); i < (sy+draw_height); i++, yofs+=VESAVars.linesize)
  {
    vofs1 = (yofs + x);

    for (j = sx; j < (sx+draw_width); j++)
    {
      t = *sprite_data++;
      if (t != 0) *(char *)(VESAVars.VGAScreen + vofs1) = t;
      vofs1++;
    }
    sprite_data+=tx;
  }
}

void PutImageLFBAll(int x, int y, Sprite *Spr)
{
  int  width, height;
  int  draw_width, draw_height;
  int  i, sx, sy, tx, ty;
  char *sprite_data;
  int vofs1;
  int yofs;

  // get the height and width of the sprite
  width  = Spr->Width;
  height = Spr->Height;

  tx = x + width;
  ty = y + height;

  // make sure is on screen
  if ((tx < 0) || (x >= (VESAVars.maxx))) return;
  if ((ty < 0) || (y >= (VESAVars.maxy))) return;

  sx = 0;
  sy = 0;

  // left clipping
  if (tx < width)
  {
    draw_width = tx;
    sx = -x;
    x = 0;
  }
  else draw_width = width;

  // right clipping
  if (tx > (VESAVars.maxx)) draw_width -= (tx - (VESAVars.maxx));

  // top clipping
  if (ty < height)
  {
    draw_height = ty;
    sy = -y;
    y = 0;
  }
  else draw_height = height;

  // bottom clipping
  if (ty > (VESAVars.maxy)) draw_height -= (ty - (VESAVars.maxy));

  // set pointer to sprite data
  sprite_data = (char *)(&(Spr->Data[sy*width + sx]));

  tx = width - draw_width;
  ty = (VESAVars.maxx) - draw_width;

  for (i = sy, yofs = (y*VESAVars.linesize); i < (sy+draw_height); i++, yofs+=VESAVars.linesize)
  {
    vofs1 = (yofs + x);
    DWordMemCpy((char *)(VESAVars.VGAScreen + vofs1), sprite_data, draw_width);
    sprite_data += width;
  }
}
