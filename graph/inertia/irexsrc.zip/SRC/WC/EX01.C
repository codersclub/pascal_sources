#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "types.h"
#include "inertia.h"
#include "mode13h.h"

ViewObject   View;  /* The View System */
VectorObject Obj;   /* A vector object */

main()
{
  InitInertia();

  if (LoadPalette("COPPRENV.PAL", 0) != I_OK)       /* load the palette */
    {
      printf("Error loading Palette.\n");
      exit(0);
    }
  if (LoadIntensityTable("COPPRENV.IT", 0) != I_OK) /* load intensity table */
    {
      printf("Error loading Intensity table.\n");
      exit(0);
    }
  if (LoadGVO(&Obj, "TORUS.GVO", 0) != I_OK)        /* load the vector object */
    {
      printf("Error loading TORUS object.\n");
      exit(0);
    }

  InitView(&View);  /* init the view */

  InitMode13h();

  SetMode(0x13);              /* Set graphics mode */
  SetPalette((char *)GlobalPalette); /* Set the palette */

  SetAbsoluteLocation(&Obj, 0, 0, Obj.Radius * 2); /* Set the object's location */
  PushLightSource(0, 0, -1);  /* Add a light source */

  SetRenderMask(&Obj, SMOOTH | LAMBERT);    /* set smooth surface */

  SetBaseColor(&Obj, 36);      /* set the object's color */

  do
    {
      SetDeltaRotation(&Obj, 0.01, 0.02, 0.03);  /* rotate the object  */
      AddtoRenderList(&View, &Obj);      /* add it to the view */
      Render(VirtualPage, 320, 200);   /* render to the virtual page */
      Flip();                            /* Copy the page over */
    }
  while (!kbhit());

  FreeView(&View);         /* Free the view's allocated memory */
  FreeVectorObject(&Obj);  /* free the vector object's allocated memory */
  FreeIntensityTable();    /* free the intensity table from memory */

  SetMode(0x03);           /* return to text mode */

  ShutdownInertia();
}
