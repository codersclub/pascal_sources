#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "types.h"
#include "inertia.h"
#include "mode13h.h"

ViewObject   View;   /* The View System */
VectorObject Obj1;   /* A vector object */
VectorObject Obj2;   /* A vector object */
int          i;

main()
{
  InitInertia();

  if (LoadPCXTexture(0, "COPPRENV.PCX", 0) != I_OK)       /* load the texture */
    {
      printf("Error loading texture.\n");
      exit(0);
    }
  GetTexturePalette(0);   /* get the texture's palette */
  if (LoadIntensityTable("COPPRENV.IT", 0) != I_OK) /* load intensity table */
    {
      printf("Error loading Intensity table.\n");
      exit(0);
    }
  if (LoadTransparencyTable("COPPRENV.TT", 0) != I_OK) /* load transparency table */
    {
      printf("Error loading transparency table.\n");
      exit(0);
    }
  if (LoadGVO(&Obj1, "TORUSA.GVO", 0) != I_OK)         /* load the vector object */
    {
      printf("Error loading TORUS object.\n");
      exit(0);
    }
  if (LoadGVO(&Obj2, "TORUSB.GVO", 0) != I_OK)         /* load the second vector object */
    {
      printf("Error loading TORUS object.\n");
      exit(0);
    }

  InitView(&View);   /* init the view */

  InitMode13h();
  SetMode(0x13);              /* Set graphics mode */

  SetPalette((char *)GlobalPalette); /* Set the palette */

  SetAbsoluteLocation(&Obj1, 0, 0, Obj1.Radius * 2); /* Set the object's location */
  SetAbsoluteLocation(&Obj2, 0, 0, Obj2.Radius * 2); /* Set the object's location */
  PushLightSource(0, 0, -1);  /* Add a light source */

  SetRenderMask(&Obj1, TRANSPARENT | SMOOTH | GOURAUD);    /* set smooth surface */
  SetCull(&Obj1, 0);        /* turn off Object 1 culling */
  SetBaseColor(&Obj1, 36);

  SetRenderMask(&Obj2, GOURAUD | TEXTURE);    /* set texture surface */
  SetObjectTexture(&Obj2, 0);


  do
    {
      SetDeltaRotation(&Obj1, 0.01, 0.02, 0.03);  /* rotate the object  */
      SetDeltaRotation(&Obj2, 0.01, 0.02, 0.03);  /* rotate the object  */
      AddtoRenderList(&View, &Obj1);      /* add it to the view */
      AddtoRenderList(&View, &Obj2);      /* add it to the view */
      Render(VirtualPage, 320, 200);       /* render to the virtual page */
      Flip();                            /* Copy the page over */
    }
  while (!kbhit());

  FreeView(&View);         /* Free the view's allocated memory */
  FreeVectorObject(&Obj1);  /* free the vector object's allocated memory */
  FreeVectorObject(&Obj2);  /* free the vector object's allocated memory */
  FreeIntensityTable();     /* free the intensity table from memory */

  FreeTexture(0);         /* Free the phong map */

  SetMode(0x03);           /* return to text mode */

  ShutdownInertia();
}
