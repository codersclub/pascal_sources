/*
�����������������������������������������������������������������������������
                   Inertia/32 Realtime 3D Rendering Engine
           Copyright (c) 1996, 1997 Alex Chalfin. All Rights Reserved.
�����������������������������������������������������������������������������
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "inertia.h"

typedef struct
{
  float Ambient;
  float Diffuse;
  float Specular;
  float Gloss;

  float AmbientFraction;

  float Gamma;

  int   SpecularRed;
  int   SpecularBlue;
  int   SpecularGreen;

  char  InFileName[64];
  char  OutFileName[64];
} ParseStruct;

int  SaveShadeTable(char *ShadeTable8, ParseStruct *Parms);
char *BuildShadeTable(char *Pal, char *Shade24);
char *Build24BitShadeTable(char *Pal, ParseStruct *Parms);
void ParseCommandLine(int argc, char **argv, ParseStruct *Parms);
void BuildGammaTable(ParseStruct *Parms);
void DisplayHelp();

char GammaTable[256];

main(int argc, char **argv)
{
  ParseStruct Parms;
  char *Pal;
  char *ShadeTable24;
  char *ShadeTable8;


  ParseCommandLine(argc, argv, &Parms);

  BuildGammaTable(&Parms);

  InitInertia;

  if (LoadPCXTexture(0, Parms.InFileName, 0) != I_OK)
    {
      printf("Error! Could not load input image file: \"%s\"\n", Parms.InFileName);
      exit(0);
    }

  Pal = (char *)TextureList[0].Pal;

  ShadeTable24 = Build24BitShadeTable(Pal, &Parms);

  if (ShadeTable24 == NULL)
    {
      printf("Error! 24-bit shade table could not be created.\n");
      exit(0);
    }

  ShadeTable8 = BuildShadeTable(Pal, ShadeTable24);
  if (ShadeTable8 == NULL)
    {
      free(ShadeTable24);
      printf("Error! 8-bit shade table could not be created.\n");
      exit(0);
    }

  SaveShadeTable(ShadeTable8, &Parms);

  free(ShadeTable8);
  free(ShadeTable24);

  FreeTexture(0);

  ShutDownInertia;
}

void BuildGammaTable(ParseStruct *Parms)
{
  int i;

  for (i = 0; i < 256; i++)
    GammaTable[i] = (int)(pow((float)i/255.0, 1.0/Parms->Gamma)*63.0);
}

int SaveShadeTable(char *ShadeTable8, ParseStruct *Parms)
{
  FILE *fp;
  int i;

  fp = fopen(Parms->OutFileName, "wb");

  if (fp == NULL)
    return(0);

  for (i = 63; i >= 0; i--)
    fwrite(&ShadeTable8[i * 256], 1, 256, fp);

  fclose(fp);

  return(1);
}

char *BuildShadeTable(char *Pal, char *Shade24)
{
  int i, j;
  int Error, TempError;
  int Match;
  char *Img;

  Img = (char *)malloc(256 * 64);

  if (Img == NULL)
    return(NULL);

  for (i = 0; i < (256 * 64); i++)
    {
      Error = (1 << 30);
      Match = 0;

      for (j = 0; j < 256; j++)
        {
          TempError = SQR((int)Pal[j*3+0] - GammaTable[(int)Shade24[i*3+2]]) +
                      SQR((int)Pal[j*3+1] - GammaTable[(int)Shade24[i*3+1]]) +
                      SQR((int)Pal[j*3+2] - GammaTable[(int)Shade24[i*3+0]]);

          if (TempError < Error)
            {
              Match = j;
              Error = TempError;
            }
        }

      Img[i] = (char)Match;
    }

  return(Img);
}

char *Build24BitShadeTable(char *Pal, ParseStruct *Parms)
{
  char *Img;
  int  color, inten;
  float sina;
  float psina;
  float  sr, sg, sb;
  float  dr, dg, db;
  float  ar, ag, ab;

  Img = malloc(256 * 64 * 3);

  if (Img == NULL)
    return(NULL);

  for (color = 0; color < 256; color++)
    {
      sr = Parms->SpecularRed;
      sg = Parms->SpecularGreen;
      sb = Parms->SpecularBlue;

      dr = Pal[color*3] * 4;
      dg = Pal[color*3+1] * 4;
      db = Pal[color*3+2] * 4;

      ar = dr * Parms->AmbientFraction;
      ab = dg * Parms->AmbientFraction;
      ag = db * Parms->AmbientFraction;

      for (inten = 0; inten < 64; inten++)
        {
          sina = sin(((float)inten) * PI / 128.0);
          psina = pow(sina, Parms->Gloss);

          Img[(color + inten * 256)*3+2] = (char)(ar * Parms->Ambient + sina * dr * Parms->Diffuse + psina * sr * Parms->Specular);
          Img[(color + inten * 256)*3+1] = (char)(ag * Parms->Ambient + sina * dg * Parms->Diffuse + psina * sg * Parms->Specular);
          Img[(color + inten * 256)*3+0] = (char)(ab * Parms->Ambient + sina * db * Parms->Diffuse + psina * sb * Parms->Specular);
        }
    }

  return(Img);
}

void ParseCommandLine(int argc, char **argv, ParseStruct *Parms)
{
  int   i;
  int   iFlag = 0;
  int   oFlag = 0;
  char  *sptr;
  float Sum;

  printf("STab - Shade Table Generator                  Alex Chalfin 10/6/97\n");

  if (argc < 2)
    DisplayHelp();

  /* set some defaults */
  Parms->Ambient  = 0.0;
  Parms->Diffuse  = 1.0;
  Parms->Specular = 0.0;
  Parms->Gloss    = 30.0;

  Parms->AmbientFraction = 3.0 / 5.0;

  Parms->SpecularRed   = 255;
  Parms->SpecularBlue  = 255;
  Parms->SpecularGreen = 255;

  Parms->Gamma         = 1.0;

  /* read in the parameters */
  for (i = 1; i < argc; i++)
    {
      if ((argv[i][0] == '-') || (argv[i][0] == '/'))
        {
          switch (argv[i][1])
            {
              case '?' : DisplayHelp();
              case 'h' : DisplayHelp();
              case 'a' : Parms->Ambient = atof(&argv[i][2]);  break;
              case 'd' : Parms->Diffuse = atof(&argv[i][2]);  break;
              case 's' : Parms->Specular = atof(&argv[i][2]); break;
              case 'g' : Parms->Gloss    = atof(&argv[i][2]); break;
              case 'c' : if (strlen(argv[i]) > 2)
                           {
                             Parms->Gamma   = atof(&argv[i][2]);
                           }
                         else
                           {
                             Parms->Gamma   = 1.7;
                           }
                         break;
            }
        }
      else
        {
          if (iFlag)
            {
              if (!oFlag)
                {
                  oFlag = 1;
                  strcpy(Parms->OutFileName, argv[i]);
                }
            }
          else
            {
              iFlag = 1;
              strcpy(Parms->InFileName, argv[i]);
            }
        }
    }

  if (!iFlag)
    {
      printf("Error! input file not specified\n");
      exit(0);
    }

  if (strchr(Parms->InFileName, '.') == NULL)
    {
      sprintf(Parms->InFileName, "%s.pcx", Parms->InFileName);
    }

  if (!oFlag)
    {
      strcpy(Parms->OutFileName, Parms->InFileName);
      sptr = strchr(Parms->OutFileName, '.');

      sprintf(sptr, ".it");
    }

  Sum = Parms->Ambient + Parms->Diffuse + Parms->Specular;

  Parms->Ambient  /= Sum;
  Parms->Diffuse  /= Sum;
  Parms->Specular /= Sum;

  Parms->Gloss = CLIP(Parms->Gloss, 0, 255);
}

void DisplayHelp()
{
  printf("Usage: STab {file} {options}\n");
  printf("Options: (preceded by '/' or '-')\n");
  printf("\n");
  printf("                 [File Specifiers]\n");
  printf("{file} specifies <infile> [outfile]\n");
  printf("   <infile>: input texture file (.PCX is default extention)\n");
  printf("   <outfile>: optional intensity table file (.IT is default extention)\n");
  printf("\n");
  printf("                 [Phong Options]\n");
  printf(" /a#  where # is ambient value.  Default 0.00\n");
  printf(" /d#  where # is diffuse value.  Default 1.00\n");
  printf(" /s#  where # is specular value. Default 0.00\n");
  printf(" /g#  where # is gloss value.    Default 30\n");
  printf("\n");
  printf("                 [Other Options]\n");
  printf(" /C[#] use gamma correction on the palette. Default 1.7\n");
  printf("\n");
  printf("                 [Help]\n");
  printf(" [/h | /?]  displays this help.\n");
  exit(0);
}
