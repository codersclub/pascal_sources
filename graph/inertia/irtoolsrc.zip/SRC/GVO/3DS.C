#include <stdio.h>
#include <stdlib.h>
#include "3ds.h"
#include "modelapi.h"

typedef struct
{
  unsigned short ID;
  unsigned long  Len;
} tBlock;


/*======================================================================*
  Load3DS - Loads a 3ds file into memory
  Returns : 0 - File loaded properly        
            1 - Error opening file          
            2 - Error reading from file     
            3 - Too many verticies in file  
            4 - Too many polygons in file   
            5 - Not enough memory
 *======================================================================*/
int Load3DS(char *Filename, int *TextureCoordFlag)
{
  int            i;
  FILE          *fp;
  tBlock         Block;
  int            Location;
  char           TempChar;
  int            Temp;
  unsigned short NumPoly;
  unsigned short NumVert;
  fVertex3d      TempVert;
  Triangle       TempPoly;
  TextureCoord   TempUV;
  int            EndPos;

  *TextureCoordFlag = 0;

  fp = fopen(Filename, "rb");
  if (fp == NULL)
    return (1);

  fseek(fp, 0, SEEK_END);
  EndPos = ftell(fp);
  fseek(fp, 0, SEEK_SET);

  Location = ftell(fp);

  while (Location < EndPos)
  {
    Location = ftell(fp);
    fread(&Block.ID, sizeof(unsigned short), 1, fp);
    fread(&Block.Len, sizeof(unsigned int),  1, fp);

    switch (Block.ID)
    {
      case 0x3d3d : break;           
      case 0x4d4d : break;           /* Do nothing when these blocks are encountered */
      case 0x4100 : NewObj(); break; /* Start a new object when this block is encountered */
      case 0x4110 : {                /* a vertex list is found */
                      fread(&NumVert, sizeof(short int), 1, fp);
                      for (i = 0; i < NumVert; i++)
                      {
                        fread(&TempVert.x, sizeof(float), 1, fp);
                        fread(&TempVert.y, sizeof(float), 1, fp);
                        fread(&TempVert.z, sizeof(float), 1, fp);
                        AddVertex(TempVert.x, TempVert.y, TempVert.z);
                      }
 
                      fseek(fp, Location + Block.Len, SEEK_SET);
                    } break;
      case 0x4120 : {                /* load a polygon list */
                      fread(&NumPoly, sizeof(short int), 1, fp);
                      for (i = 0; i < NumPoly; i++)
                      {
                        fread(&TempPoly.a, sizeof(short int), 1, fp);
                        fread(&TempPoly.b, sizeof(short int), 1, fp);
                        fread(&TempPoly.c, sizeof(short int), 1, fp);
                        fread(&Temp,       sizeof(short int), 1, fp);
                        AddPolygon(TempPoly.a, TempPoly.b, TempPoly.c);
                      }
                      fseek(fp, Location + Block.Len, SEEK_SET);
                    } break;
 
      case 0x4140 : {               /* Load Texture Coordinates */
                      *TextureCoordFlag = 1;
                      fread(&NumVert, sizeof(short int), 1, fp);
                      for (i = 0; i < NumVert; i++)
                      {
                        fread(&TempUV.u, sizeof(float), 1, fp);
                        fread(&TempUV.v, sizeof(float), 1, fp);
                        AddUV(TempUV.u, TempUV.v);
                      }
                      fseek(fp, Location + Block.Len, SEEK_SET);
                    } break;
      case 0x4000 : {
                      fread(&TempChar, sizeof(char), 1, fp);
                      while (TempChar != 0)
                        fread(&TempChar, sizeof(char), 1, fp);
                    } break;
      default     : fseek(fp, Location + Block.Len, SEEK_SET); break;
    }
  }

  fclose(fp);
  return(0);
}
