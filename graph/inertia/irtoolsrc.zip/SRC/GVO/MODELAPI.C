#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "modelapi.h"

typedef struct _tFVertCluster
{
  int                    Count;
  struct _tFVertCluster *Next;
  fVertex3d              V[256];
  fVertex3d              N[256];
} tFVertCluster;


typedef struct _tPolygonCluster
{
  int Count;
  struct _tPolygonCluster *Next;
  Triangle                 P[256];
  fVertex3d                N[256];
} tPolygonCluster;

typedef struct _tTextureCluster
{
  int                      Count;
  struct _tTextureCluster *Next;
  TextureCoord             T[256];
} tTextureCluster;

typedef struct _tObj
{
  tFVertCluster   *Vert;
  tPolygonCluster *Poly;
  int              NumVert;
  int              NumPoly;
  tTextureCluster *Tex;
  struct _tObj    *Next;
} tObj;


tObj *ObjList;
tObj *ObjCurr;

void IntClip(float Value, short int *RetInt, int *RetFlag, int RangeLow, int RangeHigh)
{
  if (Value < RangeLow)
  {
    *RetFlag = 1;
    *RetInt  = RangeLow;
  }
  else
  {
    if (Value > RangeHigh)
    {
      *RetFlag = 1;
      *RetInt  = RangeHigh;
    }
    else
    {
      *RetInt  = (int)Value;
    }
  }
}

/*=======================================================================*
  InitModeller - initializes the object database
 *=======================================================================*/
void InitModeller()
{
  ObjList = NULL;
  ObjCurr = NULL;
}

/*=======================================================================*
  NewObj - adds a new object to the database
 *=======================================================================*/
void NewObj()
{
  tObj *TempObj;

  TempObj = (tObj *)malloc(sizeof(tObj));

  TempObj->NumVert = 0;
  TempObj->NumPoly = 0;
  TempObj->Vert    = NULL;
  TempObj->Poly    = NULL;
  TempObj->Tex     = NULL;

  TempObj->Next    = ObjList;
  ObjList          = TempObj;
  ObjCurr          = TempObj;
}


/*=======================================================================*
  AddVertex - adds a vertex to the current model
 *=======================================================================*/
void AddVertex(float x, float y, float z)
{
  tFVertCluster *TempVert;
  tFVertCluster *Traverse;


  if (ObjCurr->Vert == NULL)
  {
    TempVert = (tFVertCluster *)malloc(sizeof(tFVertCluster));
    TempVert->Count  = 1;
    TempVert->V[0].x = x;
    TempVert->V[0].y = y;
    TempVert->V[0].z = z;
    TempVert->Next   = NULL;
    ObjCurr->Vert    = TempVert;
  }
  else
  {
    Traverse = ObjCurr->Vert;

    while ((Traverse->Count == 256) && (Traverse->Next != NULL))
      Traverse = Traverse->Next;

    if (Traverse->Count == 256)
    {
      TempVert = (tFVertCluster *)malloc(sizeof(tFVertCluster));
      TempVert->Count  = 1;
      TempVert->V[0].x = x;
      TempVert->V[0].y = y;
      TempVert->V[0].z = z;
      TempVert->Next   = NULL;
      Traverse->Next   = TempVert;
    }
    else
    {
      Traverse->V[Traverse->Count].x = x;
      Traverse->V[Traverse->Count].y = y;
      Traverse->V[Traverse->Count].z = z;
      Traverse->Count++;
    }
  }

  ObjCurr->NumVert++;
}

/*=======================================================================*
  AddPolygon - adds a polygon to the current object
 *=======================================================================*/
void AddPolygon(int a, int b, int c)
{
  tPolygonCluster *TempPoly;
  tPolygonCluster *Traverse;

  if (ObjCurr->Poly == NULL)
  {
    TempPoly = (tPolygonCluster *)malloc(sizeof(tPolygonCluster));
    TempPoly->Count  = 1;
    TempPoly->P[0].a = a;
    TempPoly->P[0].b = b;
    TempPoly->P[0].c = c;
    TempPoly->Next   = NULL;
    ObjCurr->Poly    = TempPoly;
  }
  else
  {
    Traverse = ObjCurr->Poly;

    while ((Traverse->Count == 256) && (Traverse->Next != NULL))
      Traverse = Traverse->Next;

    if (Traverse->Count == 256)
    {
      TempPoly = (tPolygonCluster *)malloc(sizeof(tPolygonCluster));  
      TempPoly->Count  = 1;
      TempPoly->P[0].a = a;
      TempPoly->P[0].b = b;
      TempPoly->P[0].c = c;
      TempPoly->Next   = NULL;
      Traverse->Next   = TempPoly;
    }
    else
    {
      Traverse->P[Traverse->Count].a = a;
      Traverse->P[Traverse->Count].b = b;
      Traverse->P[Traverse->Count].c = c;
      Traverse->Count++;
    }
  }    

  ObjCurr->NumPoly++;
}


/*=======================================================================*
  AddUV - adds a UV texture coordinate to the current object
 *=======================================================================*/
void AddUV(float u, float v)
{
  tTextureCluster *TempTex;
  tTextureCluster *Traverse;


  if (u > 1000)  u = 1000;
  if (u < -1000) u = -1000;
  if (v > 1000)  v = 1000;
  if (v < -1000) v = -1000;

  if (ObjCurr->Tex == NULL)
  {
    TempTex = (tTextureCluster *)malloc(sizeof(tTextureCluster));
    TempTex->Count  = 1;
    TempTex->T[0].u = u;
    TempTex->T[0].v = v;
    TempTex->Next   = NULL;
    ObjCurr->Tex    = TempTex;
  }
  else
  {
    Traverse = ObjCurr->Tex;
    while ((Traverse->Count == 256) && (Traverse->Next != NULL))
      Traverse = Traverse->Next;

    if (Traverse->Count == 256)
    {
      TempTex = (tTextureCluster *)malloc(sizeof(tTextureCluster));
      TempTex->Count  = 1;
      TempTex->T[0].u = u;
      TempTex->T[0].v = v;
      TempTex->Next   = NULL;
      Traverse->Next  = TempTex;
    }
    else
    {
      Traverse->T[Traverse->Count].u = u;
      Traverse->T[Traverse->Count].v = v;
      Traverse->Count++;
    }
  }
}

/*=======================================================================*
  GetPolygon - returns a polygon and normal
 *=======================================================================*/
void GetPolygon(tPolygonCluster *P, int Index, int *A, int *B, int *C, float *tx, float *ty, float *tz)
{
  tPolygonCluster *Traverse;
  int DivCount, ModCount;

  Traverse = P;
  DivCount = Index / 256;
  ModCount = Index % 256;

  while (DivCount > 0)
  {
    Traverse = Traverse->Next;
    DivCount--;
  }

  *A = Traverse->P[ModCount].a;
  *B = Traverse->P[ModCount].b;
  *C = Traverse->P[ModCount].c;

  *tx = Traverse->N[ModCount].x;
  *ty = Traverse->N[ModCount].y;
  *tz = Traverse->N[ModCount].z;
}


/*=======================================================================*
  GetUV - returns the UV coord of a vertex
 *=======================================================================*/
void GetUV(tTextureCluster *T, int Index, float *u, float *v)
{

  tTextureCluster *Traverse;
  int              DivCount, ModCount;


  if (T == NULL)
  {
   *u = 0.0;
   *v = 0.0;
   return;
  }

  Traverse = T;
  DivCount = Index / 256;
  ModCount = Index % 256;

  while (DivCount > 0)
  {
    Traverse = Traverse->Next;
    DivCount--;
  }

  *u = Traverse->T[ModCount].u;
  *v = Traverse->T[ModCount].v;
}


/*=======================================================================*
  GetVertex - returns the vertex an object
 *=======================================================================*/
void GetVertex(tFVertCluster *V, int Index, float *x, float *y, float *z)
{
  tFVertCluster *Traverse;
  int            DivCount, ModCount;

  Traverse = V;
  DivCount = Index / 256;
  ModCount = Index % 256;

  while (DivCount > 0)
  {
    Traverse = Traverse->Next;
    DivCount--;
  }

  *x = Traverse->V[ModCount].x;
  *y = Traverse->V[ModCount].y;
  *z = Traverse->V[ModCount].z;
}


/*=======================================================================*
  SetPolygonNormal - assigns the normal to the polygon
 *=======================================================================*/
void SetPolygonNormal(tPolygonCluster *P, int Index, float x, float y, float z)
{
  tPolygonCluster *Traverse;
  int              DivCount;
  int              ModCount;

  for (Traverse = P, DivCount = Index / 256, ModCount = Index % 256; DivCount > 0; Traverse = Traverse->Next, DivCount--);

  Traverse->N[ModCount].x = x;
  Traverse->N[ModCount].y = y;
  Traverse->N[ModCount].z = z;
}

/*=======================================================================*
  SetVertex - assigns a vertex to the object
 *=======================================================================*/
void SetVertex(tFVertCluster *P, int Index, float x, float y, float z)
{
  tFVertCluster *Traverse;
  int DivCount, ModCount;

  Traverse = P;
  DivCount = Index / 256;
  ModCount = Index % 256;

  while (DivCount > 0)
  {
    Traverse = Traverse->Next;
    DivCount--;
  }

  Traverse->V[ModCount].x = x;
  Traverse->V[ModCount].y = y;
  Traverse->V[ModCount].z = z;
}

/*=======================================================================*
  SetVertexNormal - assigns a vertex to the object
 *=======================================================================*/
void SetVertexNormal(tFVertCluster *P, int Index, float x, float y, float z)
{
  tFVertCluster *Traverse;
  int DivCount, ModCount;

  Traverse = P;
  DivCount = Index / 256;
  ModCount = Index % 256;

  while (DivCount > 0)
  {
    Traverse = Traverse->Next;
    DivCount--;
  }

  Traverse->N[ModCount].x = x;
  Traverse->N[ModCount].y = y;
  Traverse->N[ModCount].z = z;
}

/*=======================================================================*
  CalcPolygonNorlams - calculates the normals to the polygons in an object
 *=======================================================================*/
int CalcPolygonNormals(tObj *O)
{
  int   i, RetCode;
  float x1, x2, x3;
  float y1, y2, y3;
  float z1, z2, z3;
  int   a,  b,  c;
  float nx, ny, nz;
  float Len;

  RetCode = 0;

  for (i = 0; i < O->NumPoly; i++)
  {
    GetPolygon(O->Poly, i, &a, &b, &c, &x1, &x2, &x3);
    GetVertex(O->Vert, a, &x1, &y1, &z1);
    GetVertex(O->Vert, b, &x2, &y2, &z2);
    GetVertex(O->Vert, c, &x3, &y3, &z3);
    nx  = (y2 - y1) * (z3 - z1) - (z2 - z1) * (y3 - y1);
    ny  = (z2 - z1) * (x3 - x1) - (x2 - x1) * (z3 - z1);
    nz  = (x2 - x1) * (y3 - y1) - (y2 - y1) * (x3 - x1);
    Len = sqrt(nx*nx + ny*ny + nz*nz);
    if (Len == 0)
    {
      RetCode = 1;
      SetPolygonNormal(O->Poly, i, 0, 0, 0);
    }
    else
    {
      SetPolygonNormal(O->Poly, i, nx/Len, ny/Len, nz/Len);
    }
  }

  return(RetCode);
}

/*=======================================================================*
  CalcVertexNorlams - calculates the normals to the vertices
 *=======================================================================*/
int CalcVertexNormals(tObj *O)
{
  int   i, j, RetCode;
  float x, y, z;
  float Len;
  tPolygonCluster *PolyTraverse;

  RetCode = 0;

  for (i = 0; i < O->NumVert; i++)
  {
    x = 0;
    y = 0;
    z = 0;

    for (PolyTraverse = O->Poly; PolyTraverse != NULL; PolyTraverse = PolyTraverse->Next)
      for (j = 0; j < PolyTraverse->Count; j++)
      {
        if ((PolyTraverse->P[j].a == i) || (PolyTraverse->P[j].b == i) || (PolyTraverse->P[j].c == i))
        {
          x += PolyTraverse->N[j].x;
          y += PolyTraverse->N[j].y;
          z += PolyTraverse->N[j].z;
        }
      }


    Len = sqrt(x*x + y*y + z*z);
    if (Len == 0)
    {
      RetCode = 1;
      SetVertexNormal(O->Vert, i, 0, 0, 0);
    }
    else
    {
      SetVertexNormal(O->Vert, i, x/Len, y/Len, z/Len);
    }
  }

  return(RetCode);
}

/*=======================================================================*
  CalcAllNormals - calculates the normals
 *=======================================================================*/
int CalcAllNormals(int Progress)
{
  tObj *Traverse;
  int   RetCode;
  int   RetFlag;
  int   ObjCount = 0;

  RetFlag  = 0;
  Traverse = ObjList;

  while (Traverse != NULL)
  {
    if (Progress)
      printf("Object  [%d] Polygon Normals [%d]\n", ObjCount, Traverse->NumPoly);

    if (RetCode = CalcPolygonNormals(Traverse))
      RetFlag = 1;

    if (Progress)
      printf("Object  [%d] Vertex  Normals [%d]\n", ObjCount, Traverse->NumVert);

    if (RetCode = CalcVertexNormals(Traverse))
      RetFlag = 1;

    ObjCount++;

    Traverse = Traverse->Next;
  }

  return(RetFlag);
}

/*=======================================================================*
  CenterObjects - centers the objects around the average point
 *=======================================================================*/
void CenterObjects(int Flag)
{
  tObj *TraverseObj;
  float x, y, z;
  int   count, i;
  float tx, ty, tz;


  if (!Flag)
    return;

  TraverseObj = ObjList;

  x = 0;
  y = 0;
  z = 0;
  count = 0;

  while (TraverseObj != NULL)
  {
    for (i = 0; i < TraverseObj->NumVert; i++)
    {
      GetVertex(TraverseObj->Vert, i, &tx, &ty, &tz);
      x += tx;
      y += ty;
      z += tz;
      count++;
    }

    TraverseObj = TraverseObj->Next;
  }

  x /= count;
  y /= count;
  z /= count;

  TraverseObj = ObjList;

  while (TraverseObj != NULL)
  {
    for (i = 0; i < TraverseObj->NumVert; i++)
    {
      GetVertex(TraverseObj->Vert, i, &tx, &ty, &tz);
      SetVertex(TraverseObj->Vert, i, tx - x, ty - y, tz - z);
    }

    TraverseObj = TraverseObj->Next;
  }
}

/*=======================================================================*
  WriteAllVertices - writes the vertex information to disk
 *=======================================================================*/
int WriteAllVertices(FILE *fp, int Scale)
{
  tObj       *ObjTraverse;
  int        VertTotal;
  tFVertCluster *VertTraverse;
  short int  TempInt;
  int        i;
  int        RetFlag;

  RetFlag     = 0;

  ObjTraverse = ObjList;
  VertTotal   = 0;

  for (ObjTraverse = ObjList; ObjTraverse != NULL; ObjTraverse = ObjTraverse->Next)
    VertTotal += ObjTraverse->NumVert;

  TempInt = VertTotal;

  fwrite(&TempInt, sizeof(short int), 1, fp);

  ObjTraverse = ObjList;

  while (ObjTraverse != NULL)
  {
    VertTraverse = ObjTraverse->Vert;
    while (VertTraverse != NULL)
    {
      for (i = 0; i < VertTraverse->Count; i++)
      {
        IntClip(Scale * VertTraverse->V[i].x, &TempInt, &RetFlag, -32767, 32767);
        fwrite(&TempInt, sizeof(short int), 1, fp);
        IntClip(Scale * VertTraverse->V[i].y, &TempInt, &RetFlag, -32767, 32767);
        fwrite(&TempInt, sizeof(short int), 1, fp);
        IntClip(Scale * VertTraverse->V[i].z, &TempInt, &RetFlag, -32767, 32767);
        fwrite(&TempInt, sizeof(short int), 1, fp);
      }

      VertTraverse = VertTraverse->Next;
    }

    ObjTraverse = ObjTraverse->Next;
  }

  return(RetFlag);
}

/*=======================================================================*
  WriteAllPolygons - writes the polygons to disk
 *=======================================================================*/
int WriteAllPolygons(FILE *fp)
{
  tObj            *ObjTraverse;
  int              PolyTotal;
  tPolygonCluster *PolyTraverse;
  int              VStart, i;
  short int        TempShort;


  ObjTraverse = ObjList;
  PolyTotal   = 0;

  while (ObjTraverse != NULL)
  {
    PolyTotal += ObjTraverse->NumPoly;
    ObjTraverse = ObjTraverse->Next;
  }

  TempShort = PolyTotal;

  fwrite(&TempShort, sizeof(short int), 1, fp);

  VStart = 0;
  ObjTraverse = ObjList;

  while (ObjTraverse != NULL)
  {
    PolyTraverse = ObjTraverse->Poly;

    while (PolyTraverse != NULL)
    {
      for (i = 0; i < PolyTraverse->Count; i++)
      {
        TempShort = PolyTraverse->P[i].a + VStart;
        fwrite(&TempShort, sizeof(short int), 1, fp);

        TempShort = PolyTraverse->P[i].b + VStart;
        fwrite(&TempShort, sizeof(short int), 1, fp);

        TempShort = PolyTraverse->P[i].c + VStart;
        fwrite(&TempShort, sizeof(short int), 1, fp);
      }

      PolyTraverse = PolyTraverse->Next;
    }

    VStart += ObjTraverse->NumVert;
    ObjTraverse = ObjTraverse->Next;
  }

  return(0);
}

/*=======================================================================*
  WriteAllPolygonNormals - writes the polygon normals to disk
 *=======================================================================*/
int WriteAllPolygonNormals(FILE *fp, int Fixed)
{
  tObj            *ObjTraverse;
  tPolygonCluster *PolyTraverse;
  int              i;
  short int        TempShort;


  ObjTraverse = ObjList;

  while (ObjTraverse != NULL)
  {
    PolyTraverse = ObjTraverse->Poly;

    while (PolyTraverse != NULL)
    {
      for (i = 0; i < PolyTraverse->Count; i++)
      {
        TempShort = (int)(PolyTraverse->N[i].x * Fixed);
        fwrite(&TempShort, sizeof(short int), 1, fp);

        TempShort = (int)(PolyTraverse->N[i].y * Fixed);
        fwrite(&TempShort, sizeof(short int), 1, fp);

        TempShort = (int)(PolyTraverse->N[i].z * Fixed);
        fwrite(&TempShort, sizeof(short int), 1, fp);
      }

      PolyTraverse = PolyTraverse->Next;
    }

    ObjTraverse = ObjTraverse->Next;
  }

  return(0);
}

/*=======================================================================*
  WriteAllVertexNormals - writes the vertex normals to disk
 *=======================================================================*/
int WriteAllVertexNormals(FILE *fp, int Fixed)
{
  tObj          *ObjTraverse;
  tFVertCluster *VertTraverse;
  int            i;
  short int      TempShort;


  ObjTraverse = ObjList;

  while (ObjTraverse != NULL)
  {
    VertTraverse = ObjTraverse->Vert;

    while (VertTraverse != NULL)
    {
      for (i = 0; i < VertTraverse->Count; i++)
      {
        TempShort = (int)(VertTraverse->N[i].x * Fixed);
        fwrite(&TempShort, sizeof(short int), 1, fp);

        TempShort = (int)(VertTraverse->N[i].y * Fixed);
        fwrite(&TempShort, sizeof(short int), 1, fp);

        TempShort = (int)(VertTraverse->N[i].z * Fixed);
        fwrite(&TempShort, sizeof(short int), 1, fp);
      }
      VertTraverse = VertTraverse->Next;
    }
    ObjTraverse = ObjTraverse->Next;
  }

  return (0);
}

/*=======================================================================*
  WriteAllTextureCoords - writes the texture coordiantes to disk
 *=======================================================================*/
int WriteAllTextureCoords(FILE *fp)
{
  tObj            *ObjTraverse;
  int              i;
  unsigned char    TempByte;
  float            tx, ty, tz;
  int              a, b, c;
  float            u1, v1, u2, v2, u3, v3;

  ObjTraverse = ObjList;

  while (ObjTraverse != NULL)
  {
    for (i = 0; i < ObjTraverse->NumPoly; i++)
    {
      GetPolygon(ObjTraverse->Poly, i, &a, &b, &c, &tx, &ty, &tz);
      GetUV(ObjTraverse->Tex, a, &u1, &v1);
      GetUV(ObjTraverse->Tex, b, &u2, &v2);
      GetUV(ObjTraverse->Tex, c, &u3, &v3);

      TempByte = (int)(u1 * 255) & 255;
      fwrite (&TempByte, sizeof(unsigned char), 1, fp);
      TempByte = (int)(v1 * 255) & 255;
      fwrite (&TempByte, sizeof(unsigned char), 1, fp);

      TempByte = (int)(u2 * 255) & 255;
      fwrite (&TempByte, sizeof(unsigned char), 1, fp);
      TempByte = (int)(v2 * 255) & 255;
      fwrite (&TempByte, sizeof(unsigned char), 1, fp);

      TempByte = (int)(u3 * 255) & 255;
      fwrite (&TempByte, sizeof(unsigned char), 1, fp);
      TempByte = (int)(v3 * 255) & 255;
      fwrite (&TempByte, sizeof(unsigned char), 1, fp);
    }

    ObjTraverse = ObjTraverse->Next;
  }

  return(0);
}

/*=======================================================================*
  SaveGVO - saves the GVO file
 *=======================================================================*/
int SaveGVO(char *Filename, int Scale, int Fixed, int TCF)
{
  char GVOLabel[3] = {'G', 'V', 'O'};
  FILE *fp;
  short int Flag;
  int   RetFlag;
  int   OverFlow;

  OverFlow = 0;

  fp = fopen(Filename, "wb");
  if (fp == NULL)
    return(1);

  if (TCF)
    Flag = 31;
  else
    Flag = 15;

  fwrite(GVOLabel, sizeof(GVOLabel), 1, fp);
  fwrite(&Flag, sizeof(short int), 1, fp);

  RetFlag = WriteAllVertices(fp, Scale);

  if (RetFlag != 0)
    OverFlow = 2;

  RetFlag = WriteAllPolygons(fp);
  RetFlag = WriteAllPolygonNormals(fp, Fixed);
  RetFlag = WriteAllVertexNormals(fp, Fixed);

  if (TCF)
    RetFlag = WriteAllTextureCoords(fp);

  fclose(fp);

  if (OverFlow == 2)
    return(2);
  else
    return(RetFlag);
}

/*=======================================================================*
  VerifySize - returns the size of the objects
 *=======================================================================*/
int VerifySize()
{
  tObj  *ObjTraverse;
  int    VertTotal;
  int    PolyTotal;

  VertTotal = 0;
  PolyTotal = 0;
  ObjTraverse = ObjList;

  while (ObjTraverse != NULL)
  {
    VertTotal += ObjTraverse->NumVert;
    PolyTotal += ObjTraverse->NumPoly;
    ObjTraverse = ObjTraverse->Next;
  }


  return ((VertTotal < 65536) && (PolyTotal < 65536));
}
