/*=========================================================================*
                   Inertia Realtime 3D Rendering Engine
         Copyright (c) 1996,97,98 Alex Chalfin. All Rights Reserved.
           DISTRIBUTION OF THIS SOURCE CODE IS STRICTLY PROHIBITED
 *=========================================================================*/


/*-------------------------------------------------------------------------*
  Includes
 *-------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include "3ds.h"
#include "asc.h"
#include "modelapi.h"
#include "version.inc"

/*-------------------------------------------------------------------------*
  Constants
 *-------------------------------------------------------------------------*/
#define  f3DS   0x00
#define  fASC   0x01
#define  fNULL  0xff
#define  FIXED  0x100

/*-------------------------------------------------------------------------*
  Global Variables
 *-------------------------------------------------------------------------*/
int  Scale            = 1;
int  TextureCoordFlag = 0;
int  Center           = 0;
int  InFileType       = fNULL;
char InFile[64];  
char OutFile[64];


/*-------------------------------------------------------------------------*
  Function Headers
 *-------------------------------------------------------------------------*/
void Quit(char *S);
void GetFileType();
void Help();
void UpStr(char *S);
void ParseCommandLine(int ParmCount, char **ParmStr);
void Convert();


/*=========================================================================*
  Main
 *=========================================================================*/
void main(int argc, char **argv)
{
  InitModeller();
  ParseCommandLine(argc, argv);
  Convert();
}

/*=========================================================================*
  Quit - prints out a message string and terminates the application
 *=========================================================================*/
void Quit(char *S)
{
  printf("%s\n", S);
  exit(0);
}

/*=========================================================================*
  GetFileType - returns the type of the input file based on its extension
 *=========================================================================*/
void GetFileType()
{
  FILE *fp = NULL;

  if (strchr(InFile, '.') != NULL)
    Quit ("File format could not be determined or file not found.");

  fp = fopen(strcat(InFile, ".3DS"), "rb");
  if (fp == NULL)
  {
    fp = fopen(strcat(InFile, ".ASC"), "r");
    if (fp == NULL)
      Quit("File format could not be determined or file not found.");
    else
      InFileType = fASC;
  }
  else
    InFileType = f3DS;

  if (fp != NULL)
    fclose(fp);
}


/*=========================================================================*
  Help - prints out the help message and terminates the application
 *=========================================================================*/
void Help()
{
  printf("Usage: GVO <file> {options}\n");
  printf("Options: (preceded by '/' or '-')\n");
  printf("\n");
  printf("                 [File Specifiers]\n");
  printf("<file> specifies <infile> [outfile]\n");
  printf("   <infile>: input filename\n");
  printf("   [outfile]: optional output filename.\n");
  printf("\n");
  printf("                 [Options]\n");
  printf(" -C       Center the object around the origin\n");
  printf(" -S<num>  Object scaling value. Defaults to 1, maximum is 32767\n");
  printf("\n");
  printf("                 [Help]\n");
  printf(" [-h | -?]  displays this help.\n");
  exit(0);
}

/*=========================================================================*
  Uptr - converts the string to all uppercase
 *=========================================================================*/
void UpStr(char *S)
{
  int i;

  for (i = 0; i < strlen(S); i++)
    S[i] = toupper(S[i]);
}

/*=========================================================================*
  ParseCommandLine - grabs the commandline options
 *=========================================================================*/
void ParseCommandLine(int ParmCount, char **ParmStr)
{
  int   i;
  char  Temp[64];
  char *s;
  int   InFlag;
  int   OutFlag;
  float TempNum;

  printf("GVO Conversion Utility v%d.%d\n\n", VERSION_MAJOR, VERSION_MINOR);

  if (ParmCount <= 1)
    Help();

  InFlag     = 0;
  OutFlag    = 0;
  InFileType = fNULL;
  Center     = 0;

  for (i = 1; i < ParmCount; i++)
  {
    strcpy(Temp, ParmStr[i]);
    UpStr(Temp);

    if ((Temp[0] == '/') || (Temp[0] == '-'))  /* check for switch */
    {
      switch (Temp[1])
      {
        case 'F': if (strstr(Temp, "3DS") != NULL) InFileType = f3DS;
                  if (strstr(Temp, "ASC") != NULL) InFileType = fASC;
                  break;
        case 'S': TempNum = atoi(&Temp[2]);
                  if (TempNum == 0)
                    Quit("Invalid numeric format on scaling parameter");
                  if (TempNum > 32767)
                    Quit("Scaling multiplication factor is too large");
                  Scale = TempNum;
                  break;
        case 'C': Center = 1;
                  break;
      }
    }
    else
    {
      if (!InFlag)
      {
        InFlag = 1;
        strcpy(InFile, Temp);
      }
      else
      {
        OutFlag = 1;
        strcpy(OutFile, Temp);
      }
    }
  }

  if (strstr(InFile, ".3DS") != NULL) InFileType = f3DS;
  if (strstr(InFile, ".ASC") != NULL) InFileType = fASC;

  if (InFileType == fNULL)
    GetFileType();


  if (!OutFlag)
  {
    strcpy(OutFile, InFile);

    if (InFileType == f3DS)
    {
      s = strstr(OutFile, ".3DS");
      strcpy(s, ".GVO");
    }
    else
    {
      s = strstr(OutFile, ".ASC");
      strcpy(s, ".GVO");
    }
  }
}

/*=========================================================================*
  Convert - Converts the input file into GVO format
 *=========================================================================*/
void Convert()
{
  int RetCode;

  printf("Loading [%s]\n", InFile);

  if (InFileType == f3DS)
  {
    switch (Load3DS(InFile, &TextureCoordFlag))
    {
      case 1 : Quit("Error opening file"); break;
      case 2 : Quit("Error reading from file"); break;
      case 3 : Quit("Too many verticies in file"); break;
      case 4 : Quit("Too many polygons in file"); break;
      case 5 : Quit("Not enough memory"); break;
    }
  }

  if (InFileType == fASC)
  {
    switch (LoadASC(InFile, &TextureCoordFlag))
    {
      case 1 : Quit("Error opening file"); break;
      case 2 : Quit("Error reading from file"); break;
      case 3 : Quit("Too many verticies in file"); break;
      case 4 : Quit("Too many polygons in file"); break;
      case 5 : Quit("Not enough memory"); break;
    }
  }

  if (!VerifySize())
  {
    Quit("Object has too many verticies or polygons");
  }

  printf("Calculating Normals [This could take some time]\n");

  if (CalcAllNormals(1))  /* show progress while calculating */
    printf("Warning! Some polygon normals could not be calculated.\n");

  CenterObjects(Center);

  printf("Saving  [%s]\n", OutFile);

  RetCode = SaveGVO(OutFile, Scale, FIXED, TextureCoordFlag);

  switch (RetCode)
  {
    case 1 : printf("Error Saving [%s]\n", OutFile); break;
    case 2 : printf("Warning! Some verticies were clipped to 16-bit range.\n"); break;
  }
}
