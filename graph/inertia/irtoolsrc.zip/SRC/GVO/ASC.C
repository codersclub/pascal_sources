#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "modelapi.h"
#include "asc.h"

/*========================================================================*
 Parse - parses a float from the text string
 *========================================================================*/
float Parse(char *SubStr, char *FullStr, int *Success)
{
  float v;
  char *str;
  int   err;

  str = strstr(FullStr, SubStr);
  if (str == NULL)
  {
    *Success = 0;
    return(0);
  }

  str += strlen(SubStr);

  err = errno;   /* record the errno before the atof operation */

  v = atof(str);

  if ((v == 0.0) && (errno != err))
  {
    *Success = 0;
    return(0);
  }

  *Success = 1;
  return(v);
}

/*========================================================================*
 LoadASC - loads a .ASC file from disk
 Returns : 0 - File loaded properly       
           1 - Error opening file         
           2 - Error reading from file    
           3 - Too many verticies in file 
           4 - Too many polygons in file  
           5 - Not enough memory          
 *========================================================================*/
int LoadASC(char *Filename, int *TextureCoordFlag)
{
  char          TempStr[128];
  char          VertStr[128];
  int           i;
  int           count;
  int           NumPoly;
  int           NumVert;
  int           OK;
  FILE         *fp;
  char         *VertConst[3] = {"X:", "Y:", "Z:"};
  char         *PolyConst[3] = {"A:", "B:", "C:"};
  char         *TexConst[2]  = {"U:", "V:"};
  float         FltBuf[3];

  fp = fopen(Filename, "r");
  if (fp == NULL)
    return(1);

  while (fgets(TempStr, 80, fp) != NULL)
  {
    /* find the "Tri-mesh" block of the object */
    while (strstr(TempStr, "Tri-mesh") == NULL)
    {
      if (fgets(TempStr, 128, fp) == NULL)
      {
        fclose(fp);
        return (0);
      }
    }

    NewObj();  /* add a new object to the list via the Modeller */

    NumVert = (int)Parse("Vertices:", TempStr, &OK);
    if (!OK)
    {
      fclose(fp);
      return (2);
    }

    NumPoly = (int)Parse("Faces:", TempStr, &OK);
    if (!OK)
    {
      fclose(fp);
      return (2);
    }

    for (count = 0; count < NumVert; count++)
    {
      sprintf(VertStr, "Vertex %d:", count);

      while (strstr(TempStr, VertStr) == NULL)
      {
        if (fgets(TempStr, 128, fp) == NULL)
        {
          fclose(fp);
          return(2);
        }
      }

      for (i = 0; i < 3; i++)
      {
        FltBuf[i] = Parse(VertConst[i], TempStr, &OK);
        if (!OK)
        {
          fclose(fp);
          return(2);
        }
      }

      AddVertex(FltBuf[0], FltBuf[1], FltBuf[2]);

      for (i = 0; i < 2; i++)
      {
        FltBuf[i] = Parse(TexConst[i], TempStr, &OK);
      }

      if (OK)
      {
        AddUV(FltBuf[0], FltBuf[1]);
        *TextureCoordFlag = 1;
      }
    }

    for (count = 0; count < NumPoly; count++)
    {
      sprintf(VertStr, "Face %d:", count);

      while (strstr(TempStr, VertStr) == NULL)
      {
        if (fgets(TempStr, 128, fp) == NULL)
        {
          fclose(fp);
          return(2);
        }
      }

      for (i = 0; i < 3; i++)
      {
        FltBuf[i] = Parse(PolyConst[i], TempStr, &OK);
        if (!OK)
        {
          fclose(fp);
          return(2);
        }
      }

      AddPolygon((int)FltBuf[0], (int)FltBuf[1], (int)FltBuf[2]);
    }
  }

  fclose(fp);

  return(0);
}
