/* Structs.C                                                                */
/* Copyright (c) Genus Microprogramming, Inc. 1988-89  All Rights Reserved. */

/****************************************************************************

  This program demonstrates the usage of various toolkit structures. It is 
  an example C routine for the PCX Programmer's Toolkit.

  Microsoft C version 5.1                 Programmer: Chris Howard  4/15/89

*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* Include the PCX Toolkit defines */
#include "pcxlib.h"

/* Globals - DECLARE AS "char far" FOR LATTICE C                            */
int  pcxtype;
char pcximage[] = "pcxTest.PCX";

PCXHEADER header;
PCXHEADERPTR h;

PCXVINFO vi[2];
PCXDINFO di;

static char *viadapt[] = {"[None]","MDA","CGA","EGA","MCGA","VGA"};
static char *viherc[]  = {"HGC","HGC+","InColor"};
static char *vidisp[]  = {"[None]","MDA Monochrome Display","CGA Color Display",
                          "EGA Color Display","VGA Monochrome Display",
                          "VGA Color Display"};
static char *chip[]    = {"[Unknown]","Tseng Labs","Paradise","Video7"};

/**********/

void main(argc,argv)
int  argc;
char *argv[];

{
  int  i,chipset,retcode;

  /* Display program header */
  printf("\n");
  printf("��������������������������������������������������������������������������͸\n");
  printf("� Structs: Example Structures C Program      PCX Programmer's Toolkit 3.50 �\n");
  printf("� Copyright (c) Genus Microprogramming, Inc. 1988-89  All Rights Reserved. �\n");
  printf("��������������������������������������������������������������������������;\n");
  printf("\n");

  /* Get a key, to begin */
  printf("Press a key to run . . .");
  getch();
  printf("\n\n");

  /* Look at the current hardware, to find a B/W mode */
  pcxVideoInfo(vi);

  /* Display what we found */
  printf("Video Information:\n\n");
  for (i=0; i<=1; i++) {
    /* Is there an adapter here? */
    if (vi[i].adapter != viNONE) {
      /* Display, and use the other array if Hercules */
      if (vi[i].adapter >= viHGC)
        printf("  %-7s with a %s\n",viherc[vi[i].adapter-viHGC],vidisp[vi[i].display]);
      else
        printf("  %-7s with a %s\n",viadapt[vi[i].adapter],vidisp[vi[i].display]);
    }
    /* If this is a VGA, try to find a chipset */
    if (vi[i].adapter == viVGA) {
      chipset = pcxQueryChipset();
      printf("   chipset: %s\n",chip[chipset]);
    }
  }

  /* Wait for a key */
  printf("\nPress a key to continue ...");
  getch();

  /* Get an image header */
  retcode = pcxGetFileHeader(pcximage,&header);

  /* If we read it successfully, display some information */
  if (retcode == pcxSUCCESS) {

    /* Get a pointer to the header (otherwise, we have to use 'header.') */
    h = &header;

    /* List header values */
    printf("\n\nHeader structure for %s:\n\n",pcximage);
    printf("    manuf: %d\n",h->  manuf);
    printf("     hard: %d\n",h->   hard);
    printf("    encod: %d\n",h->  encod);
    printf("    bitpx: %d\n",h->  bitpx);
    printf("       x1: %d\n",h->     x1);
    printf("       y1: %d\n",h->     y1);
    printf("       x2: %d\n",h->     x2);
    printf("       y2: %d\n",h->     y2);
    printf("     hres: %d\n",h->   hres);
    printf("     vres: %d\n",h->   vres);
    printf("    vmode: %d\n",h->  vmode);
    printf("  nplanes: %d\n",h->nplanes);
    printf("    bplin: %d\n",h->  bplin);

  }

  /* Wait for a key */
  printf("\nPress a key to continue ...");
  getch();

  /* Now get information on a PCX type */
  pcxGetDisplayInfo(pcxEGA_10,&di);

  /* Display some information */
  printf("\n\nInformation on the 'pcxEGA_10' display type:\n\n");
  printf("     type: %d\n",  di.type);
  printf("  descrip: [%s]\n",di.descrip);
  printf("     mode: %X\n",  di.mode);
  printf("    bitpx: %d\n",  di.bitpx);
  printf("     hres: %d\n",  di.hres);
  printf("     vres: %d\n",  di.vres);
  printf("   planes: %d\n",  di.planes);
  printf("    pages: %d\n",  di.pages);
  printf("   begseg: %X\n",  di.begseg);
  printf(" pagesize: %X\n",  di.pagesize);


} /* end of main */

