/* pcxTest.C                                                                */
/* Copyright (c) Genus Microprogramming, Inc. 1988-89  All Rights Reserved. */

/****************************************************************************

  This program merely enters graphics mode, sets the palette, and displays
  the test image "pcxTest.PCX".  It is an example C routine for the PCX
  Programmer's Toolkit.

  NOTE: REQUIRES A CGA (or compatible) ADAPTER AND DISPLAY!

  To Compile: Microsoft C 5.x    cl  /c pcxtest.c
                                 link pcxtest,,,pcx_cs;

              Quick     C 1.x    QC  pcxtest   /lpcx_cm.qlb
                                 (press "Shift-F5" to run                 )
                           or    QCL pcxtest.c /link pcx_cm;

              Lattice   C 3.2x   lc  -n pcxtest
                                 link pcxtest \lc\s\c,,,\lc\s\lc pcx_lcs;

              Turbo     C 2.x    tc  pcxtest
                                 (Specify a PRJ file, 2 lines: pcxtest    )
                                 (                             pcx_cs.lib )
                                 (and press "Alt-R" to run                )
                           or    tcc -I\tc\h -L\tc\lib pcxtest pcx_cs.lib

  Microsoft C version 5.1                 Programmer: Chris Howard  2/01/89

*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <malloc.h> /* Change to 'alloc.h' for Turbo C, remove for Lattice  */

/* Include the PCX Toolkit defines */
#include "pcxlib.h"

/* Globals - DECLARE AS "char far" FOR LATTICE C */
int  pcxtype    =  pcxCGA_4;
char pcximage[] = "pcxTest.PCX";
char pcxpal[800];

char *bufptr;
int  bufmax     = 20000;

/**********/

void main(argc,argv)
int  argc;
char *argv[];

{
  int  retcode;

  /* Display program header */
  printf("\n");
  printf("��������������������������������������������������������������������������͸\n");
  printf("� pcxTest: Example C Test Program            PCX Programmer's Toolkit 3.50 �\n");
  printf("� Copyright (c) Genus Microprogramming, Inc. 1988-89  All Rights Reserved. �\n");
  printf("��������������������������������������������������������������������������;\n");
  printf("\n");

  /* Get a key, to begin */
  printf("Press a key to run . . .");
  getch();

  /* Allocate a larger toolkit buffer, to speed up file and display speed. */
  /* The toolkit defaults to using an internal 2KB buffer, but if we can   */
  /* spare more memory than that, declare a new buffer.                    */
  /* REMEMBER: This MUST be a GLOBAL buffer (ie, declare OUTSIDE of procs) */

  if ((bufptr = malloc(bufmax)) != NULL) {
    /* Successful, so point to it */
    retcode = pcxSetBuffer(bufptr,bufmax);
  }

  /* Set the display type and mode we will be using */
  if ((retcode = pcxSetDisplay(pcxtype)) == pcxSUCCESS) {

    /* Now enter graphics mode */
    if ((retcode = pcxSetMode(pcxGRAPHICS)) == pcxSUCCESS) {

      /* We are in graphics mode, so set the image file palette            */
      /* NOTE: If all your images use a default BIOS palette (or the       */
      /*       default Paintbrush palette), just SKIP setting the palette! */

      if ((retcode = pcxGetFilePalette(pcxtype,pcximage,pcxpal)) == pcxSUCCESS) {
        /* Now set it */
        if ((retcode = pcxSetDisplayPalette(pcxpal)) != pcxSUCCESS) {
          /* Error setting palette */
          printf("pcxSetDisplayPalette error: %d\n",retcode);
        }
      }
      else {
        /* Error getting the palette */
        printf("pcxGetFilePalette error: %d\n",retcode);
      }

      /* Now display the image file */
      if ((retcode = pcxFileDisplay(pcximage,0,0,0)) != pcxSUCCESS) {
        /* Error displaying the file */
        printf("pcxFileDisplay error: %d\n",retcode);
      }

      /* Wait for a key */
      getch();

      /* Return to text mode */
      pcxSetMode(pcxTEXT);

    }
    else {
      /* Error setting the mode */
      printf("pcxSetMode error: %d\n",retcode);
    }

  }
  else {
    /* Error setting the display type */
    printf("pcxSetDisplay error: %d\n",retcode);
  }

} /* end of main */

