/* Virtual.C                                                                */
/* Copyright (c) Genus Microprogramming, Inc. 1988-89  All Rights Reserved. */

/****************************************************************************

  This program demonstrates the usage of a virtual window. It is an example
  C routine for the PCX Programmer's Toolkit.

  Microsoft C version 5.1                 Programmer: Chris Howard  4/15/89

*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <malloc.h> /* Change to 'alloc.h' for Turbo C, remove for Lattice  */

/* Include the PCX Toolkit defines */
#include "pcxlib.h"

/* Globals - DECLARE AS "char far" FOR LATTICE C                            */
int  pcxtype    =  pcxVGA_11;
char pcximage[] = "Virtual.PCX";
char pcxpal[800];

PCXVINFO vi[2];
PCXHEADER header;

char *bufptr;
int  bufmax     = 20000;

/**********/

void main(argc,argv)
int  argc;
char *argv[];

{
  long vfree,vreq,vptr;
  int  width,depth,wx2,wy2,retcode;

  /* Display program header */
  printf("\n");
  printf("��������������������������������������������������������������������������͸\n");
  printf("� Virtual: Example Virtual C Program         PCX Programmer's Toolkit 3.50 �\n");
  printf("� Copyright (c) Genus Microprogramming, Inc. 1988-89  All Rights Reserved. �\n");
  printf("��������������������������������������������������������������������������;\n");
  printf("\n");

  /* Get a key, to begin */
  printf("Press a key to run . . .");
  getch();
  printf("\n\n");

  /* Allocate a larger toolkit buffer, to speed up file and display speed. */
  if ((bufptr = malloc(bufmax)) != NULL) {
    /* Successful, so point to it */
    retcode = pcxSetBuffer(bufptr,bufmax);
  }

  /* Check if we have expanded memory, and display */
  if (pcxEMInstalled() == pcxSUCCESS) {
    vfree = pcxVirtualFree(pcxEMM);
    printf("Free EMM: %ld\n",vfree);
  }

  /* Display the amount of conventional free memory */
  vfree = pcxVirtualFree(pcxCMM);
  printf("Free CMM: %ld\n",vfree);

  /* Look at the current hardware, to find a B/W mode */
  pcxVideoInfo(vi);

  switch(vi[0].adapter) {
    case viCGA:
      pcxtype = pcxCGA_6;
      break;
    case viEGA:
      if (vi[0].display == viMDAdisp)
        pcxtype = pcxEGA_F;
      else
        pcxtype = pcxEGA_10;
      break;
    case viVGA:
      pcxtype = pcxVGA_11;
      break;
    case viHGC:
      pcxtype = pcxHERC;
      break;
    default:
      /* If we cannot determine a good type, set flag */
      pcxtype = -1;
      break;
  }

  /* If we found a mode, continue */
  if (pcxtype != viNONE) {

    /* Get the file header */
    retcode = pcxGetFileHeader(pcximage,&header);
    if (retcode == pcxSUCCESS) {

      /* Get the image size */
      width = header.x2-header.x1+1;
      depth = header.y2-header.y1+1;

      /* Get the virtual memory required */
      vreq = pcxVirtualSize(pcxtype,width,depth);

      /* Display it */
      printf("\nReqd CMM: %ld\n\n",vreq);

      /* Wait for a key */
      printf("Press a key to continue . . .\n");
      getch();

      /* Do we have enough? */
      if (vreq < vfree) {

        /* Yes, so create the virtual buffer */
        retcode = pcxCreateVirtual(pcxCMM,&vptr,pcxtype,width,depth);
        if (retcode == pcxSUCCESS) {

          /* The buffer was created, so load the file */
          retcode = pcxFileVirtual(pcximage,vptr);
          if (retcode == pcxSUCCESS) {

            /* We loaded, so for example define a window 160x160 */
            /* (remember: 0 to 159 = 160)                        */
            wx2 = 159;
            wy2 = 159;

            /* NOTE: NEVER DEFINE A WINDOW LARGER THAN THE IMAGE FOR SCROLLING! */
            if (wx2 > width-1)
              wx2 = width-1;
            if (wy2 > depth-1)
              wy2 = depth-1;

            /* Set the display type and mode */
            pcxSetDisplay(pcxtype);
            pcxSetMode(pcxGRAPHICS);

            /* Allow scrolling of the image in the window */
            retcode = pcxVirtualScroll(vptr,width,depth,0,0,wx2,wy2,0);

            /* Get back to text mode */
            pcxSetMode(pcxTEXT);

            /* Were we successful? */
            if (retcode != pcxSUCCESS)
              printf("\npcxVirtualScroll Error: %d\n",retcode);

          }
          else {
            /* Error loading file to virtual buffer */
            printf("\nError loading file: %d . . .\n",retcode);
          }

          /* Destroy the virtual buffer */
          pcxDestroyVirtual(vptr);

        }
        else {
          /* Error creating virtual buffer */
          printf("\nError creating virtual buffer: %d . . .\n",retcode);
        }
        
      }
      else {
        /* Not enough free memory */
        printf("\nNot enough free memory . . .\n");
      }

    }
    else {
      /* Could not get image header */
      printf("\nCould not load image header: %d . . .\n",retcode);
    }

  }
  else {
    /* We could not find a good mode */
    printf("\nCould not find a good mode type . . .\n");
  }

} /* end of main */

