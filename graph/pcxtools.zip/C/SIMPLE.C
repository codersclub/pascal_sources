/* Simple.C                                                                 */
/* Copyright (c) Genus Microprogramming, Inc. 1988-89  All Rights Reserved. */

/****************************************************************************

  This program is the simplest example of toolkit usage. It is an example
  C routine for the PCX Programmer's Toolkit.

  NOTE: REQUIRES A CGA (or compatible) ADAPTER AND DISPLAY!


  Microsoft C version 5.1                 Programmer: Chris Howard  4/15/89

*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* Include the PCX Toolkit defines */
#include "pcxlib.h"

/* Globals - DECLARE AS "char far" FOR LATTICE C */
int  pcxtype    =  pcxCGA_4;
char pcximage[] = "Simple.PCX";

/**********/

void main(argc,argv)
int  argc;
char *argv[];

{
  int  retcode;

  /* Display program header */
  printf("\n");
  printf(" Simple Example C PCX Program \n\n");

  printf(" Press a key to run ...");
  getch();

  /* Set the display type and mode we will be using */
  pcxSetDisplay(pcxtype);
  retcode = pcxSetMode(pcxGRAPHICS);

  /* Now display the image file */
  if (retcode == pcxSUCCESS) {
    retcode = pcxFileDisplay(pcximage,0,0,0);

    /* Wait for a key */
    getch();

    /* Return to text mode */
    pcxSetMode(pcxTEXT);
  }

  /* Check if everything went OK */
  if (retcode != pcxSUCCESS) {
    printf("\nAn error occurred: [%d]\n\n",retcode);
    printf("You may not have a CGA, or the image SIMPLE.PCX may not\n");
    printf("be in the current directory ...\n\n");
  }

} /* end of main */

