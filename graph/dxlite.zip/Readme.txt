Microsoft(R) DirectX(R) Lite Implementation v.0.10 Beta
for TMT Pascal Multi-target (Win32 target)
Copyright (c) 2000 TMT Development Corporation
Portions  Copyright (c) 1998-1999 Microsoft Corporation.
All rights reserved.

___________________________________________________________________________

REQUIREMENTS:

This version of the DXLite unit requires the TMT Pascal Multi-target v.3.50
with Service Pack #1 installed.

___________________________________________________________________________

INSTALLATION:

To install the DXLite library on your computer, you should compile the
DXLITE.PAS unit and copy the newly created DXLITE.FPW file to your
/TMTPL/UNITS subdirectory (if it does not exist there already).

___________________________________________________________________________

IMPLEMENTATION:

The following base DirectX interfaces are implemented in the DXLite library:

  DirectDraw  - the component of the DirectXr application programming
                interface (API) that allows you to directly manipulate
                display memory, the hardware blitter, hardware overlay
                support, and flipping surface support. DirectDraw provides
                this functionality while maintaining compatibility with
                existing Microsoftr Windowsr-based applications and device
                drivers.
  DirectSound - the wave-audio component of the DirectXr API. DirectSound
                provides low-latency mixing, hardware acceleration, and
                direct access to the sound device. It provides this
                functionality while maintaining compatibility with existing
                device drivers.
  DirectInput - an API for input devices including the mouse, keyboard,
                joystick, and other game controllers, as well as for
                force-feedback (input/output) devices.

___________________________________________________________________________

SAMPLES:

You will find some samples on DXLite library usage (both sources and compiled
executables) in the \SAMPLES subdirectory.

