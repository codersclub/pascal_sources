/*
**      Netdiff
**
**      Find changes between two nodelists
**
**      (c) Ralf Mahler (Pascal Sources)
**
**      C Sources by Hinrich Donner
**
**      98/01/09        - Converted
**
**      Public Domain
**
*/

#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <share.h>
#if defined(__BORLANDC__)
 #include <alloc.h>
#else
 #include <malloc.h>
#endif
#include <string.h>

#if defined(__OS2__)
 #define OS_ADDON       "/2"
#elif defined(__NT__)
 #define OS_ADDON       " [Windows 95/NT]"
#elif defined(__NETWARE__)
 #define OS_ADDON       " [NLM]"
#elif defined(__DOS__)
 #define OS_ADDON
#else
 #error Operating system not supported or missing definition!
#endif

/* Max length of a string */
#define MAX_STRING_LENGTH       255
/* Max. length of an Fido address (w/o domain) */
#define MAX_AKA_LENGTH          25
/* Max length of a flag string */
#define MAX_FLAG_LENGTH         7
/* Max. count of flags per node */
#define MAXFLAGS                30
/* Max. entries at all */
#define MAX_ARRAY_SIZE          5500

/*
** Checking for the type 'bool'!
** It is defined under Watcom C++ (and only C++) in Version 11.0
** If you know others, change the preprocessor commands
*/
#if defined(__cplusplus) && (__WATCOMC__ >= 0x1100)
/* Here you know, that we have a bool */
#else
typedef unsigned int    bool;
#endif

#if defined(False)
 #undef False
#endif
#if defined(True)
 #undef True
#endif
#define False   0
#define True    !False

/* A single node info */
typedef struct _NODEADRESSTYPE {
        signed int      zone;                   /* Zone */
        signed int      net;                    /* zugehoeriges Netz */
        signed int      adr;                    /* zugehoerige Adresse */
        signed int      reg;                    /* zugehoerige Region */
        char            ges[MAX_AKA_LENGTH+1];  /* Nodeadresse x:yyyy/zzzz */
        char            nlc[MAX_AKA_LENGTH+1];  /* zugehoeriger NL-Verantw. */
}       NodeAdressType;

/* A flag info */
typedef struct _FLAGSETTYPE {
        unsigned int    num;
        char            f[MAXFLAGS][MAX_FLAG_LENGTH+1];
}       FlagSetType;

typedef struct _NLENTRYTYPE {
        char            fu[MAX_STRING_LENGTH+1];        /* Funktion */
        NodeAdressType  na;
        char            bn[MAX_STRING_LENGTH+1];        /* BBS-Name */
        char            ci[MAX_STRING_LENGTH+1];        /* Ort */
        char            sn[MAX_STRING_LENGTH+1];        /* Sysop-Name */
        char            tn[MAX_STRING_LENGTH+1];        /* Telefon-Nr. */
        char            ge[MAX_STRING_LENGTH+1];        /* Geschwindigkeit */
        char            fl[MAX_STRING_LENGTH+1];        /* Flags */
        FlagSetType     fs;
        bool            nn;                             /* normal Node */
}       NLEntryType;

signed int              defaultZone;
unsigned int            index;
unsigned int            t;
unsigned int            stat;
char                    eingabe[MAX_STRING_LENGTH+1];
char                    nadds[MAX_ARRAY_SIZE][16];
char                    nstas[MAX_ARRAY_SIZE][11];
char                    nnlcs[MAX_ARRAY_SIZE][13];
char                    nsnam[MAX_ARRAY_SIZE][31];
bool                    nfous[MAX_ARRAY_SIZE];
NLEntryType             nlentry;
NodeAdressType          aktna;


/*
** Prototypen
*/
void            CheckIO(void);
void            MakeNLEntry(char * e1, NodeAdressType * e2, NLEntryType * a);
void            NetDiffExit(void);
char *          OhneStrich(char * target, const char * source);
unsigned int    Suchen(char * a, char * b, char * c, char * y, char * x);
/*
** Funktionen
*/

/*
** Suchen
*/
unsigned int Suchen(char * a, char * b, char * c, char * y, char * x) {
        /* suchen=1 -> nicht gefunden in alter Liste */
        /* suchen=2 ->       gefunden in alter Liste ohne Statusaenderung */
        /* suchen=3 ->       gefunden in alter Liste  mit Statusaenderung */
        /* suchen=4 ->       gefunden in alter Liste (Namensaenderung)    */
        unsigned int    result;
        unsigned int    i;
        char * ptr;
        result = 1;
        for ( i = 0; i <= index; i++ ) {
                if (stricmp(nadds[i], a) == 0) {
                        result = 2;
                        ptr = nadds[i];
                        while(*ptr != ':')
                                ++ ptr;
                        *ptr = 0;
                        aktna.zone = atoi(nadds[i]);
                        *ptr =':';
                        break;
                };
        };
        if (result == 1)
                --i;
        strcpy(x, nstas[i]);
        /* Nicht gefunden, also fertig */
        if (result == 1)
                return result;
        nfous[i] = False;
        if (stricmp(nstas[i], b) != 0)
                result = 3;
        else if (stricmp(nsnam[i], c) != 0) {
                /* Sysopname hat gewechselt */
                strcpy(y, nsnam[i]);
                result = 4;
        };
        return(result);
};

/*
** OhneStrich
**
** Copies an String and removes '_'
**
*/
char * OhneStrich(char * target, const char * source) {

        size_t          __length;
        __length = strlen(source);
        memmove(target, source, (__length + 1));
        while (__length > 0) {
                --__length;
                if (target[__length] == '_')
                        target[__length] = ' ';
        };
        return(target);
}

/*
** NetDiffExit
*/
void NetDiffExit(void) {

        fcloseall();
}

/*
** CheckIO
*/
void CheckIO(void) {

        if (errno != 0) {
                fprintf(stderr,
                        "I/O-Fehler %d occured -> program end.\n",
                        errno);
                exit(errno);
        };
}

/*
** MakeNLEntry
*/
void MakeNLEntry(char * e1, NodeAdressType * e2, NLEntryType * a) {

        char *          b;
        char *          cptr;
        size_t          kurz;
        int             ziffer;

        /* Use stack for temp memory */
        b = alloca((size_t) MAX_STRING_LENGTH+1);
        cptr = e1;              /* Use the copy */
        strcpy(a -> fu, "NN");
        kurz = 1;
        a -> nn = True;
        if (defaultZone == 0)
                e2 -> zone = 2;         /* default, wenn keine Zone vorhanden */
        /* Funktion */
        if (strnicmp(cptr, "zone,", 5) == 0) {
                strcpy(a -> fu, "ZC");
                kurz = 5;
                a -> nn = False;
        } else if (strnicmp(cptr, "region,", 7) == 0) {
                strcpy(a -> fu, "RC");
                kurz = 7;
                a -> nn = False;
        } else if (strnicmp(cptr, "host,", 5) == 0) {
                strcpy(a -> fu, "Host");
                kurz = 5;
                a -> nn = False;
        } else if (strnicmp(cptr, "hub,", 4) == 0) {
                strcpy(a -> fu, "Hub");
                kurz = 4;
        } else if (strnicmp(cptr, "pvt,", 4) == 0) {
                strcpy(a -> fu, "Pvt");
                kurz = 4;
        } else if (strnicmp(cptr, "hold,", 5) == 0) {
                strcpy(a -> fu, "Hold");
                kurz = 5;
        } else if (strnicmp(cptr, "down,", 5) == 0) {
                strcpy(a -> fu, "Down");
                kurz = 5;
        }
        // Offset correting */
        cptr += kurz;
        /* Nodenummer */
        kurz = 0;
        while (cptr[kurz] != ',')
                ++kurz;
        /* Set eos */
        cptr[kurz] = 0;
        /* get number */
        ziffer = atoi(cptr);
        /* undo changes */
        cptr[kurz++] = ',';
        /* increase pointer */
        cptr += kurz;
        /* Now interpret value */
        e2 -> zone = defaultZone;
        if (stricmp(a -> fu, "zc") == 0) {
                defaultZone =
                        e2 -> zone =
                        e2 -> net = ziffer;
                e2 -> reg =
                        e2 -> adr = 0;
                sprintf(e2 -> nlc,
                        "%d:%d/%d",
                        e2 -> zone, e2 -> net, e2 -> adr);
        } else if (stricmp(a -> fu, "rc") == 0) {
                e2 -> reg =
                        e2 -> net = ziffer;
                e2 -> adr = 0;
                sprintf(e2 -> nlc,
                        "%d:%d/%d",
                        e2 -> zone, e2 -> net, e2 -> adr);
        } else if (stricmp(a -> fu, "host") == 0) {
                e2 -> net = ziffer;
                e2 -> adr = 0;
                sprintf(e2 -> nlc,
                        "%d:%d/%d",
                        e2 -> zone, e2 -> net, e2 -> adr);
        };
        if (a -> nn)
                e2 -> adr = ziffer;
        if (stricmp(a -> fu, "hub") == 0)
                sprintf(e2 -> nlc,
                        "%d:%d/%d",
                        e2 -> zone, e2 -> net, e2 -> adr);
        sprintf(e2 -> ges, "%d:%d/%d",
                e2 -> zone, e2 -> net, e2 -> adr);
        /* Now we have the address */
        /* Funktion */
        if ((e2 -> net == e2 -> zone)
            && (e2 -> reg == 0) && (e2 -> adr != 0)) {
                strcpy(a -> fu, "Z-I");
                sprintf(e2 -> nlc,
                        "%d:%d/%d",
                        e2 -> zone, e2 -> net, 0);
        };

        if ((e2 -> net == e2 -> reg) && (e2 -> adr != 0)) {
                strcpy(a -> fu, "R-I");
                sprintf(e2 -> nlc,
                        "%d:%d/%d",
                        e2 -> zone, e2 -> reg, 0);
        }
        /* Copy the informations */
        memcpy(&a -> na, e2, sizeof(NodeAdressType));
        /* BBS-Name */
        kurz = 0;
        while (cptr[kurz] != ',')
                ++kurz;
        cptr[kurz] = 0; /* Set eos */
        OhneStrich(a -> bn, cptr);
        cptr[kurz++] = ',';
        cptr += kurz;
        /* City */
        kurz = 0;
        while (cptr[kurz] != ',')
                ++kurz;
        cptr[kurz] = 0; /* Set eos */
        OhneStrich(a -> ci, cptr);
        cptr[kurz++] = ',';
        cptr += kurz;
        /* Sysop-Name */
        kurz = 0;
        while (cptr[kurz] != ',')
                ++kurz;
        cptr[kurz] = 0; /* Set eos */
        OhneStrich(a -> sn, cptr);
        cptr[kurz++] = ',';
        cptr += kurz;
        /* Telefon-Nr */
        kurz = 0;
        while (cptr[kurz] != ',')
                ++kurz;
        cptr[kurz] = 0; /* Set eos */
        strcpy(a -> tn, cptr);
        cptr[kurz++] = ',';
        cptr += kurz;
        /* Geschwindigkeit */
        kurz = 0;
        while (cptr[kurz] != ',')
                ++kurz;
        cptr[kurz] = 0; /* Set eos */
        strcpy(a -> ge, cptr);
        cptr[kurz++] = ',';
        cptr += kurz;
        /* Flags */
        strcpy(a -> fl, cptr);
}

/*
** main
*/
int main(int argc, char ** argv) {

        char *          oldList;
        char *          newList;
        char *          reportFile;
        char *          cptr;
        char            flag[MAX_STRING_LENGTH+1];
        char            oldname[MAX_STRING_LENGTH+1];
        FILE *          f; /* Eingabe */
        FILE *          g; /* Ausgabe */
        unsigned long   lineCounter;
        unsigned int    newIndex;

        fprintf(stderr,
                "NetDiff v1.11" OS_ADDON " by Hinrich Donner\n"
                "based on NetDiff v1.1 by Ralf Mahler\n"
                "============================================="
                "=================================\n\n");
        if (argc != 4) {
                fprintf(stderr,
                        "Aufruf:   NETDIFF NetWork-File(old) NetWork-File(new) Output\n"
                        "Beispiel: NETDIFF NET2433.159       NET2433.166       NET2433.DIF\n");
                return(1);
        };

        /* Copy the pointer of the parameters */
        oldList = argv[1];
        newList = argv[2];
        reportFile = argv[3];

        /* Init */
        atexit(NetDiffExit);
        errno = 0;
        index = 0;
        /* Set Zero for uncompleted fgets */
        eingabe[MAX_STRING_LENGTH] = 0;

        /* Open old list */
        f = _fsopen(oldList, "rt", SH_DENYWR);
        if (f == 0)
                CheckIO();
        lineCounter = 0;
        /* Read first line */
        cptr = fgets(eingabe, MAX_STRING_LENGTH, f);
        /* If any */
        while (cptr != 0) {
                /* Correct the counter */
                ++lineCounter;
                /* We need a check if the line exceeds string */
                if (eingabe[strlen(eingabe) - 1] != '\n') {
                        fprintf(stderr,
                                "Error: Line %ul (%s) exceeds %d characters!\n"
                                "Program terminates!\n",
                                lineCounter, oldList, MAX_STRING_LENGTH);
                        exit(1);
                };
                CheckIO();
                /* Ignore comment lines */
                if (*cptr != ';') {
                        /* Parse string */
                        MakeNLEntry(eingabe,&aktna,&nlentry);
                        /* Copy data */
                        strcpy(nadds[index], nlentry.na.ges);
                        strcpy(nnlcs[index], nlentry.na.nlc);
                        strcpy(nstas[index], nlentry.fu);
                        strcpy(nsnam[index], nlentry.sn);
                        nfous[index] = True;
                        /* Increas Index */
                        ++index;
                }; /* if (*cptr... */
                /* Get next line */
                cptr = fgets(eingabe, MAX_STRING_LENGTH, f);
        };
        /* Close the input file */
        fclose(f);
        /* Correct 'index' */
        --index;
        /* Open new list file */
        f = _fsopen(newList, "rt", SH_DENYWR);
        if (f == 0)
                CheckIO();
        g = _fsopen(reportFile, "wt", SH_DENYWR);
        if (g == 0)
                CheckIO();

        fprintf(g, "\nComparing %s and %s:\n\n", oldList, newList);

        lineCounter = 0;
        newIndex = 0;
        cptr = fgets(eingabe, MAX_STRING_LENGTH, f);
        /* If any */
        while (cptr != 0) {
                /* Correct the counter */
                ++lineCounter;
                /* We need a check if the line exceeds string */
                if (eingabe[strlen(eingabe) - 1] != '\n') {
                        fprintf(stderr,
                                "Error: Line %ul (%s) exceeds %d characters!\n"
                                "Program terminates!\n",
                                lineCounter, newList, MAX_STRING_LENGTH);
                        exit(1);
                };
                CheckIO();
                /* Comments ignoring */
                if (*cptr != ';') {
                        ++newIndex;
                        /* Make an entry */
                        MakeNLEntry(eingabe, &aktna, &nlentry);
                        /* Search the entry */
                        stat = Suchen(nlentry.na.ges,
                                      nlentry.fu,
                                      nlentry.sn,
                                      oldname,
                                      flag);
                        switch(stat){

                        case 1: /* It's new */
                                fprintf(g, "%-13s (under %s): New node (%s)\n",
                                        nlentry.na.ges, nlentry.na.nlc, nlentry.sn);
                        case 2: /* No changes */
                                break;
                        case 3: /* New flags */
                                if (stricmp(flag, "NN") == 0)
                                        strcpy(flag, "./.");
                                if (stricmp(nlentry.fu, "NN") == 0)
                                        strcpy(nlentry.fu, "./.");
                                fprintf(g, "%-13s (under %s): %s to %s (%s)\n",
                                        nlentry.na.ges,
                                        nlentry.na.nlc,
                                        flag, nlentry.fu,
                                        nlentry.sn);
                                break;
                        case 4: /* New sysop */
                                fprintf(g, "%-13s (under %s): New sysop %s (was: %s)\n",
                                        nlentry.na.ges,
                                        nlentry.na.nlc,
                                        oldname,
                                        nlentry.sn);
                                break;

                        }; /* switch */
                        CheckIO();
                }; // if (*cptr...
                /* Next line */
                cptr = fgets(eingabe, MAX_STRING_LENGTH, f);
        }; /* while */
        /* Close input file */
        fclose(f);

        for (t=0; t <= index; t++) {
                if (nfous[t]) {
                        fprintf(g, "%-13s (under %s): Lost node (was: %s)\n",
                                nadds[t],
                                nnlcs[t],
                                nsnam[t]);
                        CheckIO();
                };
        };

        fprintf(g, "\n...produced by NetDiff v1.11" OS_ADDON "\n");
        fclose(g);
        fprintf(stderr, "%u old entries with %u entries compared\n",
                index, newIndex);
        return(0); /* Exit without any errors */
};
