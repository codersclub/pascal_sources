/*-----------------15.10.96 22:16-----------------
  (c) Jury Fradkin 1996, Spb
      converted to C by Anton Krenitskiy
--------------------------------------------------*/

#include <string.h>
#include <io.h>
#include <alloc.h>
#include <fcntl.h>
#include "t_lng.h"

#define LNG_MAX_INDEX 1024

static ushort *table = NULL;
static char   *body  = NULL;
static size_t  size  = 0;
static ushort  count,cnt = 0;

ushort openLng(const char *fileName)
{
  int i;
  char *p;
  int F;

  closeLng();

  F = open(fileName, O_RDONLY | O_BINARY );
  if ( F != -1 )
  {
    size = filelength(F);
    if ( size != (size_t)(-1) && size >2 )
    {
      p = body = (char*)malloc(size-2);
      if ( body )
      {
        if ( read(F,body,size-2) == -1 )
        {
          close(F);
          free(body);
          return 0;
        }
        else close(F);
      }
      else
      {
        close(F);
        return 0;
      }
    }
    else
    {
      close(F);
      return 0;
    }

    table = (ushort*)malloc(LNG_MAX_INDEX*sizeof(ushort));
    if ( !table )
    {
      free(body);
      return 0;
    }

    *table = 0;

    for ( i = 1; i <= size-2; i++ )
      if ( !*p++ ) table[++count] = i;
  }
  else return 0;

  if ( !count ) closeLng();
  else table = realloc(table,(count)*sizeof(ushort));

  return count;
}

void closeLng(void)
{
  if ( body )
  {
    free(body); body = NULL;
  }

  if ( table )
  {
    free(table); table = NULL;
  }

  count = 0;
  size  = 0;
}

char *getLng( ushort n )
{
  if ( n < count)
    return ( body + table[n] );
  else
    return NULL;
}

char *getLngKey( ushort n )
{
  static char s[256];
  char *p = getLng(n), *p1;

  if ( p )
  {
    if ( p1 = strchr(p, '%'))
    {
      strncpy(s, p, p1-p);
      s[p1-p] = '\0';
      return s;
    }
    else
      return p;
  }
  else
    return NULL;
}

