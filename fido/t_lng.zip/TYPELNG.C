#include <stdio.h>
#include "t_lng.h"

int main(int argc, char **argv)
{
  int i, n;
   if ( argc != 2 )
   {
      puts("Printing .LNG.  (c) Jef, 1996");
      puts("TYPELNG filename");
      return 1;
   }
   n = openLng(*++argv);
   for ( i = 0; i != n; i++)
       printf("%03u> %s\n     %s\n\n",i,getLng(i),getLngKey(i));
   closeLng();
   return 0;
}
