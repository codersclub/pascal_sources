/****************************************************************
*
*  Name:          SHAREB
*
*  Function:      share memory/data with another process
*
*  Shows how to:  1. read from and write to shared memory.
*                 2. receive from another process the address of shared data.
*                 3. control access to shared data via mailbox semaphore.
*
****************************************************************/

#include <stdio.h>
#include "dvapi.h"

/* minimum API version required */
#define required 0x201

/* API version number */
int version;

/* default object handle */
ulong win;

/* application handle of other process */
ulong apphana;

/* mail-related variables */
int status;
char *malptr;
int mallng;

/* type declarations related to shared data */
typedef char *DATATYPE;
typedef DATATYPE *DATAPTR;

/* constant value to be assigned to shared memory */
DATATYPE shrconst = "     BBBBB";

/* pointer to shared data */
DATAPTR shrptr;

/* pointer to pointer to shared data */
DATAPTR *shrptrptr;

/* mailbox semaphore controlling access to shared memory */
ulong sema;

/* global name of mailbox */
char *name = "Shared Memory Semaphore";


/**********************************************************************
*  main  -  check for DESQview present and enable required extensions.
***********************************************************************/

main () {
  /* initialize C interfaces and get API version number */
  version = api_init();

  /* if DESQview is not running or version is too low, display a message */
  if (version < required) {
    printf ("This program requires DESQview version %d.02%d or later.\n",
             required/256,required%256);
    }

  else {
    /* tell DESQview what extensions to enable and start application */
    api_level (required);
    program_body();

    /* disable C interfaces and return from program */
    api_exit();
    }

  }


/********************************************************************
/*  program_body
/********************************************************************/

program_body () {

  /* get object handle */
  win = win_me();

  /* copy initial data into shared memory */
  *shrptr = shrconst;

  /* find named mailbox semaphore */
  sema = mal_find (name,sizeof (name));

  /* read pointer to mailed data */
  status = mal_read (mal_me(),shrptrptr,mallng);

  /* assign pointer to shared data by dereferencing pointer to pointer */
  shrptr = *shrptrptr;

  /* get the application task handle of other process */
  apphana = mal_addr (mal_me());

  /* begin critical region */
  api_beginc();

  /* loop till handle of other process is no longer valid */
  while (api_isobj (apphana)) {

    /* lock semaphore */
    mal_lock (sema);

    /* read & display current contents & address of shared data */
    win_printf (win,"%s at %Fp\n",*shrptr,*shrptr);

    /* modify contents of shared data */
    strcpy (*shrptr,shrconst);

    /* unlock semaphore */
    mal_unlock (sema);

    /* end critical region */
    api_endc();

    /* begin critical region */
    api_beginc();
    }

  }
