/****************************************************************
*
*  Name:          SHAREA
*
*  Function:      share memory/data with another process
*
*  Shows how to:  1. allocate and deallocate shared memory.
*                 2. read from and write to shared memory.
*                 3. mail to another process the address of shared data.
*                 4. control access to shared data via mailbox semaphore.
*
****************************************************************/

#include <stdio.h>
#include "dvapi.h"

/* minimum API version required */
#define required 0x201
#define piflen 416

/* API version number */
int version;

/* default object handle */
ulong win;

/* PIF-related variables */
FILE *fp,*fopen();
char dvpbuf[piflen];

/* application handle of other process */
ulong apphanb;

/* type declarations related to shared data */
typedef char *DATATYPE;
typedef DATATYPE *DATAPTR;

/* constant value to be assigned to shared memory */
DATATYPE shrconst = "AAAAA     ";

/* pointer to shared data */
DATAPTR shrptr;

/* mailbox semaphore controlling access to shared memory */
ulong sema;

/* global name of mailbox */
char *name = "Shared Memory Semaphore";


/**********************************************************************
*  main  -  check for DESQview present and enable required extensions.
***********************************************************************/

main () {
  /* initialize C interfaces and get API version number */
  version = api_init();

  /* if DESQview is not running or version is too low, display a message */
  if (version < required) {
    printf ("This program requires DESQview version %d.02%d or later.\n",
             required/256,required%256);
    }

  else {

    /* tell DESQview what extensions to enable and start application */
    api_level (required);
    program_body();

    /* disable C interfaces and return from program */
    api_exit();
    }

  }


/********************************************************************
/*  program_body
/*
/*  Set up named mailbox semaphore.  Start other process.  Allocate
/*  & initialize shared memory.  Mail pointer to shared data.
/*  Continuously read, display and modify contents of shared data.
/********************************************************************/

program_body () {

  /* get object handle */
  win = win_me();

  /* create & name mailbox semaphore */
  sema = mal_new();
  mal_name (sema,name,sizeof (name));

  /* disallow closing of window */
  win_disallow (win,ALW_CLOSE);

  /* read other process' dvp file into buffer area */
  fp = fopen ("SB-PIF.DVP","rb");
  fread (dvpbuf,piflen,1,fp);
  fclose (fp);

  /* start other process & get its task handle */
  apphanb = app_start (dvpbuf,piflen);

  /* allocate shared memory & get its buffer pointer */
  /* Api_getmem normally allocates "system memory" from within the
  /* "process memory" pool.  Such system memory is not shareable among other
  /* processes.  Instead, if system memory were to be allocated from the
  /* "shared memory" pool then system memory would be shareable among other
  /* processes.  In other words, all processes that use shared memory have
  /* access to each others' system memory.  Placing a single asterisk (*)
  /* in the Shared Memory Pathname field of the PIF file will accomplish this.
  /* See Chapter 16: Memory Management of the API Reference Manual. */
  shrptr = api_getmem (sizeof (shrconst));

  /* copy initial data into shared memory */
  strcpy(*shrptr,shrconst);

  /* mail to other process the pointer to shared data */
  mal_write (mal_of (apphanb),shrptr,sizeof (shrptr));

  /* begin critical region */
  api_beginc();

  /* loop till handle of other process is no longer valid */
  while (api_isobj (apphanb)) {

    /* lock semaphore */
    mal_lock (sema);

    /* read & display current contents & address of shared data */
    win_printf (win,"%s at %Fp\n",*shrptr,*shrptr);

    /* modify contents of shared data */
    strcpy (*shrptr,shrconst);

    /* unlock semaphore */
    mal_unlock (sema);

    /* end critical region */
    api_endc();

    /* begin critical region */
    api_beginc();
    }

  /* free allocated shared memory */
  api_putmem (shrptr);

  /* allow closing of window */
  win_allow (win,ALW_CLOSE);

  /* free allocated object */
  mal_free (sema);
  }