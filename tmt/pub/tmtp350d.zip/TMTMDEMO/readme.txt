                         Pascal Multi-target Compiler
                              [ Version 3.50 ]

                        TMT Development Corporation


Fetures
-------

  The Multi-target version of TMT Pascal Compiler will come on a CD whose
  price is $99, plus postage and handling. The TMT Pascal Multi-target has
  the following features:

  - You can easily build your own applications with TMT Pascal Multi-target
    for the following Operating Systems:  Windows' 95/98/2000/NT (GUI,
    Console, DLLs and CPls), OS/2 (PM, Console, DLLs) and MS-DOS 32-bit
    protected mode.
  - MS-DOS applications compiled with TMT Pascal Multi-target will work with
    many popular DOS-extenders, such as PMODE, PMODE/W, WDOSX and DOS/4GW.
  - Our built-in assembler supports the full 32-bit assembler Instruction set.
    We even support Intel MMX and AMD 3DNow! instructions for the creation of
    fast multimedia applications.
  - TMT Pascal Multi-target closely follows Borland Pascal syntax and has
    similar run-time libraries. Most of the standard run-time units are
    supported for all targets. Hence one can recompile old MS-DOS text-mode
    Pascal sources to create modern Win32 or OS/2 console applications.
  - One can compile old Turbo/Borland Pascal sources for DOS 32-bit protected
    mode or as Win32 or OS/2 console applications.
  - Advanced STUB file support. Allows any DOS program to be inserted as the
    STUB program into OS/2 and Win32 executables, instead of default ones.
  - Enhanced Graph unit, which provides SVGA banked and LFB video modes
    support in MS-DOS executables and uses Microsoft DirectDraw features in
    Win32 applications.
  - TMT Pascal Multi-target includes many examples and partial run-time
    source code (OS/2 and Win32 API, DOS, CRT, MOUSE, STRINGS, MATH, DPMI,
    WINDOS, GRAPH units etc) for all compilation targets.
  - TMT Pascal Multi-target is supplied with a standard IDE/Debugger for
    MS-DOS and an enhanced IDE for Windows 32-bit, which has the following
    features:
    * Syntax highlighting.
    * Multi-level undo buffer.
    * A comfortable multi-window editor, which allows one to edit and run
      sources.
    * A new Windows-based context-sensitive help system.
    * ANSI/OEM character insertion table.
    * A powerful search/replace engine, which allows one to find specified
      text in open windows and subdirectories.
    * An easy to use compiler options setup menu.
    * Multi-target compilation support.


Ordering the TMT Pascal Multi-target compiler
---------------------------------------------

  A license will get you the current version of the compiler plus all
  updates as they are released until the next major version.

  To order the TMT Pascal Multi-target compiler, send an email to
  sales@tmt.com with your credit card number and its expiration date
  (VISA, MC, AMEX, DISCOVER). Alternatively, call 1-631-689-3172 or send
  a check or money order to:

  TMT Development Corp.
  19 POPLAR AVE,
  Stony Brook, NY 11790-1751

  Foreign orders: if you are paying by check, please make sure
  that your check is in US dollars and drawn on a US bank.

  Postal orders: please make sure that your order specifies a contact
  email account.

  PO's: we will accept PO's from qualified institutions in the US and Canada.
  Please verify that your PO will be accepted before issuing it.


                              TMT Development Corporation (http://www.tmt.com)