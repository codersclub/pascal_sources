/**********************************************/
/* Example C DLL, to be loaded by CHELLO.PAS  */
/* Copyleft (C) 1999-2000 Virtual Research    */
/**********************************************/

#include <stdio.h>
#include "__tmt.h"
#include "dlltypes.h"

#pragma aux (__tmt) sayhello;
#pragma pack (1);

void sayhello() {
 printf("Hello world from DLL!\n");
}

static TExport_Table_Entry export_table_entry[2] = {
 { "SayHello",0,&sayhello },
 { NULL,0,NULL } };
 
static TExport_Table_Header export_table_header = {
 "%EXPORT%",
 &export_table_entry,
 NULL };

void main() {
 export_table_header.dummy_string = "Sample DLL (C) 1999 Virtual Research";
} 
