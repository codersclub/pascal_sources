Watch the tiger cross the screen.  Do do this first compile "Fli.pas".
Then run Fli.exe with the file "Tigercat.fli".

On a DOS line this means give the command: fli tigercat.fli
