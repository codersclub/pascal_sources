Ripples
-------

A demo showing the effect of water drops falling into some water. I
haven�t yet been able to test it on many machines, but on my machine
it looks very real. I don�t know what will happen on faster machines.
My machine = Cel 450 + GeForce.

Keys : 
 "H" - display the help screen
 "W" - add/remove the floating wedge
 "+/-" - increase and decreases the interval in which drops will fall.
 "Space" - adds another drop to the water
 Arrow keys - rotate the scene

If you have any queries or bug reports, please mail me.

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
