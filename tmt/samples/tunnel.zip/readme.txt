Plasma Tunnel
-------------

Another wormhole type effect. If you plan to use this effect somewhere else, 
please mention my name and URL.

If you have any queries or bug reports, please mail me.

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

