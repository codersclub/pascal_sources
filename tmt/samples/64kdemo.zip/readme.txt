                             64K Demo
                             --------

A demo entry for Optimize 2001

Demo Requirements
  System........      win98/win2k with OpenGL
  Cpu...........      Pentium 3 or athlon recommended.
  Video.........      opengl accelerated 3d card.
  Audio.........      windows compatible soundcard.
  
I have tested the demo on a P3-733 with a TNT2 video card running at 800x600. 

Demo created by 
  Code..........      Jan Horn
  Design........      Jan Horn
  Graphics......      Jan Horn

Compiled for the windows platform using Borland Delphi 5.  

For this demo and many others all containing full source code, 
visit my website at : http://www.sulaco.co.za

If you have any queries or bug reports, please mail me.

Name : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

