Environment mapped metaballs
----------------------------

This app uses spherical environment mapping applied to the metaballs to create metaballs that look like they are reflective liquid metal. You can increase and decrease the quality of the metaballs by pressing + and - on the keypad. 

To find out more about metaballs have a look at the article put up by Paul Burke (http://www.swin.edu.au/astronomy/pbourke/modelling/). There you will find an excellent explanation on how the marching cubes algorithm works.

Keys :
  +/- : increase and descrease quality
  W : toggle wireframe mode.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn
