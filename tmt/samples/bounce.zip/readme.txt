Bouncing Ball
-------------

This program simply has a ball bouncing on a surface below. As it hits the surface the ball is squashed and then bounces back up again.  
The ball has some spherical environment mapping applied to it, both of which is reflected in the surface below.

The original idea was from a similar program by Andreas Gustafsson.

If you have any queries or bug reports, please mail me

Code : Jan Horn
Mail : jhorn@global.co.za
Web  : http://www.sulaco.co.za
       http://home.global.co.za/~jhorn

