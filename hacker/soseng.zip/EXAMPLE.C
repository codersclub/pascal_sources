/*
   EXAMPLE.C
   How to use the SOS-ENGINE with C
   Be sure to add SOSFUNC to your link statement
*/

void_main
{

   SeOnLog;                 /* Turn on logging */

}
