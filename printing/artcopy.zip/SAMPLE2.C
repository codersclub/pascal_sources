/* =======================================================================   */
/*           SAMPLE2.C                                                       */
/*    This is a sample of a C program which uses BGIPrint drivers.           */
/*    It uses portions of Borland's BGI Demo to illustrate the compatibility */
/*    of BGI Print with screen drivers.                                      */
/*                                                                           */
/*    Please note the use of calculated x-y coordinates based on values      */
/*    returned by GETMAXX and GETMAXY.                                       */
/*                                                                           */
/*    To run this sample, ensure that the BGIPrint drivers are in the        */
/*    current directory along with the CHR files supplied with Turbo C       */
/*                                                                           */
/*                                                                           */
/*   Written by Glen McDonald                                                */

#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <conio.h>


#define adjasp( y ) ((int)(AspectRatio * (double)(y)))
#define PI          3.14159         /* Define a value for PI    */
#define CLIP_ON     1
#define TRUE        1
#define FALSE       0


/* ---------- Global Variables ---------- */

int     driver, mode, testdriver, errcode,
        maxX, maxY, maxcolor, fillcolor,
        numpens = 8;                   /* plotter has this many pens */

char    prname[7];
double  AspectRatio;

/* ------------ Function Prototypes ----------- */
void intro(void);
void initprinter(void);
void pieplay(void);
void bar3dplay(void);
void gettextcoords(int AngleInDegrees, int *radius, int *x, int *y);
int huge testdetect(void);


int main(void)
    {
    intro();
    initprinter();
    pieplay();
    printf("\a");
    printf("Press any key for\n");
    printf("3D bar demo\n");
    getch();
    closegraph();
    initprinter();
    bar3dplay();
    printf("\a");
    printf("Press any key to quit\n");
    getch();
    closegraph();
    return 0;
    }

void intro(void)
    {
    char *bgidrvrs[] = { "HPPCL", "MATRIX", "HPGL", "SCREEN" };
    int ch, needchoice = TRUE;

    clrscr();
    printf("                               BGI Print\n");
    printf("                    Copyright (c) Bruce McAra, 1991\n");
    printf("                           All Rights Reserved\n");
    printf("                   Demonstration Program for Turbo C\n");
    printf("            ***************************************************\n");
    printf("                1. HP Laser Jet (PCL) on LPT1\n");
    printf("                2. Epson Compatible Dot Matrix on LPT1\n");
    printf("                3. HPGL Pen Plotter on COM1\n");
    printf("                4. Screen\n\n");
    printf("                     Select a printer Driver by Number:  ");

    do
        {
        ch = getch();
        if((ch >= 0x31 && ch <= 0x34) || ch == 0x1B)
            needchoice = FALSE;
        } while (needchoice == TRUE);

    if (ch == 0x1B)
        {
        printf("Terminating program\n");
        exit(0);
        }
    else
        {
        strcpy(prname, bgidrvrs[ch-0x31]);
        printf("\nPrinting to %s\n", prname);
        }
    }


void initprinter(void)
    {
    /* Install the driver */
    if (!strcmp(prname, "HPGL"))
        {
        printf("Please insert paper into plotter and Press any key when ready");
        getch();
        }

    if (strcmp(prname, "SCREEN"))
        {
        testdriver = installuserdriver(prname, testdetect);
        if (graphresult() != grOk)
            {
            printf("Error installing driver\n");
            exit(1);
            }
        driver = DETECT;
        printf("Initializing graphics buffer\n");
        initgraph(&driver, &mode, "");
        errcode = graphresult();
        if (errcode != grOk)
            {
            printf("Error during Init: %s\n", grapherrormsg(errcode));
            exit(1);
            }
        else
            printf("INIT OK\n");
        }
    else
        {
        driver = DETECT;
        initgraph(&driver, &mode, "");
        }
    maxX = getmaxx();
    maxY = getmaxy();
    if (!strcmp(prname, "HPGL"))
        maxcolor = numpens;
    else
        maxcolor = getmaxcolor();
    }

void pieplay(void)
    {
    struct viewporttype vp;
    int centerX, centerY, x, y;
    int radius, xasp, yasp;
    double piesize;

    printf("Doing Pie Chart\n");
    getaspectratio(&xasp, &yasp);
    AspectRatio = (double)xasp / (double)yasp;
    getviewsettings( &vp );               /* Get the current viewport */
    centerX = (vp.right - vp.left) / 2;   /* Center the Pie horizontally  */
    centerY = (vp.bottom - vp.top) / 2+20;/* Center the Pie vertically    */
    radius  = (vp.bottom - vp.top) / 3;   /* It will cover 2/3rds screen  */
    piesize = (vp.bottom - vp.top) / 4.0; /* Optimum height ratio of pie  */

    while( (AspectRatio*radius) < piesize ) ++radius;

    settextstyle( TRIPLEX_FONT, HORIZ_DIR, 4 );
    settextjustify( CENTER_TEXT, TOP_TEXT );
    outtextxy( maxX/2, 6, "This is a Pie Chart" );
    printf("Title Done\n");

    settextstyle( TRIPLEX_FONT, HORIZ_DIR, 1 );
    settextjustify( CENTER_TEXT, TOP_TEXT );

    fillcolor = 2;
    printf("Fill color = %d\n", fillcolor);
    setfillstyle( SOLID_FILL, fillcolor );
    pieslice( centerX+10, centerY-adjasp(10), 0, 90, radius );
    gettextcoords(45, &radius, &x, &y);
    settextjustify( LEFT_TEXT, BOTTOM_TEXT );
    outtextxy( centerX+10+x+textwidth((char far *)"H"), centerY-adjasp(10+y), "25 \%");
    printf("Segment Done\n");

    fillcolor = 3;
    printf("Fill color = %d\n", fillcolor);
    setfillstyle( LTSLASH_FILL, fillcolor);
    pieslice( centerX, centerY, 225, 360, radius );
    gettextcoords(293, &radius, &x, &y);
    settextjustify( LEFT_TEXT, TOP_TEXT );
    outtextxy( centerX+x+textwidth("H"), centerY-adjasp(y), "37.5 \%");
    printf("Segment Done\n");
    printf("Fill color = %d\n", fillcolor = 4);
    setfillstyle( BKSLASH_FILL, fillcolor );
    pieslice(centerX-10, centerY, 135, 225, radius);
    gettextcoords(180, &radius, &x, &y);
    settextjustify( RIGHT_TEXT, CENTER_TEXT );
    outtextxy(centerX-10+x-textwidth("H"), centerY-adjasp(y), "25 \%");
    printf("Segment Done\n");

    printf("Fill color = %d\n", fillcolor = 5);
    setfillstyle(WIDE_DOT_FILL, fillcolor);
    pieslice(centerX, centerY, 90, 135, radius);
    gettextcoords(112, &radius, &x, &y);
    settextjustify(RIGHT_TEXT, BOTTOM_TEXT);
    outtextxy(centerX+x-textwidth("H"), centerY-adjasp(y), "12.5 \%");
    printf("Chart done\n");
    }

void bar3dplay(void)
    {
    int numbars = 7;
    int barheight[] = {1,3,2,4,3,2,1};
    int Yticks = 5;                     /* The number of tick marks on the
                                         * Y axix */
    struct viewporttype vp;
    unsigned h, depth, color, t;
    int i, j, xstep, ystep;
    char buffer[10];

    printf("3d Bar Chart\n");
    h = 3 * textheight("M");
    t = 2 * textheight("M");
    getviewsettings(&vp);
    settextjustify(CENTER_TEXT, TOP_TEXT);
    settextstyle(TRIPLEX_FONT, HORIZ_DIR, 4);
    outtextxy(maxX / 2, t, "These are 3D bars");
    printf("Title done\n");
    settextstyle(SMALL_FONT, HORIZ_DIR, 4);
    setviewport(vp.left+50, vp.top+40, vp.right-50, vp.bottom-10, CLIP_ON);
    getviewsettings(&vp);
    line(h, h, h, (vp.bottom - vp.top) - h);
    line(h, (vp.bottom - vp.top) - h, (vp.right - vp.left) - h,
                                        (vp.bottom - vp.top) - h);
    ystep = ((vp.bottom - vp.top) - (2*h)) / Yticks;
    xstep = ((vp.right - vp.left) - (2*h)) / numbars;
    j = (vp.bottom - vp.top) - h;
    t = textwidth("M");
    settextjustify(CENTER_TEXT, CENTER_TEXT);

    /* Draw the Y axis and tick marks */
    for(i = 0; i < Yticks; ++i)
        {
        line(h / 2, j, h, j);
        itoa(i, buffer, 10);
        outtextxy(h/2 - t, j, buffer);
        j -= ystep;
        }
    printf("Y axis done\n");
    depth = (int)(0.25 * xstep);        /* Calculate depth of bar */

    /* Draw X axis, bars, and tick marks */
    j = h;
    settextjustify(CENTER_TEXT, TOP_TEXT);
    color = 1;
    for ( i = 1; i <= numbars + 1; i++)
        {
        setcolor(1);
        line(j, (vp.bottom-vp.top)- h, j, (vp.bottom-vp.top-3)-(h/2));
        itoa(i-1, buffer, 10);
        outtextxy(j, (vp.bottom-vp.top)-(t*2), buffer);
        printf("%s\n", buffer);
        if (i != numbars+1)
            {
            color = color + 1;
            setfillstyle(i, color);
            setcolor(color);
            bar3d(j,
                  ((vp.bottom-vp.top-h)-(barheight[i-1] * ystep)),
                  j+xstep-depth, ((vp.bottom-vp.top)-h-1), depth,1);
            j += xstep;
            printf("Bar Done\n");
            }
        }
    printf("Chart Done\n");
    }







void gettextcoords(int AngleInDegrees, int *radius, int *x, int *y)
    {
    double radians;

    radians = AngleInDegrees * PI / 180;
    *x = cos(radians) * *radius + 0.5;
    *y = sin(radians) * *radius + 0.5;
    }

int huge testdetect(void)
    {
    /* Autodetect function.  Assume hardware is always present.
     * Return value = recommended default mode */

    return 1;
    }













