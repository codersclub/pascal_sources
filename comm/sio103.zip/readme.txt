
*** RIGHTS
----------

              You are free to
                - take copies of SerialIO and programs/units
                  delivered with it
                - deliver it in public or private networks
                - add your own code
                - use it in your commercial or non-commercial
                  programs

                AS LONG AS THE NAME OF THE ORIGINAL AUTHOR IS
                MENTIONED IN THE CODE AND PROGRAMS USING SERIALIO
                AS IT IS IN THE ORIGINAL SOURCE OF SERIALIO!!!

                If you decide to change the code of SerialIO or
                some unit/program delivered with it, remember to
                comment the code lines that will be changed. In
                other words: do NOT delete a line of code!
                Remember also to write detailed explanations what
                changes have been done, why and by who (name and
                e-mail).


*** PURPOSE
-----------

                The purpose of SerialIO is not to be a fast
                serial I/O tool-kit but to be some kind of source
                to those programmers who don't know very much
                about hardware programming but are intrested in
                it. I hope that this piece of human work would
                help that people to understand how to make
                programs that use for example interrupts, UART or
                some other chips.


*** CONTACT
-----------

                In the case you have found a bug or you just have
                in your mind something that is in close relation
                to SerialIO, please contact me by sending e-mail.
                There are not only one or two, but several things
                that still make me hesitate... If you feel, that
                you have a better solution to some problem, let
                me know it too.


On Saturday 22 October 1994 in Espoo, Finland

Dado.Colussi@Helsinki.FI		University of Helsinki, Finland
http://www.helsinki.fi/~gcolussi	Department of Computer Science

