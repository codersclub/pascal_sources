/* ------------------------------------------------------------------------
   CTDEMO.C - coolTimer Demo Program

   Copyright(c) 1996 by B-coolWare.  Written by Bobby Z.
   ------------------------------------------------------------------------ */
#include "timer.h"
#include <stdio.h>

unsigned char Counter = 0;
unsigned int  Cnt1 = 0,
              Cnt2 = 0;

void far h0( void ) {   /* should be void and far */
asm {
        mov     ax,seg Counter
        mov     ds,ax
        inc     Counter
        mov     ah,0x02
        mov     dl,0x30
        int     0x21
    }   /* just put a character on screen */
}

void far h1( void ) {
asm {
        mov     ax,seg Cnt1
        mov     ds,ax
        inc     Cnt1
        mov     ah,0x02
        mov     dl,0x31
        int     0x21
    }   /* the same as above */
}

void far h2( void ) {
asm {
        mov     ax,seg Cnt2
        mov     ds,ax
        inc     Cnt2
        mov     ah,0x02
        mov     dl,0x32
        int     0x21
    }   /* the same as above */
}

void main( void ) {

puts("coolTimer 1.21/C Demo  Copyright(c) 1993-96 by B-coolWare.\n");
puts("Each number corresponds to different timer handler working at different\nrate. Enjoy :)");
grabTimer();
setTimerHandler(1,30,h1); /* 30 times per second */
setTimerHandler(2,60,h2); /* 60 times per second */
setTimerHandler(0,18,h0); /* standard rate */
while (Counter < 91) ;    /* do it for five seconds */
printf("\nHandler #0 was called %d times, #1 - %d times and #2 - %d times.\n",
        Counter, Cnt1, Cnt2);
}
