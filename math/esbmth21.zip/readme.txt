Program: ESBMaths v2.1 Released: 13 July 1999

Purpose: Freeware Maths/Stats Routine Collection for Delphi.

More Info: See ESBMaths.TXT

Installation: unzip into a dir of your choice. 
Place PAS file in Library Path. 

Status: Freeware, freely distributable

Contact: Glenn Crouch mailto:support@esbconsult.com.au
