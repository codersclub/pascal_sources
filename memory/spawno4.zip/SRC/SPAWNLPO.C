/********************************************************************/
/*   SPAWNO v4.0   EMS/XMS/disk swapping replacement for spawn...() */
/*   (c) Copyright 1990, 1991 Ralf Brown  All Rights Reserved	    */
/*								    */
/*   May be freely copied provided that this copyright notice is    */
/*   not altered or removed.					    */
/********************************************************************/

#include "_spawno.h"

extern int _Cdecl errno ;
extern int _Cdecl _doserrno ;
char * pascal __spawn_search(const char *) ;

int _Cdecl spawnlpo(const char *overlay_path,const char *prog_name,...)
{
   char *prog_path = __spawn_search(prog_name) ;

   if (prog_path)
      return __spawnv(overlay_path,prog_path,(const char **)_va_ptr,ENV_SEG) ;
   else
      {
      errno = ENOENT ;	 /* _doserrno already set by __spawn_search() */
      return -1 ;
      }
}

