/********************************************************************/
/*   SPAWNO v4.0   EMS/XMS/disk swapping replacement for spawn...() */
/*   (c) Copyright 1990, 1991 Ralf Brown  All Rights Reserved	    */
/*								    */
/*   May be freely copied provided that this copyright notice is    */
/*   not altered or removed.					    */
/********************************************************************/

#include "spawno.h"

int _Cdecl spawnlo(const char *overlay_path,const char *prog_name,...)
{
   return __spawnv(overlay_path,prog_name,(const char **)_va_ptr,0) ;
}
