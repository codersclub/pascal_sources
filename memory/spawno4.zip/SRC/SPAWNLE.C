/********************************************************************/
/*   SPAWNO v4.0   EMS/XMS/disk swapping replacement for spawn...() */
/*   (c) Copyright 1990, 1991 Ralf Brown  All Rights Reserved	    */
/*								    */
/*   May be freely copied provided that this copyright notice is    */
/*   not altered or removed.					    */
/********************************************************************/

#include <alloc.h>
#include "_spawno.h"

int _Cdecl spawnleo(const char *overlay_path,const char *prog_name,...)
{
   int retval ;
   va_list env ;

   va_start(env,1) ;
   while (*((char **)env))  /* find NULL terminating list of program args */
      va_arg(env,void*) ;
   va_arg(env,const char **) ;     /* point at pointer to list of env variables */
   retval = __spawnv(overlay_path,prog_name,(const char **)_va_ptr,
		      __spawn_buildenv(*((const char ***)env))) ;
   va_end(env) ;
   __spawn_free_env() ;
   return retval ;
}
