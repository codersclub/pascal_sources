/********************************************************************/
/*   SPAWNO v4.0   EMS/XMS/disk swapping replacement for spawn...() */
/*   (c) Copyright 1991 Ralf Brown  All Rights Reserved 	    */
/*								    */
/*   May be freely copied provided that this copyright notice is    */
/*   not altered or removed.					    */
/********************************************************************/

#include <alloc.h>
#include "_spawno.h"

int _Cdecl spawnve(int type,const char *prog_name,const char **args,
		  const char **env)
{
   if (type != P_WAIT)
      {
      errno = EINVAL ;
      return -1 ;
      }
   return spawnveo(___spawn_swap_dirs,prog_name,args,env) ;
}


int _Cdecl spawnle(int type,const char *prog_name, ...)
{
   int retval ;
   va_list env ;

   if (type != P_WAIT)
      {
      errno = EINVAL ;
      return -1 ;
      }
   va_start(env,1) ;
   while (*((char **)env))  /* find NULL terminating list of program args */
      va_arg(env,void *) ;
   va_arg(env,const char **) ;     /* point at pointer to list of env variables */
   retval = spawnveo(___spawn_swap_dirs,prog_name,(const char **)_va_ptr,
		     *((const char ***)env)) ;
   va_end(env) ;
   return retval ;
}

