/********************************************************************/
/*   SPAWNO v4.0   EMS/XMS/disk swapping replacement for spawn...() */
/*   (c) Copyright 1991 Ralf Brown  All Rights Reserved 	    */
/*								    */
/*   May be freely copied provided that this copyright notice is    */
/*   not altered or removed.					    */
/********************************************************************/

#include "_spawno.h"

int _Cdecl spawnvp(int type,const char *prog_name,const char **args)
{
   if (type != P_WAIT)
      {
      errno = EINVAL ;
      return -1 ;
      }
#ifdef USE_ENVP
   return spawnvpeo(___spawn_swap_dirs,prog_name,args,ENVP) ;
#else
   return spawnvpo(___spawn_swap_dirs,prog_name,args) ;
#endif
}

int _Cdecl spawnlp(int type,const char *prog_name, ...)
{
   return spawnvp(type,prog_name,(const char **)_va_ptr) ;
}
