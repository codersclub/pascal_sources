/********************************************************************/
/*   SPAWNO v4.0   EMS/XMS/disk swapping replacement for spawn...() */
/*   (c) Copyright 1991 Ralf Brown  All Rights Reserved 	    */
/*								    */
/*   May be freely copied provided that this copyright notice is    */
/*   not altered or removed.					    */
/********************************************************************/

#include "_spawno.h"

void _Cdecl init_SPAWNO(const char *overlay_path, int swap_types)
{
   const char *swapdirs ;

   swapdirs = getenv("SWAPDIR") ;
   if (!swapdirs && overlay_path && *overlay_path)
      swapdirs = overlay_path ;
   if (!swapdirs)
      swapdirs = getenv("TEMP") ;
   if (!swapdirs)
      swapdirs = getenv("TMP") ;
   if (swapdirs)
      ___spawn_swap_dirs = swapdirs ;
   __spawn_ext = (swap_types & SWAP_EXT) != 0 ;
   __spawn_ems = (swap_types & SWAP_EMS) != 0 ;
   __spawn_xms = (swap_types & SWAP_XMS) != 0 ;
}

