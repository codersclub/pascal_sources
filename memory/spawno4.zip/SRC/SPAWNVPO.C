/********************************************************************/
/*   SPAWNO v4.0   EMS/XMS/disk swapping replacement for spawn...() */
/*   (c) Copyright 1990, 1991 Ralf Brown  All Rights Reserved	    */
/*								    */
/*   May be freely copied provided that this copyright notice is    */
/*   not altered or removed.					    */
/********************************************************************/

#include "_spawno.h"

int _Cdecl spawnvpo(const char *overlay_path, const char *prog_name,
		    const char **args)
{
   char *prog_path = __spawn_search(prog_name) ;

   if (prog_path)
      return __spawnv(overlay_path,prog_path,args,0) ;
   else
      {
      errno = ENOENT ;	/* path or filename not found */
			/* _doserrno already set by __spawn_search() */
      return -1 ;
      }
}

