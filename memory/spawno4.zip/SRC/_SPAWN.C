/********************************************************************/
/*   SPAWNO v4.0   EMS/XMS/disk swapping replacement for spawn...() */
/*   (c) Copyright 1991 Ralf Brown  All Rights Reserved 	    */
/*								    */
/*   May be freely copied provided that this copyright notice is    */
/*   not altered or removed.					    */
/********************************************************************/

#include "_spawno.h"

int _Cdecl spawnv(int type,const char *prog_name,const char **args)
{
   if (type != P_WAIT)
      {
      errno = EINVAL ;
      return -1 ;
      }
#ifdef USE_ENVP
   return spawnvo(___spawn_swap_dirs,prog_name,args,ENVP) ;
#else
   return __spawnv(___spawn_swap_dirs,prog_name,args,0) ;
#endif
}

int _Cdecl spawnl(int type,const char *prog_name, ...)
{
   return spawnv(type,prog_name,(const char **)_va_ptr) ;
}
