/********************************************************************/
/*   SPAWNO v4.0   EMS/XMS/disk swapping replacement for spawn...() */
/*   (c) Copyright 1990, 1991 Ralf Brown  All Rights Reserved	    */
/*								    */
/*   May be freely copied provided that this copyright notice is    */
/*   not altered or removed.					    */
/********************************************************************/

#include "_spawno.h"
#include <alloc.h>

int _Cdecl spawnveo(const char *overlay_path, const char *name, const char **args,
		    const char **env)
{
   int retval ;
   
   retval = __spawnv(overlay_path,name,args,__spawn_buildenv(env)) ;
   __spawn_free_env() ;
   return retval ;
}
