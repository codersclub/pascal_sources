
/* ---------------------------------------------------------------------*/
/*									*/
/*	XMS Interface for Borland C/C++, Version 1.0			*/
/*	Developed by Tanescu A. Horatiu					*/
/*	January 1997							*/
/*									*/
/* ---------------------------------------------------------------------*/
/*	C sources							*/
/* ---------------------------------------------------------------------*/
/*									*/
/*	XMSVER.C							*/
/*									*/
/*	XMS driver version information routines				*/
/*	(xmsverinfo, xmsver)						*/
/*									*/
/* ---------------------------------------------------------------------*/

#include "xms.h"

#pragma inline

/* xmsverinfo - get the XMS version number and the driver internal revision
   number and query the existence of HMA
 */

unsigned int xmsverinfo(unsigned int* revision, int* HMA)
{
  asm	xor	ah, ah
  xmscontrol();
  *revision = _BX;
  *HMA = _DX;
  return (_AX);
}

/* xmsver - get the XMS version number
 */

unsigned int xmsver(void)
{
  asm	xor	ah, ah
  xmscontrol();
  return (_AX);
}