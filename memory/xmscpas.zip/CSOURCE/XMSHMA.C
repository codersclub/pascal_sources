
/* ---------------------------------------------------------------------*/
/*									*/
/*	XMS Interface for Borland C/C++, Version 1.0			*/
/*	Developed by Tanescu A. Horatiu					*/
/*	January 1997							*/
/*									*/
/* ---------------------------------------------------------------------*/
/*	C sources							*/
/* ---------------------------------------------------------------------*/
/*									*/
/*	XMSHMA.C							*/
/*									*/
/*	High Memory Area management routines				*/
/*	(hmarequest, hmarelease)					*/
/*									*/
/* ---------------------------------------------------------------------*/

#include "xms.h"

#pragma inline

/* hmarequest - request HMA
 */

int hmarequest(unsigned int reqsize)
{
  asm	mov	dx, reqsize
  asm	xor	bl, bl
  asm	mov	ah, 0x01
  xmscontrol();
  asm	mov	xmserrno, bl
  return (_AX);
}

/* hmarelease - release HMA
 */

int hmarelease(void)
{
  asm	xor	bl, bl
  asm	mov	ah, 0x02
  xmscontrol();
  asm	mov	xmserrno, bl
  return (_AX);
}