
/* ---------------------------------------------------------------------*/
/*									*/
/*	XMS Interface for Borland C/C++, Version 1.0			*/
/*	Developed by Tanescu A. Horatiu					*/
/*	January 1997							*/
/*									*/
/* ---------------------------------------------------------------------*/
/*	C sources							*/
/* ---------------------------------------------------------------------*/
/*									*/
/*	XMSXM.C								*/
/*									*/
/*	eXtended memory management routines				*/
/*	(xmfreespace, xmcontig, xmalloc, xmfree, xmemcpy, ctoxm, xmtoc,	*/
/*	xmtoxm, ctoc, xmlock, xmunlock, xmhandleinfo, xmrealloc)	*/
/*									*/
/* ---------------------------------------------------------------------*/

#include <dos.h>
#include "xms.h"

#pragma inline

/* xmfreespace - get the amount of free extended memory
 */

unsigned int xmfreespace(void)
{
  asm	xor	bl, bl
  asm	mov	ah, 0x08
  xmscontrol();
  asm	mov	xmserrno, bl
  return (_DX);
}

/* xmcontig - get the size of the largest free extended memory block
 */

unsigned int xmcontig(void)
{
  asm	xor	bl, bl
  asm	mov	ah, 0x08
  xmscontrol();
  asm	mov	xmserrno, bl
  return (_AX);
}

/* xmalloc - allocate extended memory block
 */

xmhandle xmalloc(unsigned int size)
{
  asm	mov	dx, size
  asm	xor	bl, bl
  asm	mov	ah, 0x09
  xmscontrol();
  asm	mov	xmserrno, bl
  asm	or	ax, ax
  asm	je	AllocFailed
  return (_DX);
AllocFailed:
  return (_AX);
}

/* xmfree - free extended memory block
 */

int xmfree(xmhandle hxmem)
{
  asm	mov	dx, hxmem
  asm	xor	bl, bl
  asm	mov	ah, 0x0A
  xmscontrol();
  asm	mov	xmserrno, bl
  return (_AX);
}

/* xmemcpy - copy extended memory block (generic function)
 */

int xmemcpy(xmemcpy_t *x)
{
  _SI = FP_OFF(x);
  asm	push	ds
  _DS = FP_SEG(x);
  asm	xor	bl, bl
  asm	mov	ah, 0x0B
  xmscontrol();
  asm	pop	ds
  asm	mov	xmserrno, bl
  return (_AX);
}

/* ctoxm - copy block from conventional to extended memory
 */

int ctoxm(xmhandle desthandle, unsigned long destoff,
	  void far *source,
	  unsigned long n)
{
  xmemcpy_t x;
  x.xmc_count = n;
  x.xmc_srchandle = 0;
  x.xmc_srcoff = (unsigned long)source;
  x.xmc_desthandle = desthandle;
  x.xmc_destoff = destoff;
  return xmemcpy(&x);
}

/* xmtoc - copy block from extended to conventional memory
 */

int xmtoc(void far *dest,
	  xmhandle srchandle, unsigned long srcoff,
	  unsigned long n)
{
  xmemcpy_t x;
  x.xmc_count = n;
  x.xmc_srchandle = srchandle;
  x.xmc_srcoff = srcoff;
  x.xmc_desthandle = 0;
  x.xmc_destoff = (unsigned long)dest;
  return xmemcpy(&x);
}

/* xmtoxm - copy block within extended memory
 */

int xmtoxm(xmhandle desthandle, unsigned long destoff,
	   xmhandle srchandle,  unsigned long srcoff,
	   unsigned long n)
{
  xmemcpy_t x;
  x.xmc_count = n;
  x.xmc_srchandle = srchandle;
  x.xmc_srcoff = srcoff;
  x.xmc_desthandle = desthandle;
  x.xmc_destoff = destoff;
  return xmemcpy(&x);
}

/* ctoc - copy block within conventional memory
 */

int ctoc(void far *dest,
	 void far *source,
	 unsigned long n)
{
  xmemcpy_t x;
  x.xmc_count = n;
  x.xmc_srchandle = 0;
  x.xmc_srcoff = (unsigned long)source;
  x.xmc_desthandle = 0;
  x.xmc_destoff = (unsigned long)dest;
  return xmemcpy(&x);
}

#define MAKELONG(low, high) ((unsigned long)(((unsigned int)(low)) | (((unsigned long)((unsigned int)(high))) << 16)))

/* xmlock - lock extended memory block
 */

unsigned long xmlock(xmhandle hxmem)
{
  asm	mov	dx, hxmem
  asm	xor	bl, bl
  asm	mov	ah, 0x0C
  xmscontrol();
  asm	mov	xmserrno, bl
  asm	or	ax, ax
  asm	je      LockFailed
  return (MAKELONG(_BX, _DX));
LockFailed:
  return (_AX);
}

/* xmunlock - unlock extended memory block
 */

int xmunlock(xmhandle hxmem)
{
  asm	mov	dx, hxmem
  asm	xor	bl, bl
  asm	mov	ah, 0x0D
  xmscontrol();
  asm	mov	xmserrno, bl
  return (_AX);
}

/* xmhandleinfo - get EMB handle information
 */

int xmhandleinfo(xmhandle hxmem, unsigned int* size, unsigned char* lockcount, unsigned char* freehandles)
{
  asm	mov	dx, hxmem
  asm	xor	bl, bl
  asm	mov	ah, 0x0E
  xmscontrol();
  asm	or	ax, ax
  asm	je      FlagsQueryFailed
  *lockcount = _BH;
  *freehandles = _BL;
  *size = _DX;
  asm	mov	xmserrno, 0
  return (_AX);
FlagsQueryFailed:
  asm	mov	xmserrno, bl
  return (_AX);
}

/* xmrealloc - reallocate extended memory block
 */

int xmrealloc(xmhandle hxmem, unsigned int newsize)
{
  asm	mov	bx, newsize
  asm	mov	dx, hxmem
  asm	xor	bl, bl
  asm	mov	ah, 0x0F
  xmscontrol();
  asm	mov	xmserrno, bl
  return (_AX);
}