//WAVEEXAM.PAS / EXAMPLE FOR A WAVES EFFECT//
//WRITING BY THE KING IN 01/06/96          //


#include "kmagunit.c"
#include <math.h>
#include <alloc.h>
#define WAVES 3
#define SINWAVES 7
#define PI 3.14159

int y,t,t1;
char sinT[360],cosT[360];
unsigned char *Pic;
PaletteType Pal;

//-------------------------------------------------//
//        Make a Sin/Cos Tables of Shortint        //
//-------------------------------------------------//
void MakeSinCos()
{
int T;

    for(T=0;T<360;T++) {
        sinT[T]=(sin(T*PI/180))*127;
        cosT[T]=(cos(T*PI/180))*127;
    }
}

//Paint a vertrical line on the Y
void VLine(int Y,unsigned char Col){
    asm {
        Mov Ax,0x0a000          //Ax = screen segment//
        Mov Es,Ax               //Es = Ax//
        Mov Ax,320              //Ax = 320//
        Mul Y                   //Ax = 320 * Y//
        Mov Di,Ax               //Di = Ax//
        Mov Al,Col              //Al = Col//
        Mov Ah,Col              //Ah = Col//
        Mov Cx,160              //Cx = 160//
        Rep StoSw               //[Es:Di] = Al;[Es:Di+1] = Ah;Inc Di,2//
    }
}
//Draw one line from Where Y1 to Where1 Y//
void DrawVLine(int Y,int Y1,unsigned char *Where,unsigned char *Where1){
asm {
    Cmp Y1,199                  //Checking Ranges On Y1
    Ja Exit
    Cmp Y,199                   //Checking Ranges On Y
    Ja Exit
    Push Ds                     //Saving DS
    Lds Si,Where                //[Ds:Si] = Where
    Mov Ax,320                  //Ax = 320
    Mul Y                       //Ax = Y * 320
    Add Si,Ax                   //Si = Ax
    Les Di,Where1               //[Es:Di] = Where1
    Mov Ax,320                  //Ax = 320
    Mul Y1                      //Ax = Y1 * 320
    Add Di,Ax                   //Di = Ax
    Mov Cx,160                  //Cx = 160
    Rep MovSw                   //[Es:Di] = [Ds:Si];Inc Di,2;Inc Si,2;*320
    Pop Ds                      //Restore Ds
}
Exit:
}

void main() {
    Pic = (char *)malloc(64000);
    MakeSinCos();
    SetMode();
    t = 0;
    t1 = 0;
    //Load Picture
    LoadCel("sea.cel",Pic,Pal);
    //Put Pal
    ShowPal(Pal);
    VLine(9,54);
    VLine(181,54);
    do {
        for(y=10;y<=180;y++){
            t = t + WAVES;
            t1 = (sinT[t % 360] * SINWAVES) / 127;
            DrawVLine(t1+y,y,Pic,(unsigned char *)MK_FP(0xa000,0));
        }
        t = t - 170 * WAVES;
    } while(inp(0x60) != 1);
}