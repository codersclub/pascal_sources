/* ------------------------------------------------------------------------- */
/* CPU.C  Sample program demonstrating usage of TMi0SDGL(tm) routines        */
/* 									     */
/* Copyright(c) 1994 by B-coolWare.  Written by Bobby Z.		     */
/* ------------------------------------------------------------------------- */
/* files needed to build project:
   CPU.C		- compile with memory model XXX
   CPUTYPE.C		- compile with memory model XXX
   CPU_HL.ASM		- set memory model to XXX,C
   CPUSPEED.ASM		- set memory model to XXX,C
*/

#include <stdio.h>
#include "cputype.h"

void main()
{
 puts("CPU Type Identifier/C  Version 1.14e  Copyright(c) 1994 by B-coolWare.\n");

 /* due to parameters passing convention CPU_Speed() routine will be called
    first, when _CPU is not yet defined. So we should call cpuType_Str
    before invoking CPU_Speed() */
 printf("  Processor: %s, ",cpuType_Str());
 printf("%dMHz\n",intCPU_Speed());
 printf("Coprocessor: %s\n",fpuType_Str());
}
