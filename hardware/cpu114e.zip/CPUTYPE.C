/* ------------------------------------------------------------------------- */
/* CPUTYPE.C  CPU/FPU detection routines				     */
/*									     */
/* Copyright(c) 1994 by B-coolWare.  Written by Bobby Z. and VAP.	     */
/* Uses portions of TMi0SDGL(tm) v1.14					     */
/* ------------------------------------------------------------------------- */
/* files needed to build:
   
   CPUTYPE.C		- compile with memory model XXX
   CPU_HL.ASM		- set memory model to XXX,C
   CPUSPEED.ASM		- set memory model to XXX,C
   P5INFO.ASM		- set memory model to XXX,C
*/

/* Modification history:

	21 Jun 1994  initially written
	04 Oct 1994  some changes made, see HISTORY.DOC for details

*/

#include <stdlib.h>
#include <string.h>

#define __Lib__
#include "cputype.h"

byte FPUType = 0xFF;	/* variable to keep FPU test result code */
long CPUFix  = 0L;	/* variable used internally in CPU speed testing */
word Shift   = 2;	/* --"-- */

extern int Speed( byte );		/* returns raw CPU speed factor */

extern word GetP5Features(void);	/* returns P5 feature word */

extern void GetP5Vendor(char far *);	/* returns CPU vendor id string */

extern word CheckP5(void);		/* checks if cpuid works */

/*
   To my regret I didn't find a function in C RTL to search for a substring in
   a string so I had to write one on my own. It works fine as far as I tested
   it though I didn't perform extensive tests...
*/

int strscan( char *substr, char *instr )
{
 int i = 0, k = strlen(instr)-strlen(substr);
 while (i <= k)
  if(substr[0] != instr[i]) ++i;
 else
  if(!strncmp(substr,instr+i,strlen(substr)))
   return i;
 return 0;
}

void checkUMC(void)
{
 char s[14];
 if(_CPU >= i486sxr)
  if(CheckP5()==0x423)
   {
    GetP5Vendor(s);
    s[13]=0;
    if(strscan("UMC",s+1))
     if(GetP5Features() & 1)
      _CPU = 0x13;
     else
      _CPU = 0x12;
   }
}

float CPU_Speed(void)
{
 word sp;
 if(!_CPU)
  return 0;
 sp = Speed(_CPU);
 return (((long)Shift*CPUFix)/sp+5)/10;
}

int intCPU_Speed(void)
{
 long sp;
 if(!_CPU)
  return 0;
 sp = (long) Speed(_CPU);
 return (int) ((((long)Shift*CPUFix)/sp+5l)/10l);
}

char * cpuType_Str(void)
{
  char *Names[] = { "Intel 8088", "Intel 8086", "NEC V20", "NEC V30",
		    "Intel 80188", "Intel 80186", "Intel 80286", "Intel 80386sx",
		    "Intel 80386dx", "IBM 386sl", "Intel i486sx", "Intel i486dx",
		    "Cyrix 486slc", "Cyrix 486", "Intel Pentium", "Cyrix M1 (586)",
		    "AMD Am386sx","AMD Am386dx","UMC U5-S","UMC U5-D"
		   };

  word c = CPU_Type();
  _CPU = c;
  checkUMC();
  switch(c) {
   case i80386sxr:
   case i80386sxv: if (intCPU_Speed() > 35)
 		    return Names[0x10];
		   else
	 	    return Names[_CPU];
   case i80386dxr:
   case i80386dxv: if (intCPU_Speed() > 35)
		    return Names[0x11];
		   else
		    return Names[_CPU];
   default:
	           return Names[_CPU];
  }
}

char *fpuType_Str(void)
{
  char *Names[] = {"Unknown!", "Unknown!", "None", "Weitek", "Intel 8087",
		   "Intel 8087 & Weitek", "Intel i487sx", "Intel i487sx & Weitek",
		   "Intel 80287", "Intel 80287 & Weitek", "Cyrix 2C87",
		   "Cyrix 2C87 & Weitek", "Intel 80387", "Intel 80387 & Weitek",
		   "Cyrix 3C87", "Cyrix 3C87 + Weitek", "Built-in",
		   "Built-in & Weitek", "Cyrix 4C87", "Cyrix 4C87 & Weitek",
		   "Intel 80287XL", "Intel 80287XL & Weitek",
		   "IIT 2C87", "IIT 2C87 & Weitek", "IIT 3C87", "IIT 3C87 & Weitek"
		  };

  if (FPUType == 0xFF)
   CPU_Type();
  if (FPUType > 25) 
   return ("Unknown!");
  else
   return Names[FPUType];
}

