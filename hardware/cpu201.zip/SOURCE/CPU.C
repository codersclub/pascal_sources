/*****************************************************************************/
/* CPU.C        TMi0SDGL Release 2 Demonstration program        Version 2.01 */
/*                                                                           */
/* Too-Much-in-0ne-So-Don't-Get-Lost(tm) Revision 2 CPU/FPU Detection Library*/
/* Copyright(c) 1996 by B-coolWare. Written by Bobby Z.                      */
/*****************************************************************************/

#include <stdio.h>
#include "tmi0sdgl.h"

int cdecl main( void )
{
 puts("CPU Type Identifier/C II  Version 2.01  Copyright(c) 1996 by B-coolWare.");
 printf("Processor: %s, %dMHz\nMath unit: %s\n",cpu_Type(),cpu_Speed(),fpu_Type());
 return cpu;
}
