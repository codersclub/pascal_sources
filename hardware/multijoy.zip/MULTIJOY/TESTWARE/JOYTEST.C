/* Mainprogram for Multijoy */

/* #include <iostream.h> */
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>     /* for getenv  */
#include <dos.h>	/* for inportb */
#include <string.h>	/* for strchr  */
#include <ctype.h>	/* for toupper */
#include "minijoy.h"


void hit(void)
{
  putc('�',stdout);
  sound(440);
  delay(10);
  nosound();
}

void main(void)
{
  int i;

  /* init the unit-parameter */
  InitMultiJoy ();

  clrscr();
  for (i=1; i<=6; i++)
  {
    gotoxy(i*10-2, 3);
    printf("Joy %d",i);
  }
  gotoxy(1,24);
  printf("Press any key to exit");

  do
  {
    if (kbhit()) { clrscr(); exit(0); }

    GetAllJoyState ();
    for (i=1; i<=6; i++)
    {
      gotoxy(i*10,5);
      if (JoyState[i].y ==-1)
	{if (JoyState[i].uhit) hit(); else puts("^");}
      else puts(" ");

      gotoxy(i*10-2,6);
      if (JoyState[i].x ==-1)
	{if (JoyState[i].lhit) hit(); else puts("<");}
      else puts(" ");

      gotoxy(i*10+2,6);
      if (JoyState[i].x ==1)
	{if (JoyState[i].rhit) hit(); else puts(">");}
      else puts(" ");

      gotoxy(i*10,7);
      if (JoyState[i].y == 1)
	{if (JoyState[i].dhit) hit(); else puts("v");}
      else puts(" ");

      gotoxy(i*10,9);
      if (JoyState[i].knopf)
	{if (JoyState[i].khit) hit(); else puts("K");}
      else puts(" ");

      gotoxy(i*10,10);
      if (JoyState[i].xtra)
	{if (JoyState[i].xhit) hit(); else puts("X");}
      else puts(" ");

    }
  }
  while (1);
}